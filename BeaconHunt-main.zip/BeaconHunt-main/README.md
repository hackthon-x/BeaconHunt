<div align="center">

<img src="logo.png" alt="BeaconHunt Logo" width="400">

# BeaconHunt

### Offline C2 Beaconing Detection & Network Traffic Analysis

**A defensive desktop application for finding suspicious periodic connection patterns in PCAP captures and firewall/proxy logs.**

</div>

---

## Download BeaconHunt

Download the complete project from the public GitHub repository:

<div align="center">

[![Download ZIP](https://img.shields.io/badge/Download-Project%20ZIP-2ea44f?style=for-the-badge&logo=github)](https://github.com/hackthon-x/BeaconHunt/archive/refs/heads/main.zip)

[**Open GitHub Repository**](https://github.com/hackthon-x/BeaconHunt) · [**Download ZIP**](https://github.com/hackthon-x/BeaconHunt/archive/refs/heads/main.zip)

</div>

### Download without Git

1. Click **Download ZIP**.
2. Extract the archive.
3. Open a terminal in the extracted `BeaconHunt-main/BeaconHunt/` application directory.
4. Follow the installation instructions below.

### Clone with Git

```bash
git clone https://github.com/hackthon-x/BeaconHunt.git
cd BeaconHunt/BeaconHunt
```

---

## Overview

BeaconHunt is a passive, offline network-analysis application that examines connection metadata to identify periodic, beacon-like communication patterns that may deserve further investigation.

The application imports PCAP/PCAPNG captures, CSV/TSV files, and supported plain-text firewall or proxy logs. It normalizes the input into connection records, groups events by destination, port, and protocol, calculates timing and byte-size statistics, and ranks the results using a transparent 0–100 regularity score.

BeaconHunt is a heuristic triage tool. A regular communication pattern is not proof of command-and-control (C2) activity. Findings must be validated with endpoint context, asset ownership, threat intelligence, and organizational policy.

## Features

- **Offline packet-capture parsing:** Read PCAP and PCAPNG files locally with Scapy.
- **TCP and UDP event extraction:** Apply configurable TCP event policies and UDP idle-timeout handling.
- **CSV/TSV import:** Parse tabular connection logs with automatic header aliases and configurable column mapping.
- **Plain-text log import:** Parse the documented `firewall_kv` and `squid_common` formats, or provide a custom regular expression with named groups.
- **Destination grouping:** Group events by destination address, destination port, and protocol.
- **Timing analysis:** Calculate inter-event intervals, mean, median, standard deviation, coefficient of variation, and interval range.
- **Jitter analysis:** Calculate median absolute deviation, relative jitter, and jitter-band fit.
- **Byte-size analysis:** Calculate byte-size statistics when the input provides usable byte counts.
- **Transparent scoring:** Combine interval regularity, jitter consistency, byte-size consistency, and connection-count support into a 0–100 score.
- **Exclusion lists:** Exclude known-good IP addresses, IP-and-port entries, and CIDR ranges.
- **Baseline comparison:** Identify destinations already present in a saved baseline and destinations that are new to it.
- **Desktop dashboard:** Review ranked results, destination details, event records, statistics, and charts.
- **Report exports:** Export reports as JSON, CSV, HTML, PDF, and plain text.
- **Synthetic sample data:** Use included sample CSV, PCAP, and text-log files to explore the tool.
- **Automated tests:** Run the included parser, analysis, export, and GUI smoke tests.

## Technology Stack

| Technology | Purpose |
|---|---|
| Python 3.11+ | Application and analysis logic |
| PySide6 | Desktop GUI (Qt 6) |
| Scapy | Offline PCAP/PCAPNG parsing |
| NumPy | Numerical statistics |
| Matplotlib | Analysis charts |
| ReportLab | PDF report export |
| pytest | Automated tests |

Dependencies are listed in `BeaconHunt/requirements.txt`.

## Requirements

- Python **3.11 or later**. The project dependencies are documented as tested with Python 3.11+ and developed on Python 3.12.
- A graphical desktop environment to run the GUI.
- `pip` and Python's `venv` module.
- Linux, macOS, or Windows for manual Python environment setup. The supplied `install.sh` installer is for Linux and macOS; Windows users should use the manual setup instructions.

## Project Layout

The ZIP contains a top-level `BeaconHunt-main/` folder. Inside it, the application project is in `BeaconHunt/`, while the repository-level README and logo are alongside that folder.

```text
BeaconHunt-main/
├── README.md
├── logo.png
└── BeaconHunt/
    ├── beaconhunt/
    │   ├── analysis/       # Grouping, statistics, scoring, exclusions, baseline
    │   ├── config/         # Analysis configuration and defaults
    │   ├── models/         # Connection records and parsing models
    │   ├── parsers/        # PCAP, CSV/TSV, and plain-text parsers
    │   ├── reports/        # JSON, CSV, HTML, PDF, and text exporters
    │   ├── samples/        # Synthetic sample generator
    │   ├── ui/             # PySide6 desktop interface and charts
    │   ├── workers/        # Background analysis worker
    │   └── app.py          # GUI application entry point
    ├── samples/            # Sample input files and configuration examples
    ├── tests/              # Automated test suite
    ├── download/
    │   └── example_reports/
    ├── requirements.txt
    ├── setup_venv.sh
    ├── install.sh
    ├── run.py
    └── README.md
```

## Installation

Open a terminal in the application directory.

For the downloaded ZIP:

```bash
cd BeaconHunt-main/BeaconHunt
```

For a Git clone:

```bash
cd BeaconHunt/BeaconHunt
```

### Option 1: Setup helper (Linux/macOS)

The project includes `setup_venv.sh` to create a local virtual environment and install the dependencies:

```bash
chmod +x setup_venv.sh
./setup_venv.sh
source venv/bin/activate
```

Then launch the application:

```bash
python3 -m beaconhunt.app
```

You can also launch without activating the environment:

```bash
./venv/bin/python -m beaconhunt.app
```

### Option 2: Manual setup (Linux/macOS)

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Option 3: Manual setup (Windows PowerShell)

From the `BeaconHunt` application directory:

```powershell
py -3 -m venv venv
.\\venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If PowerShell blocks activation, use the Python executable in the virtual environment directly:

```powershell
.\\venv\\Scripts\\python.exe -m pip install -r requirements.txt
.\\venv\\Scripts\\python.exe -m beaconhunt.app
```

## Installer Script (Linux/macOS)

The project also includes `install.sh`. It can extract a `BeaconHunt.zip` archive, create a virtual environment, install dependencies, optionally handle Linux Qt runtime libraries, and run a smoke test.

The script's default archive name is `BeaconHunt.zip`. To use the downloaded repository archive under its current name, pass its path explicitly:

```bash
./install.sh --zip ../BeaconHunt-main.zip
```

Useful installer options:

```bash
./install.sh --help
./install.sh --zip ../BeaconHunt-main.zip --skip-tests
./install.sh --zip ../BeaconHunt-main.zip --dest ../BeaconHunt-installed
./install.sh --uninstall
```

Review the script help before using reinstall or uninstall options because they can remove an existing installation directory.

## Launch the Application

From the `BeaconHunt/` application directory, with the virtual environment active:

```bash
python -m beaconhunt.app
```

Alternatively, use the convenience runner:

```bash
python run.py
```

The application opens the BeaconHunt desktop interface.

## Quick Start

1. Launch BeaconHunt.
2. Open one of the included sample files, such as `samples/mixed.csv`.
3. Check the input type and analysis settings.
4. Start the analysis.
5. Review the ranked destination results and their statuses.
6. Select a destination to inspect its metrics, score components, events, and charts.
7. Export the report in the required format.

You can also select your own supported PCAP/PCAPNG, CSV/TSV, or text-log file through the application.

## Supported Input Formats

### PCAP and PCAPNG

BeaconHunt reads packet-capture files offline using Scapy. It extracts connection metadata and creates events according to the configured TCP and UDP policies.

Relevant analysis settings include:

- `tcp_event_policy`: `syn_no_ack` or `first_seen`
- `udp_idle_timeout`: default 120 seconds
- `byte_size_source`: `captured`, `wire`, or `reported`

The tool does not perform live packet capture.

### CSV and TSV

The CSV parser supports a configurable delimiter and automatic header matching.

Required fields:

- Timestamp
- Source address
- Destination address

Optional fields:

- Destination port
- Protocol
- Byte count

Common header aliases include `timestamp`, `ts`, `time`, `src`, `src_ip`, `source`, `dst`, `dst_ip`, `destination`, `dport`, `dst_port`, `proto`, `protocol`, `bytes`, and `length`.

If automatic mapping cannot identify required columns, configure the column mapping in the application.

### Plain-text logs

The text parser provides two documented named formats:

- `firewall_kv`
- `squid_common`

It also supports a custom Python regular expression using named groups:

- Required: `ts`, `src`, `dst`
- Optional: `dport`, `proto`, `bytes`

For custom formats, the timestamp must be parseable by the application's timestamp parser (or as a Unix epoch float where supported).

## Detection and Scoring

BeaconHunt processes input through the following stages:

1. Parse the selected file and normalize connection events.
2. Apply the configured TCP/UDP event policy.
3. Group records by destination address, port, and protocol by default.
4. Calculate time intervals between consecutive events.
5. Compute timing, jitter, and available byte-size statistics.
6. Calculate the regularity score.
7. Apply exclusion rules and optional baseline comparison.
8. Rank the results for review and export.

### Score components

The default score uses four components:

| Component | Default weight |
|---|---:|
| Interval regularity | 35% |
| Jitter consistency | 30% |
| Byte-size consistency | 20% |
| Connection-count support | 15% |

Each available component is normalized to a 0–100 scale. If a component cannot be calculated, it is omitted and the remaining weights are renormalized. Missing byte-size data does not automatically force a destination's score to zero.

### Default analysis settings

| Setting | Default |
|---|---:|
| Minimum events | 5 |
| Score threshold | 70 |
| Jitter tolerance | 20% |
| UDP idle timeout | 120 seconds |
| Grouping policy | `dest_port_protocol` |
| TCP event policy | `syn_no_ack` |
| Byte-size source | `captured` |
| Standard deviation | Population (`ddof=0`) |
| Maximum events per group | 200,000 |

These values can be overridden through the application's Analysis Settings panel.

### Result statuses

| Status | Meaning |
|---|---|
| `flagged` | Meets the minimum event count and score threshold |
| `not_flagged` | Meets the minimum event count but is below the score threshold |
| `insufficient_evidence` | Has fewer events than the configured minimum |
| `excluded` | Matches an analyst-provided exclusion entry |

A `flagged` result indicates suspicious periodicity for investigation; it does not establish malicious activity.

## Exclusions and Baselines

BeaconHunt can apply an exclusion list to mark matching destinations as excluded. The project includes `samples/exclusions.txt` as an example.

It can also compare destination/port/protocol keys with a saved baseline. Destinations are marked as `known` or `new` relative to that baseline. An example baseline is provided at `samples/baseline.json`.

Review the example files before adapting them to your environment.

## Reports and Exports

BeaconHunt supports these report formats:

| Format | Use |
|---|---|
| JSON | Structured analysis results |
| CSV | Tabular results |
| HTML | Browser-readable report |
| PDF | Printable report |
| TXT | Plain-text summary |

Example reports are included in:

```text
download/example_reports/
```

The project includes example reports generated from mixed CSV and periodic PCAP sample data.

## Included Sample Data

The `samples/` directory includes examples such as:

- `mixed.csv`
- `strict_periodic.csv`
- `jittered_periodic.csv`
- `irregular_human.csv`
- `below_threshold.csv`
- `empty.csv`
- `malformed.csv`
- `missing_bytes.csv`
- `ipv6.csv`
- `timezone_offset.csv`
- `firewall.txt`
- `periodic.pcap`
- `udp_periodic.pcap`
- `ipv6.pcap`
- `truncated.pcap`
- `exclusions.txt`
- `baseline.json`

Regenerate synthetic samples from the application directory with:

```bash
python run.py --samples
```

## Demo Mode

Run the bundled demonstration analysis and generate example reports with:

```bash
python run.py --demo
```

The demo processes the mixed CSV sample with the supplied exclusions and baseline, then processes the periodic PCAP sample. Generated reports are written to:

```text
download/example_reports/
```

## Testing

Run the full automated test suite:

```bash
python run.py --tests
```

Or run pytest directly:

```bash
python -m pytest tests/ -v
```

For a GUI smoke test in a headless Linux environment:

```bash
QT_QPA_PLATFORM=offscreen python tests/test_gui_smoke.py
```

The test directory includes coverage for PCAP parsing, text and CSV logs, grouping, statistics, scoring, exclusions, baseline comparison, exports, usability, and GUI smoke behavior.

## Privacy and Security

BeaconHunt is designed for local defensive analysis:

- It reads files selected by the user.
- PCAP processing is offline.
- It does not capture live network traffic.
- It does not open network sockets or send packets.
- It does not perform online DNS resolution.
- It does not upload analysis data to a cloud service.
- The analysis focuses on connection metadata rather than displaying packet payload contents.

Only analyze captures and logs that you own or are explicitly authorized to examine. Treat exported reports as potentially sensitive security information and store them securely.

## Limitations and False Positives

- The detection method is heuristic and can produce false positives.
- Legitimate update agents, monitoring systems, scheduled jobs, NTP, telemetry, and synchronization clients may communicate periodically.
- A regularity score is not a malware verdict or proof of C2.
- The tool focuses on connection metadata; it does not perform payload-based C2 identification.
- It does not resolve hostnames online.
- Incomplete, truncated, or filtered captures may affect event counts and calculated statistics.
- NAT and proxy infrastructure can make source-address context less representative.

Investigate flagged results alongside endpoint telemetry, network architecture, asset ownership, and other available evidence before taking action.

## Responsible Use

BeaconHunt is intended for cybersecurity education, defensive network traffic analysis, and authorized security investigations. It is not a replacement for a full incident-response process, endpoint investigation, or professional security assessment.

## Author

**Ashar**

**Version:** 1.0.0

---

<div align="center">

**BeaconHunt · Passive. Offline. Evidence-driven.**

</div>
