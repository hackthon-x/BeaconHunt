#!/usr/bin/env bash
#
# install.sh — BeaconHunt installer
# ----------------------------------
# Extracts BeaconHunt.zip, creates a Python virtual environment, installs
# the project's Python dependencies, optionally installs the Qt runtime
# libraries the GUI needs on Linux, and runs a smoke test.
#
# Supported platforms: Linux (Debian/Ubuntu/Kali/Arch/Fedora) and macOS.
# Windows is not supported by this script — use setup_venv.sh inside
# PowerShell, or run python -m venv manually.
#
# Usage:
#   ./install.sh                 # extract ./BeaconHunt.zip next to this script
#   ./install.sh --zip FILE      # use a different zip file
#   ./install.sh --dest DIR      # extract into DIR instead of ./BeaconHunt
#   ./install.sh --skip-tests    # skip the post-install smoke test
#   ./install.sh --no-system-qt  # do not attempt to install Qt system libs
#   ./install.sh --reinstall     # wipe an existing ./BeaconHunt first
#   ./install.sh --uninstall     # remove ./BeaconHunt and ./venv
#   ./install.sh --help
#
# After install, launch the GUI with:
#   ./BeaconHunt/venv/bin/python -m beaconhunt.app
# or, after activating the venv:
#   source ./BeaconHunt/venv/bin/activate
#   python3 -m beaconhunt.app
#
set -euo pipefail

# ----------------------------------------------------------------------------
# Config
# ----------------------------------------------------------------------------
DEFAULT_ZIP="BeaconHunt.zip"
DEFAULT_DEST="BeaconHunt"
MIN_PY_MINOR=11                 # require Python 3.11+
VENV_NAME="venv"                # created inside DEST

# Pretty printing.
if [ -t 1 ] && command -v tput >/dev/null 2>&1; then
    BOLD="$(tput bold)";   GREEN="$(tput setaf 2)"; YELLOW="$(tput setaf 3)"
    RED="$(tput setaf 1)"; BLUE="$(tput setaf 4)"; RESET="$(tput sgr0)"
else
    BOLD=""; GREEN=""; YELLOW=""; RED=""; BLUE=""; RESET=""
fi

log()  { printf '%s==>%s %s\n'  "${BOLD}${BLUE}" "${RESET}" "$*"; }
ok()   { printf '%s✓%s  %s\n'   "${GREEN}"       "${RESET}" "$*"; }
warn() { printf '%s!%s  %s\n'   "${YELLOW}"      "${RESET}" "$*" >&2; }
err()  { printf '%s✗%s  %s\n'   "${RED}"         "${RESET}" "$*" >&2; }
die()  { err "$*"; exit 1; }

# ----------------------------------------------------------------------------
# Arg parsing
# ----------------------------------------------------------------------------
ZIP_PATH=""
DEST_DIR=""
SKIP_TESTS=0
NO_SYSTEM_QT=0
REINSTALL=0
UNINSTALL=0
SHOW_HELP=0

while [ $# -gt 0 ]; do
    case "$1" in
        --zip)            ZIP_PATH="$2"; shift 2 ;;
        --dest)           DEST_DIR="$2"; shift 2 ;;
        --skip-tests)     SKIP_TESTS=1; shift ;;
        --no-system-qt)   NO_SYSTEM_QT=1; shift ;;
        --reinstall)      REINSTALL=1; shift ;;
        --uninstall)      UNINSTALL=1; shift ;;
        --help|-h)        SHOW_HELP=1; shift ;;
        --)               shift; break ;;
        *)
            err "Unknown argument: $1"
            err "Run '$0 --help' for usage."
            exit 2
            ;;
    esac
done

if [ "$SHOW_HELP" -eq 1 ]; then
    # Print the leading comment block (lines 2..first non-#), stripped of "# ".
    awk 'NR==1{next} /^#/{sub(/^# ?/,""); print; next} {exit}' "$0"
    exit 0
fi

# Resolve paths relative to the script's own directory so the user can run
# ./install.sh from anywhere.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -z "$ZIP_PATH" ]  && ZIP_PATH="$SCRIPT_DIR/$DEFAULT_ZIP"
[ -z "$DEST_DIR" ]  && DEST_DIR="$SCRIPT_DIR/$DEFAULT_DEST"

# ----------------------------------------------------------------------------
# Uninstall mode
# ----------------------------------------------------------------------------
if [ "$UNINSTALL" -eq 1 ]; then
    log "Uninstalling BeaconHunt..."
    for target in "$DEST_DIR" "$DEST_DIR/$VENV_NAME"; do
        if [ -e "$target" ]; then
            warn "Removing: $target"
            rm -rf "$target"
        fi
    done
    ok "Uninstall complete."
    exit 0
fi

# ----------------------------------------------------------------------------
# Preflight checks
# ----------------------------------------------------------------------------
command -v unzip >/dev/null 2>&1 || die "unzip is required but not installed (apt install unzip / dnf install unzip / brew install unzip)."
command -v python3 >/dev/null 2>&1 || die "python3 is not installed. Install Python 3.11+ first."

PY_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
PY_MAJOR="$(printf '%s' "$PY_VERSION" | cut -d. -f1)"
PY_MINOR="$(printf '%s' "$PY_VERSION" | cut -d. -f2)"
if [ "$PY_MAJOR" -ne 3 ] || [ "$PY_MINOR" -lt "$MIN_PY_MINOR" ]; then
    die "BeaconHunt needs Python 3.$MIN_PY_MINOR or newer (found $PY_VERSION)."
fi
ok "Python $PY_VERSION detected."

if [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -ge 13 ]; then
    warn "Python $PY_VERSION is newer than 3.12 (the version BeaconHunt was developed on)."
    warn "If pip fails to find a wheel for PySide6 / matplotlib / numpy, fall back to"
    warn "Python 3.12 from your distro or pyenv. The script will keep going regardless."
fi

# Detect OS / distro for the venv + Qt helper install steps.
OS_KIND="unknown"
if [ "$(uname -s)" = "Darwin" ]; then
    OS_KIND="macos"
elif [ -f /etc/debian_version ]; then
    OS_KIND="debian"
elif [ -f /etc/arch-release ]; then
    OS_KIND="arch"
elif [ -f /etc/fedora-release ] || [ -f /etc/redhat-release ]; then
    OS_KIND="rhel"
fi

# ----------------------------------------------------------------------------
# Optional reinstall
# ----------------------------------------------------------------------------
if [ "$REINSTALL" -eq 1 ] && [ -d "$DEST_DIR" ]; then
    warn "Removing existing $DEST_DIR (--reinstall)."
    rm -rf "$DEST_DIR"
fi

# ----------------------------------------------------------------------------
# Extract the zip — or detect we're already inside the project
# ----------------------------------------------------------------------------
#
# Two supported layouts:
#   (A) install.sh + BeaconHunt.zip  side-by-side
#       → extract the zip into ./BeaconHunt
#   (B) install.sh already inside the extracted BeaconHunt/ folder
#       → no zip exists, but requirements.txt + run.py + beaconhunt/ do
#       → install in place (DEST_DIR == SCRIPT_DIR)
#
# User-provided --zip / --dest always win and force layout (A).
USER_GAVE_ZIP=0
[ "${ZIP_PATH:-}" != "$SCRIPT_DIR/$DEFAULT_ZIP" ] && USER_GAVE_ZIP=1
USER_GAVE_DEST=0
[ "${DEST_DIR:-}" != "$SCRIPT_DIR/$DEFAULT_DEST" ] && USER_GAVE_DEST=1

IN_PLACE=0
if [ ! -f "$ZIP_PATH" ]; then
    # No zip next to the script. Are we standing inside the project?
    if [ -f "$SCRIPT_DIR/requirements.txt" ] \
       && [ -f "$SCRIPT_DIR/run.py" ] \
       && [ -f "$SCRIPT_DIR/beaconhunt/__init__.py" ]; then
        if [ "$USER_GAVE_ZIP" -eq 1 ]; then
            die "Zip file not found: $ZIP_PATH"
        fi
        IN_PLACE=1
        DEST_DIR="$SCRIPT_DIR"
        ok "No zip found — running in-place against the project in $SCRIPT_DIR"
    else
        die "Zip file not found: $ZIP_PATH (use --zip FILE to override), and the current directory does not look like a BeaconHunt project (missing requirements.txt / run.py / beaconhunt/)."
    fi
fi

if [ "$IN_PLACE" -eq 0 ]; then
    if [ ! -d "$DEST_DIR" ]; then
        log "Extracting $ZIP_PATH → $DEST_DIR ..."
        # Zip ships with a top-level "BeaconHunt/" folder; strip it so the
        # extracted files land directly inside $DEST_DIR.
        mkdir -p "$DEST_DIR"
        unzip -q -o "$ZIP_PATH" -d "$SCRIPT_DIR"
        # If the zip's internal folder name matches the default, we're done.
        # Otherwise (custom --dest), move the extracted tree.
        INTERNAL_NAME="$(unzip -Z1 "$ZIP_PATH" 2>/dev/null | head -1 | cut -d/ -f1 || true)"
        if [ -n "$INTERNAL_NAME" ] && [ -d "$SCRIPT_DIR/$INTERNAL_NAME" ] && \
           [ "$SCRIPT_DIR/$INTERNAL_NAME" != "$DEST_DIR" ]; then
            # Move contents into the user's --dest (handles case-sensitivity too).
            if [ -d "$DEST_DIR" ] && [ -z "$(ls -A "$DEST_DIR" 2>/dev/null)" ]; then
                rmdir "$DEST_DIR"
            fi
            mv "$SCRIPT_DIR/$INTERNAL_NAME" "$DEST_DIR"
        fi
        ok "Extracted to $DEST_DIR"
    else
        ok "$DEST_DIR already exists — reusing it (use --reinstall to start fresh)."
    fi
fi

# Sanity check the project contents (works for both layouts).
for f in requirements.txt run.py beaconhunt/__init__.py; do
    if [ ! -f "$DEST_DIR/$f" ]; then
        die "Install looks incomplete — '$f' is missing inside $DEST_DIR."
    fi
done

cd "$DEST_DIR"

# ----------------------------------------------------------------------------
# Make sure python3-venv is available (Debian ships python3 WITHOUT venv)
# ----------------------------------------------------------------------------
need_venv_module=0
if ! python3 -c 'import venv, ensurepip' >/dev/null 2>&1; then
    need_venv_module=1
fi

if [ "$need_venv_module" -eq 1 ]; then
    warn "The python3 venv module is missing."
    case "$OS_KIND" in
        debian)
            err "Install it once with:"
            err "    sudo apt install python3-venv python3-full"
            err "then re-run this script."
            exit 1
            ;;
        arch)
            err "On Arch, python3-venv is part of the 'python' package — install it with:"
            err "    sudo pacman -S python"
            exit 1
            ;;
        rhel)
            err "On Fedora/RHEL install it with:"
            err "    sudo dnf install python3 python3-pip"
            exit 1
            ;;
        macos)
            err "On macOS, install Python 3 from python.org or via 'brew install python'."
            exit 1
            ;;
        *)
            err "Could not auto-detect your distro. Install the python3 venv module manually."
            exit 1
            ;;
    esac
fi

# ----------------------------------------------------------------------------
# Create the virtual environment
# ----------------------------------------------------------------------------
#
# We deliberately do NOT use `source venv/bin/activate` + bare `pip`. On
# Kali/Debian/Ubuntu (PEP 668) the venv can exist on disk but have no
# working `pip` inside it — `activate` then silently leaves PATH pointing
# at system pip, which dies with "externally-managed-environment". Calling
# venv/bin/python -m pip directly bypasses that whole class of bugs.
VENV_PY="$VENV_NAME/bin/python"
VENV_PIP_OK=0

# Returns 0 if the venv has a working pip that does NOT report
# "externally-managed-environment" (i.e. it really is the venv's own pip).
venv_pip_works() {
    [ -x "$VENV_PY" ] || return 1
    "$VENV_PY" -m pip --version >/dev/null 2>&1 || return 1
    # PEP 668 marker file. A real venv has EXTERNALLY-MANAGED *removed*.
    # Check by trying to install a no-op into a temp target.
    "$VENV_PY" -m pip install --dry-run --quiet pip >/dev/null 2>&1 || return 1
    return 0
}

if [ -d "$VENV_NAME" ]; then
    if venv_pip_works; then
        ok "Virtual environment ./$VENV_NAME already exists and has a working pip — reusing it."
        VENV_PIP_OK=1
    else
        warn "Existing ./$VENV_NAME is missing pip (likely created without python3-venv)."
        warn "Recreating it cleanly..."
        rm -rf "$VENV_NAME"
    fi
fi

if [ "$VENV_PIP_OK" -eq 0 ]; then
    log "Creating virtual environment ./$VENV_NAME ..."
    # --upgrade-deps makes the freshly-created venv upgrade pip+setuptools
    # on creation, which avoids a second pip-install step.
    if ! python3 -m venv --upgrade-deps "$VENV_NAME" 2>"/tmp/beaconhunt_venv.err"; then
        err "python3 -m venv failed. Output was:"
        sed 's/^/    /' "/tmp/beaconhunt_venv.err" >&2
        case "$OS_KIND" in
            debian)
                err ""
                err "On Kali/Debian/Ubuntu this usually means python3-venv is not installed."
                err "Fix it once with:"
                err "    sudo apt install python3-venv python3-full"
                err "then re-run this script."
                ;;
            *)
                err "See /tmp/beaconhunt_venv.err for details."
                ;;
        esac
        exit 1
    fi
    if ! venv_pip_works; then
        err "Virtual environment was created at ./$VENV_NAME but pip is not usable."
        err "Try removing it and re-running:"
        err "    rm -rf $VENV_NAME && bash $0"
        exit 1
    fi
    ok "Virtual environment ./$VENV_NAME created."
fi

log "Upgrading pip ..."
"$VENV_PY" -m pip install --upgrade pip --quiet

log "Installing requirements.txt into the venv ..."
"$VENV_PY" -m pip install -r requirements.txt

# pytest is dev-only (not in requirements.txt) but the bundled tests use it.
# Install it so the smoke test below can actually run.
log "Installing pytest (needed by the bundled test suite) ..."
"$VENV_PY" -m pip install pytest --quiet

# ----------------------------------------------------------------------------
# Optional: install Qt runtime libraries the GUI needs on a minimal Linux.
# ----------------------------------------------------------------------------
if [ "$OS_KIND" = "debian" ] && [ "$NO_SYSTEM_QT" -eq 0 ]; then
    QT_LIBS_MISSING=0
    for lib in libEGL.so.1 libxkbcommon.so.0 libdbus-1.so.3 libfontconfig.so.1; do
        if ! ldconfig -p 2>/dev/null | grep -q "$lib"; then
            QT_LIBS_MISSING=1
            break
        fi
    done
    if [ "$QT_LIBS_MISSING" -eq 1 ]; then
        warn "Some Qt runtime libraries appear to be missing."
        warn "If the GUI fails to start with libEGL errors, run:"
        warn "    sudo apt install libegl1 libegl-mesa0 libxkbcommon0 libdbus-1-3 libfontconfig1"
        warn "(Or re-run with --no-system-qt to silence this message.)"
    fi
fi

# ----------------------------------------------------------------------------
# Smoke test
# ----------------------------------------------------------------------------
if [ "$SKIP_TESTS" -eq 0 ]; then
    log "Running smoke test (pytest tests/ — offscreen Qt) ..."
    if QT_QPA_PLATFORM=offscreen "$VENV_PY" -m pytest tests/ -q >/tmp/beaconhunt_install_tests.log 2>&1; then
        ok "Smoke test passed."
    else
        warn "Smoke test reported failures. See /tmp/beaconhunt_install_tests.log"
        warn "You can still try to launch the GUI — tests may fail on a headless box."
    fi
else
    ok "Skipping tests (--skip-tests)."
fi

# ----------------------------------------------------------------------------
# Done
# ----------------------------------------------------------------------------

cat <<EOF

${GREEN}${BOLD}BeaconHunt installed successfully.${RESET}

  Location:        ${DEST_DIR}
  Virtual env:     ${DEST_DIR}/${VENV_NAME}
  Python:          ${PY_VERSION}

${BOLD}Next steps:${RESET}

  ${BOLD}Launch the GUI:${RESET}
    ${DEST_DIR}/${VENV_NAME}/bin/python -m beaconhunt.app

  ${BOLD}Or activate the venv first:${RESET}
    source ${DEST_DIR}/${VENV_NAME}/bin/activate
    python3 -m beaconhunt.app

  ${BOLD}Run the demo (synthetic samples):${RESET}
    ${DEST_DIR}/${VENV_NAME}/bin/python ${DEST_DIR}/run.py --demo

  ${BOLD}Run the test suite:${RESET}
    ${DEST_DIR}/${VENV_NAME}/bin/python ${DEST_DIR}/run.py --tests

${BOLD}Uninstall:${RESET}
    ${SCRIPT_DIR}/install.sh --uninstall

EOF
