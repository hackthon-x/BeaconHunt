#!/usr/bin/env bash
# BeaconHunt — virtual environment setup helper.
#
# Works around PEP 668 ("externally-managed-environment") on Kali, Debian
# 12+, Ubuntu 23.04+, and similar distributions by creating a local venv
# and installing the requirements into it.
#
# Usage:
#   ./setup_venv.sh
#   source venv/bin/activate
#   python3 -m beaconhunt.app
#
# Or, after running this once:
#   ./venv/bin/python -m beaconhunt.app
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# Make sure python3-venv is available. On Debian/Kali this may need:
#   sudo apt install python3-venv python3-full
if ! command -v python3 >/dev/null 2>&1; then
    echo "error: python3 is not installed." >&2
    exit 1
fi

if [ ! -d venv ]; then
    echo "Creating virtual environment in ./venv ..."
    python3 -m venv venv
fi

# Activate and install.
# shellcheck disable=SC1091
source venv/bin/activate

echo "Upgrading pip ..."
pip install --upgrade pip --quiet

echo "Installing requirements.txt into the venv ..."
pip install -r requirements.txt

# Optional Linux Qt runtime libraries. PySide6 ships its own Qt, but on
# minimal installs you may need these system packages for libEGL etc.
# We do NOT install them automatically (that needs root); we just print
# the command for the user to run if the GUI fails to start.
if [ -f /etc/debian_version ]; then
    QT_LIBS_MISSING=0
    for lib in libEGL.so.1 libxkbcommon.so.0 libdbus-1.so.3 libfontconfig.so.1; do
        if ! ldconfig -p 2>/dev/null | grep -q "$lib"; then
            QT_LIBS_MISSING=1
            break
        fi
    done
    if [ "$QT_LIBS_MISSING" -eq 1 ]; then
        echo ""
        echo "NOTE: some Qt runtime libraries appear to be missing."
        echo "      If the GUI fails to start with libEGL errors, run:"
        echo ""
        echo "      sudo apt install libegl1 libegl-mesa0 libxkbcommon0 libdbus-1-3 libfontconfig1"
        echo ""
    fi
fi

echo ""
echo "Setup complete. To launch BeaconHunt:"
echo ""
echo "    source venv/bin/activate"
echo "    python3 -m beaconhunt.app"
echo ""
echo "Or directly without activating:"
echo ""
echo "    ./venv/bin/python -m beaconhunt.app"
