"""BeaconHunt — convenience runner.

Usage:
    python run.py            # launch the GUI
    python run.py --tests    # run the full test suite
    python run.py --samples  # regenerate synthetic samples
    python run.py --demo     # run the analysis on samples/mixed.csv and
                              # write all example exports to
                              # download/example_reports/
"""
from __future__ import annotations

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _set_ld_library_path() -> None:
    """On Linux, prepend the locally-extracted Qt libraries if present.

    The .local-libs directory is created by the user (or the install
    script) when libEGL is not available system-wide. This makes the GUI
    runnable without root.
    """
    libs = os.path.join(HERE, ".local-libs", "usr", "lib", "x86_64-linux-gnu")
    if os.path.isdir(libs):
        existing = os.environ.get("LD_LIBRARY_PATH", "")
        os.environ["LD_LIBRARY_PATH"] = (
            f"{libs}:{existing}" if existing else libs
        )


def launch_gui() -> int:
    _set_ld_library_path()
    from beaconhunt.app import main
    return main()


def run_tests() -> int:
    _set_ld_library_path()
    env = os.environ.copy()
    env.setdefault("QT_QPA_PLATFORM", "offscreen")
    return subprocess.call(
        [sys.executable, "-m", "pytest", os.path.join(HERE, "tests"), "-v"],
        env=env,
    )


def regenerate_samples() -> int:
    from beaconhunt.samples.generator import build_all
    out = os.path.join(HERE, "samples")
    paths = build_all(out)
    print(f"Regenerated {len(paths)} sample files under {out}")
    return 0


def run_demo() -> int:
    _set_ld_library_path()
    from beaconhunt.config import AnalysisConfig
    from beaconhunt.parsers import CsvParser, PcapParser
    from beaconhunt.analysis import run_analysis
    from beaconhunt.reports import (
        export_csv, export_html, export_json, export_pdf, export_text,
    )

    out_dir = os.path.join(HERE, "download", "example_reports")
    os.makedirs(out_dir, exist_ok=True)

    # Demo 1: mixed CSV with exclusions + baseline.
    pr = CsvParser().parse(os.path.join(HERE, "samples", "mixed.csv"))
    rep = run_analysis(
        pr, AnalysisConfig(),
        exclusion_path=os.path.join(HERE, "samples", "exclusions.txt"),
        baseline_path=os.path.join(HERE, "samples", "baseline.json"),
    )
    for fn, name in [
        (export_json, "mixed_report.json"),
        (export_csv, "mixed_report.csv"),
        (export_html, "mixed_report.html"),
        (export_pdf, "mixed_report.pdf"),
        (export_text, "mixed_report.txt"),
    ]:
        p = os.path.join(out_dir, name)
        fn(rep, p, force=True)
        print(f"  wrote {p} ({os.path.getsize(p)} bytes)")

    # Demo 2: strict periodic PCAP (clean case).
    pr2 = PcapParser().parse(os.path.join(HERE, "samples", "periodic.pcap"))
    rep2 = run_analysis(pr2, AnalysisConfig())
    for fn, name in [
        (export_json, "periodic_pcap_report.json"),
        (export_pdf, "periodic_pcap_report.pdf"),
        (export_text, "periodic_pcap_report.txt"),
    ]:
        p = os.path.join(out_dir, name)
        fn(rep2, p, force=True)
        print(f"  wrote {p} ({os.path.getsize(p)} bytes)")

    print()
    print(f"Flagged destinations (mixed): {[r.destination_address for r in rep.flagged]}")
    print(f"Flagged destinations (periodic pcap): {[r.destination_address for r in rep2.flagged]}")
    return 0


def main() -> int:
    args = sys.argv[1:]
    if not args:
        return launch_gui()
    if args == ["--tests"]:
        return run_tests()
    if args == ["--samples"]:
        return regenerate_samples()
    if args == ["--demo"]:
        return run_demo()
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main())
