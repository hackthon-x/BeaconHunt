"""BeaconHunt — passive, offline beaconing detector.

BeaconHunt analyzes user-selected PCAP or firewall/proxy log files to find
periodic, beacon-like connection patterns. It is a defensive analysis tool:

  * Reads only files explicitly selected by the user.
  * Never captures live traffic, opens sockets, resolves hostnames, or sends
    packets.
  * Describes results as "beacon-like" or "suspicious periodicity," never as
    proof of command-and-control activity.
  * All parsing and analysis happens locally in a worker thread; no data is
    uploaded anywhere.

See README.md for installation, usage, metrics, and limitations.
"""

__version__ = "1.0.0"
__author__ = "Ashar"
__tool_name__ = "BeaconHunt"
