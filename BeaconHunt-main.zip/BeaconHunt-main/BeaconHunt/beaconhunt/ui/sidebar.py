"""Left navigation sidebar.

Dark navy panel with the BeaconHunt logo at the top, a vertical list of
navigation items (Overview, Analyze File, Results, Baselines, Settings),
and an "Analyst / LAB ENVIRONMENT" footer block. The active item gets a
teal left-edge bar and a slightly lighter background.

Items are exposed as checkable QPushButtons in an exclusive QButtonGroup.
Clicking one emits `page_changed` with the page key.
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QButtonGroup, QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget,
)


# (key, icon glyph, label)
NAV_ITEMS = [
    ("overview",  "⌂",  "Overview"),
    ("analyze",   "▤",  "Analyze File"),
    ("results",   "▦",  "Results"),
    ("baselines", "◫",  "Baselines"),
    ("settings",  "⚙",  "Settings"),
]


class Sidebar(QFrame):
    """Fixed-width dark navy navigation panel."""

    page_changed = Signal(str)   # one of the NAV_ITEMS keys

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setFixedWidth(220)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Logo block
        logo_row = QHBoxLayout()
        logo_row.setContentsMargins(22, 20, 22, 4)
        logo_row.setSpacing(10)
        logo_glyph = QLabel("◆")
        logo_glyph.setStyleSheet(
            f"color:#14B8A6; font-size:18pt; font-weight:800; padding:0;"
        )
        logo_row.addWidget(logo_glyph)
        logo_text = QLabel("BeaconHunt")
        logo_text.setObjectName("SidebarLogo")
        logo_text.setStyleSheet("padding:0;")
        logo_row.addWidget(logo_text)
        logo_row.addStretch()
        layout.addLayout(logo_row)

        tag = QLabel("LOCAL · OFFLINE")
        tag.setObjectName("SidebarLogoTag")
        layout.addWidget(tag)

        layout.addSpacing(14)

        # Nav buttons
        self._group = QButtonGroup(self)
        self._group.setExclusive(True)
        self._buttons: dict = {}
        for key, glyph, label in NAV_ITEMS:
            btn = self._make_nav_button(glyph, label)
            self._group.addButton(btn)
            self._buttons[key] = btn
            btn.clicked.connect(lambda _checked=False, k=key: self._on_clicked(k))
            layout.addWidget(btn)

        layout.addStretch()

        # Footer
        footer = QFrame()
        footer.setObjectName("SidebarFooter")
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(22, 12, 22, 18)
        footer_layout.setSpacing(4)
        avatar_row = QHBoxLayout()
        avatar_row.setSpacing(8)
        avatar = QLabel("●")
        avatar.setStyleSheet(
            "background:#1C3247; color:#14B8A6; border-radius:14px; "
            "padding:6px 9px; font-weight:700; min-width:28px; min-height:28px;"
        )
        avatar.setAlignment(Qt.AlignCenter)
        avatar_row.addWidget(avatar)
        who = QLabel("Analyst")
        who.setStyleSheet(
            f"color:#E8EEF0; font-size:10pt; font-weight:600; padding:0;"
        )
        avatar_row.addWidget(who)
        avatar_row.addStretch()
        footer_layout.addLayout(avatar_row)
        env = QLabel("LAB ENVIRONMENT")
        env.setStyleSheet(
            "color:#5B6B7A; font-size:8pt; font-weight:700; letter-spacing:1px;"
        )
        footer_layout.addWidget(env)
        layout.addWidget(footer)

    def _make_nav_button(self, glyph: str, label: str) -> QPushButton:
        btn = QPushButton(f"  {glyph}   {label}")
        btn.setObjectName("NavButton")
        btn.setCheckable(True)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setMinimumHeight(40)
        return btn

    def _on_clicked(self, key: str) -> None:
        self.page_changed.emit(key)

    def set_active(self, key: str) -> None:
        btn = self._buttons.get(key)
        if btn is not None:
            btn.setChecked(True)
