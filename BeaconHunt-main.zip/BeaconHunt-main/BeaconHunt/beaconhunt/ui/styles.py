"""BeaconHunt — design tokens and Qt stylesheet.

Visual language (matches the reference mockups):

  * Dark navy sidebar (~210px wide) with teal active-state highlight.
  * Light gray content area with white rounded cards.
  * Teal accent (#0E7C86 / #14B8A6) for primary actions, links, the
    beacon-score donut, and active navigation.
  * Amber for "Review" / flagged, gray for "Insufficient evidence",
    green for "LOCAL ONLY" / "Detected" / privacy banner.
  * Status badges always carry a text label — color is never the only
    cue (accessibility).
"""
from __future__ import annotations

# ---- Color tokens --------------------------------------------------------
SIDEBAR_BG = "#0E1B2A"           # very dark navy
SIDEBAR_BG_GRADIENT_TO = "#16283C"
SIDEBAR_ACTIVE_BG = "#1C3247"
SIDEBAR_ACTIVE_BAR = "#14B8A6"   # teal left-edge bar
SIDEBAR_TEXT = "#B8C4CF"
SIDEBAR_TEXT_ACTIVE = "#FFFFFF"

CONTENT_BG = "#F1F3F6"
CARD_BG = "#FFFFFF"
CARD_BORDER = "#E2E8F0"

TEXT_PRIMARY = "#0F172A"
TEXT_SECONDARY = "#64748B"
TEXT_MUTED = "#94A3B8"

ACCENT_TEAL = "#0E7C86"
ACCENT_TEAL_BRIGHT = "#14B8A6"
ACCENT_TEAL_DARK = "#0E9384"     # primary button bg
TEAL_TINT = "#E6F4F3"
TEAL_TINT_LIGHT = "#E8F4F4"

GREEN_BG = "#DCFCE7"
GREEN_FG = "#15803D"
GREEN_BORDER = "#86EFAC"
GREEN_BANNER_BG = "#E7F5EE"

AMBER_BG = "#FEF3C7"
AMBER_FG = "#B45309"
AMBER_BORDER = "#FCD34D"

GRAY_BADGE_BG = "#F1F5F9"
GRAY_BADGE_FG = "#475569"
GRAY_BADGE_BORDER = "#E2E8F0"

BLUE_TINT = "#DBEAFE"

TABLE_HEADER_BG = "#F8FAFC"
TABLE_ROW_SEP = "#E2E8F0"


STATUS_BG = {
    "flagged": AMBER_BG,                # "Review" in the mockup
    "not_flagged": "#DBEAFE",
    "excluded": GRAY_BADGE_BG,
    "insufficient_evidence": GRAY_BADGE_BG,
}
STATUS_FG = {
    "flagged": AMBER_FG,
    "not_flagged": "#1E40AF",
    "excluded": GRAY_BADGE_FG,
    "insufficient_evidence": GRAY_BADGE_FG,
}
STATUS_BORDER = {
    "flagged": AMBER_BORDER,
    "not_flagged": "#93C5FD",
    "excluded": GRAY_BADGE_BORDER,
    "insufficient_evidence": GRAY_BADGE_BORDER,
}
STATUS_LABEL = {
    "flagged": "Review",
    "not_flagged": "Not flagged",
    "excluded": "Excluded",
    "insufficient_evidence": "Insufficient evidence",
}


def status_color(status: str) -> str:
    return STATUS_BG.get(status, "#FFFFFF")


def status_fg_color(status: str) -> str:
    return STATUS_FG.get(status, TEXT_PRIMARY)


# ---- QSS -----------------------------------------------------------------
QSS = f"""
* {{
    font-family: 'Inter', 'Segoe UI', 'Helvetica Neue', Arial, sans-serif;
    font-size: 10pt;
    color: {TEXT_PRIMARY};
}}
QMainWindow, QDialog {{ background: {CONTENT_BG}; }}

/* ---- Sidebar ---- */
QFrame#Sidebar {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 {SIDEBAR_BG}, stop:1 {SIDEBAR_BG_GRADIENT_TO});
    border-right: 1px solid #0A1422;
}}
QLabel#SidebarLogo {{
    color: {SIDEBAR_TEXT_ACTIVE};
    font-size: 16pt;
    font-weight: 800;
    padding: 18px 22px 12px 22px;
}}
QLabel#SidebarLogoTag {{
    color: {ACCENT_TEAL_BRIGHT};
    font-size: 8pt;
    font-weight: 700;
    letter-spacing: 2px;
    padding: 0 22px 18px 22px;
}}
QPushButton#NavButton {{
    background: transparent;
    color: {SIDEBAR_TEXT};
    border: none;
    border-left: 3px solid transparent;
    text-align: left;
    padding: 12px 22px 12px 19px;
    font-size: 10.5pt;
    font-weight: 500;
}}
QPushButton#NavButton:hover {{
    background: rgba(255,255,255,0.04);
    color: {SIDEBAR_TEXT_ACTIVE};
}}
QPushButton#NavButton:checked {{
    background: {SIDEBAR_ACTIVE_BG};
    border-left: 3px solid {SIDEBAR_ACTIVE_BAR};
    color: {SIDEBAR_TEXT_ACTIVE};
}}
QLabel#SidebarFooter {{
    color: #5B6B7A;
    font-size: 8pt;
    padding: 16px 22px;
}}

/* ---- Content area ---- */
QWidget#Content {{ background: {CONTENT_BG}; }}
QLabel#PageTitle {{
    color: {TEXT_PRIMARY};
    font-size: 20pt;
    font-weight: 800;
}}
QLabel#PageSubtitle {{
    color: {TEXT_SECONDARY};
    font-size: 10pt;
}}

/* ---- Cards ---- */
QFrame#Card {{
    background: {CARD_BG};
    border: 1px solid {CARD_BORDER};
    border-radius: 12px;
}}
QLabel#CardTitle {{
    color: {TEXT_PRIMARY};
    font-size: 11pt;
    font-weight: 700;
}}
QLabel#CardHint {{
    color: {TEXT_SECONDARY};
    font-size: 9pt;
}}
QLabel#CardLabel {{
    color: {TEXT_SECONDARY};
    font-size: 9pt;
    font-weight: 500;
}}
QLabel#CardValue {{
    color: {TEXT_PRIMARY};
    font-size: 14pt;
    font-weight: 800;
}}
QLabel#CardCaption {{
    color: {TEXT_SECONDARY};
    font-size: 8.5pt;
}}
QLabel#Muted {{ color: {TEXT_SECONDARY}; font-size: 9pt; }}
QLabel#TinyMuted {{ color: {TEXT_MUTED}; font-size: 8pt; }}

/* ---- KPI cards ---- */
QFrame#KpiCard {{
    background: {CARD_BG};
    border: 1px solid {CARD_BORDER};
    border-radius: 12px;
}}
QLabel#KpiTitle {{ color: {TEXT_SECONDARY}; font-size: 9pt; font-weight: 600; }}
QLabel#KpiValue {{ color: {TEXT_PRIMARY}; font-size: 22pt; font-weight: 800; }}
QLabel#KpiCaption {{ color: {TEXT_SECONDARY}; font-size: 8.5pt; }}
QLabel#KpiIconTeal {{
    background: {TEAL_TINT};
    color: {ACCENT_TEAL};
    border-radius: 10px;
    padding: 6px;
    font-size: 14pt;
    font-weight: 700;
    qproperty-alignment: AlignCenter;
}}
QLabel#KpiIconGreen {{
    background: {GREEN_BG};
    color: {GREEN_FG};
    border-radius: 10px;
    padding: 6px;
    font-size: 14pt;
    font-weight: 700;
    qproperty-alignment: AlignCenter;
}}
QLabel#KpiIconAmber {{
    background: {AMBER_BG};
    color: {AMBER_FG};
    border-radius: 10px;
    padding: 6px;
    font-size: 14pt;
    font-weight: 700;
    qproperty-alignment: AlignCenter;
}}

/* ---- Badges ---- */
QLabel#BadgeLocal {{
    background: {GREEN_BG};
    color: {GREEN_FG};
    border: 1px solid {GREEN_BORDER};
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 8.5pt;
    font-weight: 700;
    letter-spacing: 1px;
}}
QLabel#BadgeOffline {{
    background: {TEAL_TINT};
    color: {ACCENT_TEAL};
    border: 1px solid {ACCENT_TEAL_BRIGHT};
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 8.5pt;
    font-weight: 700;
    letter-spacing: 1px;
}}
QLabel#StatusBadge {{
    border-radius: 6px;
    padding: 3px 9px;
    font-size: 8.5pt;
    font-weight: 700;
}}
QLabel#ReviewBadge {{
    background: {AMBER_BG};
    color: {AMBER_FG};
    border: 1px solid {AMBER_BORDER};
    border-radius: 6px;
    padding: 3px 9px;
    font-size: 8.5pt;
    font-weight: 700;
}}
QLabel#NewBadge {{
    background: {GREEN_BG};
    color: {GREEN_FG};
    border: 1px solid {GREEN_BORDER};
    border-radius: 6px;
    padding: 3px 9px;
    font-size: 8.5pt;
    font-weight: 700;
}}
QLabel#DestChip {{
    background: {TEAL_TINT};
    color: {TEXT_PRIMARY};
    border: 1px solid {ACCENT_TEAL_BRIGHT};
    border-radius: 6px;
    padding: 3px 8px;
    font-size: 9pt;
    font-weight: 600;
}}

/* ---- Banners ---- */
QFrame#PrivacyBanner {{
    background: {GREEN_BANNER_BG};
    border: 1px solid {GREEN_BORDER};
    border-radius: 10px;
}}
QLabel#PrivacyText {{
    color: #14532D;
    font-size: 10pt;
    font-weight: 600;
}}
QLabel#PrivacySub {{
    color: #166534;
    font-size: 9pt;
}}
QFrame#InfoBanner {{
    background: {TEAL_TINT};
    border: 1px solid {ACCENT_TEAL_BRIGHT};
    border-radius: 10px;
}}
QLabel#InfoBannerText {{
    color: {ACCENT_TEAL};
    font-size: 10pt;
    font-weight: 600;
}}

/* ---- Buttons ---- */
QPushButton {{
    background: {ACCENT_TEAL_DARK};
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 18px;
    font-weight: 600;
    min-height: 18px;
}}
QPushButton:hover {{ background: {ACCENT_TEAL_BRIGHT}; }}
QPushButton:disabled {{ background: #9CA3AF; color: #F3F4F6; }}
QPushButton[secondary="true"] {{
    background: {CARD_BG};
    color: {TEXT_PRIMARY};
    border: 1px solid {CARD_BORDER};
}}
QPushButton[secondary="true"]:hover {{ background: #F9FAFB; border-color: #CBD5E1; }}
QPushButton[danger="true"] {{
    background: {CARD_BG};
    color: #B91C1C;
    border: 1px solid #FCA5A5;
}}
QPushButton[danger="true"]:hover {{ background: #FEF2F2; }}
QPushButton[outline="true"] {{
    background: {CARD_BG};
    color: {TEXT_PRIMARY};
    border: 1.5px solid {TEXT_PRIMARY};
    border-radius: 8px;
    padding: 6px 14px;
    font-weight: 600;
}}
QPushButton[outline="true"]:hover {{ background: #F3F4F6; }}

/* Segmented control */
QFrame#SegmentedTrack {{
    background: #E5E7EB;
    border-radius: 8px;
    padding: 3px;
}}
QPushButton#Segment {{
    background: transparent;
    color: {TEXT_SECONDARY};
    border: none;
    border-radius: 6px;
    padding: 6px 16px;
    font-weight: 600;
}}
QPushButton#Segment:checked {{
    background: white;
    color: {TEXT_PRIMARY};
    border: 1px solid {CARD_BORDER};
}}

/* ---- Inputs ---- */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
    background: {CARD_BG};
    border: 1px solid {CARD_BORDER};
    border-radius: 6px;
    padding: 6px 10px;
    selection-background-color: {ACCENT_TEAL_BRIGHT};
    selection-color: white;
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    border: 1px solid {ACCENT_TEAL_BRIGHT};
}}
QLineEdit#SearchInput {{
    padding-left: 28px;
    background: {CARD_BG};
    border: 1px solid {CARD_BORDER};
    border-radius: 8px;
}}
QLineEdit::placeholder {{ color: {TEXT_MUTED}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox::down-arrow {{
    image: none;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 5px solid {TEXT_SECONDARY};
    margin-right: 8px;
}}
QComboBox QAbstractItemView {{
    background: {CARD_BG};
    border: 1px solid {CARD_BORDER};
    border-radius: 4px;
    selection-background-color: {TEAL_TINT};
    selection-color: {TEXT_PRIMARY};
    outline: none;
}}

/* ---- Tables ---- */
QTableWidget {{
    background: {CARD_BG};
    alternate-background-color: #FAFBFC;
    gridline-color: transparent;
    border: none;
    selection-background-color: {TEAL_TINT};
    selection-color: {TEXT_PRIMARY};
}}
QTableWidget::item {{
    padding: 10px 12px;
    border-bottom: 1px solid {TABLE_ROW_SEP};
}}
QTableWidget::item:selected {{
    background: {TEAL_TINT};
}}
QHeaderView::section {{
    background: {TABLE_HEADER_BG};
    color: {TEXT_SECONDARY};
    padding: 10px 12px;
    border: none;
    border-bottom: 1px solid {CARD_BORDER};
    font-weight: 600;
    font-size: 9pt;
}}
QHeaderView::section:first {{ border-top-left-radius: 12px; }}
QHeaderView::section:last {{ border-top-right-radius: 12px; }}
QTableCornerButton::section {{ background: {TABLE_HEADER_BG}; border: none; }}

/* ---- Progress bar ---- */
QProgressBar {{
    background: #E2E8F0;
    border: none;
    border-radius: 3px;
    text-align: center;
    color: transparent;
    height: 6px;
}}
QProgressBar::chunk {{
    background: {ACCENT_TEAL_BRIGHT};
    border-radius: 3px;
}}

/* ---- Tabs ---- */
QTabWidget::pane {{ border: none; background: transparent; }}
QTabBar::tab {{
    background: transparent;
    color: {TEXT_SECONDARY};
    padding: 8px 16px;
    border: none;
    border-bottom: 2px solid transparent;
    font-weight: 600;
}}
QTabBar::tab:selected {{
    color: {TEXT_PRIMARY};
    border-bottom: 2px solid {ACCENT_TEAL_BRIGHT};
}}
QTabBar::tab:hover {{ color: {TEXT_PRIMARY}; }}

/* ---- Scrollbar ---- */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 0; }}
QScrollBar::handle:vertical {{ background: #CBD5E1; border-radius: 5px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #94A3B8; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 0; }}
QScrollBar::handle:horizontal {{ background: #CBD5E1; border-radius: 5px; min-width: 30px; }}

/* ---- Tooltip ---- */
QToolTip {{
    background: {TEXT_PRIMARY};
    color: white;
    border: none;
    padding: 6px 10px;
    border-radius: 4px;
}}

/* ---- Status bar (kept minimal, mostly hidden) ---- */
QStatusBar {{ background: transparent; color: {TEXT_SECONDARY}; border: none; }}
"""


def badge_qss(status: str) -> str:
    """Return inline QSS for a status badge QLabel."""
    bg = STATUS_BG.get(status, CARD_BG)
    fg = STATUS_FG.get(status, TEXT_PRIMARY)
    border = STATUS_BORDER.get(status, CARD_BORDER)
    return (
        f"background:{bg}; color:{fg}; border:1px solid {border}; "
        f"border-radius:6px; padding:3px 9px; "
        f"font-size:8.5pt; font-weight:700;"
    )


def status_label(status: str) -> str:
    return STATUS_LABEL.get(status, status)
