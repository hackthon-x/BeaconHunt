"""Destination Details page.

Layout matches the reference mockup:
  - Breadcrumb row (Results › destination) with REVIEW badge.
  - Summary row: huge destination address + "TEST-NET" tag on the left,
    beacon-score donut + "High confidence" pill on the right, with a
    metadata row (first seen, last seen, total connections) below.
  - Connection intervals chart card with jitter band and median dashed line.
  - Four metric cards with progress bars (interval regularity, jitter
    consistency, byte-size consistency, event support).
  - Evidence card: raw connection samples table with the metadata-only
    footer note.

The donut is drawn with a small QWidget subclass using QPainter; the
chart is matplotlib (QtAgg backend) with a styled look matching the
mockup (teal line + dot markers, semi-transparent teal jitter band,
gray dashed median line).
"""
from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QColor, QPainter, QPen, QBrush
from PySide6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QProgressBar,
    QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem, QTabWidget,
    QVBoxLayout, QWidget,
)

from ..analysis.scoring import DestinationResult, ComponentScore
from .styles import (
    ACCENT_TEAL, ACCENT_TEAL_BRIGHT, AMBER_BG, AMBER_FG, AMBER_BORDER,
    GREEN_BG, GREEN_FG, TEXT_PRIMARY, TEXT_SECONDARY, TEXT_MUTED,
    CARD_BG, CARD_BORDER, TEAL_TINT,
)

# Matplotlib QtAgg backend — must happen before pyplot import.
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas


class _ScoreDonut(QWidget):
    """A circular progress ring showing the beacon score out of 100."""

    def __init__(self, score: float, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._score = max(0.0, min(100.0, float(score)))
        self.setFixedSize(96, 96)

    def paintEvent(self, event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(8, 8, self.width() - 16, self.height() - 16)
        # Background ring (light gray).
        bg = QPen(QColor("#E2E8F0"), 8)
        bg.setCapStyle(Qt.RoundCap)
        p.setPen(bg)
        p.drawArc(rect, 0, 360 * 16)
        # Foreground arc (teal) proportional to score.
        fg = QPen(QColor(ACCENT_TEAL_BRIGHT), 8)
        fg.setCapStyle(Qt.RoundCap)
        p.setPen(fg)
        # Qt angles are in 1/16 degree, 0 at 3 o'clock, counterclockwise.
        span = int(self._score / 100.0 * 360 * 16)
        p.drawArc(rect, 90 * 16, -span)
        p.setPen(QColor(TEXT_PRIMARY))
        font = p.font()
        font.setPointSize(16)
        font.setBold(True)
        p.setFont(font)
        p.drawText(rect, Qt.AlignCenter, f"{self._score:.0f}")
        p.end()


class _MetricCard(QFrame):
    """One of the four score-component cards with a progress bar."""

    def __init__(self, icon: str, label: str, score: Optional[float], reason: str = "") -> None:
        super().__init__()
        self.setObjectName("KpiCard")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(6)
        head = QHBoxLayout()
        head.setSpacing(8)
        ic = QLabel(icon)
        ic.setStyleSheet(
            f"background:{TEAL_TINT}; color:{ACCENT_TEAL}; border-radius:8px; "
            f"padding:4px 6px; font-weight:800; min-width:24px; min-height:24px;"
        )
        ic.setAlignment(Qt.AlignCenter)
        head.addWidget(ic)
        t = QLabel(label)
        t.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt; font-weight:600;")
        head.addWidget(t)
        head.addStretch()
        lay.addLayout(head)
        v = QLabel(f"{score:.0f}" if score is not None else "n/a")
        v.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:20pt; font-weight:800;"
        )
        lay.addWidget(v)
        bar = QProgressBar()
        bar.setRange(0, 100)
        if score is not None:
            bar.setValue(int(score))
        else:
            bar.setValue(0)
        bar.setTextVisible(False)
        bar.setFixedHeight(6)
        lay.addWidget(bar)
        if reason:
            r = QLabel(reason)
            r.setStyleSheet(f"color:{TEXT_MUTED}; font-size:8pt;")
            r.setWordWrap(True)
            lay.addWidget(r)


class _EvidenceTable(QTableWidget):
    """Raw connection samples table."""

    def __init__(self) -> None:
        super().__init__()
        self.setColumnCount(4)
        self.setHorizontalHeaderLabels(["Timestamp", "Source", "Bytes", "Destination"])
        self.verticalHeader().setVisible(False)
        self.setEditTriggers(QTableWidget.NoEditTriggers)
        self.setAlternatingRowColors(True)
        self.setShowGrid(False)
        h = self.horizontalHeader()
        h.setHighlightSections(False)
        h.setSectionResizeMode(0, QHeaderView.Stretch)
        h.setSectionResizeMode(1, QHeaderView.Stretch)
        h.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.Stretch)


class DetailsPanel(QWidget):
    """The redesigned Destination Details page."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("Content")
        self._current: Optional[DestinationResult] = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(32, 28, 32, 28)
        outer.setSpacing(18)

        # --- Breadcrumb row ---
        crumb = QHBoxLayout()
        crumb.setSpacing(8)
        c1 = QLabel("Results")
        c1.setStyleSheet(f"color:{ACCENT_TEAL}; font-size:10pt; font-weight:600;")
        crumb.addWidget(c1)
        sep = QLabel("›")
        sep.setStyleSheet(f"color:{TEXT_MUTED}; font-size:10pt;")
        crumb.addWidget(sep)
        self.lbl_dest_breadcrumb = QLabel("—")
        self.lbl_dest_breadcrumb.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:10pt; font-weight:600;"
        )
        crumb.addWidget(self.lbl_dest_breadcrumb)
        crumb.addStretch()
        self.review_badge = QLabel("◉ REVIEW")
        self.review_badge.setStyleSheet(
            f"background:#F97316; color:white; border-radius:6px; "
            f"padding:3px 9px; font-size:8.5pt; font-weight:700;"
        )
        self.review_badge.setVisible(False)
        crumb.addWidget(self.review_badge)
        synthetic_note = QLabel("ⓘ  Synthetic analysis data")
        synthetic_note.setStyleSheet(
            f"color:{TEXT_SECONDARY}; font-size:9pt; padding-left:8px;"
        )
        crumb.addWidget(synthetic_note)
        outer.addLayout(crumb)

        # --- Summary card ---
        summary = QFrame()
        summary.setObjectName("Card")
        slay = QHBoxLayout(summary)
        slay.setContentsMargins(24, 20, 24, 20)
        slay.setSpacing(24)

        # Left: destination block.
        left = QVBoxLayout()
        left.setSpacing(4)
        dlbl = QLabel("Destination")
        dlbl.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt; font-weight:600;")
        left.addWidget(dlbl)
        self.lbl_dest = QLabel("—")
        self.lbl_dest.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:22pt; font-weight:800;"
        )
        left.addWidget(self.lbl_dest)
        self.lbl_tag = QLabel("")
        self.lbl_tag.setStyleSheet(
            f"color:{TEXT_MUTED}; font-size:8pt; font-weight:700; letter-spacing:1px;"
        )
        left.addWidget(self.lbl_tag)
        slay.addLayout(left, 1)

        # Divider.
        div = QFrame()
        div.setFrameShape(QFrame.VLine)
        div.setStyleSheet(f"color:{CARD_BORDER};")
        div.setFixedWidth(1)
        slay.addWidget(div)

        # Right: score donut + confidence.
        right = QVBoxLayout()
        right.setSpacing(4)
        s_lbl = QLabel("Beacon Score")
        s_lbl.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt; font-weight:600;")
        right.addWidget(s_lbl)
        right.setAlignment(s_lbl, Qt.AlignCenter)
        score_row = QHBoxLayout()
        score_row.setSpacing(10)
        self.donut = _ScoreDonut(0)
        score_row.addWidget(self.donut)
        score_col = QVBoxLayout()
        score_col.setSpacing(2)
        self.lbl_score = QLabel("0 / 100")
        self.lbl_score.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:22pt; font-weight:800;"
        )
        score_col.addWidget(self.lbl_score)
        self.confidence_badge = QLabel("● High confidence")
        self.confidence_badge.setStyleSheet(
            f"background:{GREEN_BG}; color:{GREEN_FG}; border-radius:6px; "
            f"padding:3px 9px; font-size:8.5pt; font-weight:700;"
        )
        score_col.addWidget(self.confidence_badge)
        score_row.addLayout(score_col)
        right.addLayout(score_row)
        slay.addLayout(right, 1)

        outer.addWidget(summary)

        # --- Metadata line ---
        meta_row = QHBoxLayout()
        meta_row.setSpacing(24)
        self.lbl_first_seen = QLabel("First seen  —")
        self.lbl_first_seen.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        meta_row.addWidget(self.lbl_first_seen)
        self.lbl_last_seen = QLabel("Last seen  —")
        self.lbl_last_seen.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        meta_row.addWidget(self.lbl_last_seen)
        self.lbl_total_conn = QLabel("Total connections  —")
        self.lbl_total_conn.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        meta_row.addWidget(self.lbl_total_conn)
        meta_row.addStretch()
        outer.addLayout(meta_row)

        # --- Charts card ---
        chart_card = QFrame()
        chart_card.setObjectName("Card")
        cclay = QVBoxLayout(chart_card)
        cclay.setContentsMargins(20, 18, 20, 18)
        cclay.setSpacing(10)
        chead = QHBoxLayout()
        ctitle = QLabel("Connection intervals")
        ctitle.setObjectName("CardTitle")
        chead.addWidget(ctitle)
        chead.addStretch()
        cr_label = QLabel("Time range")
        cr_label.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        chead.addWidget(cr_label)
        cr_value = QLabel("All data")
        cr_value.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:9pt; font-weight:600; padding-left:6px;"
        )
        chead.addWidget(cr_value)
        cclay.addLayout(chead)
        self.fig = Figure(figsize=(7, 3.2))
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setFixedHeight(220)
        cclay.addWidget(self.canvas)
        self.plot_note = QLabel(
            "Charts show observed intervals and a fitted jitter band. "
            "A chart alone does not confirm malicious activity."
        )
        self.plot_note.setStyleSheet(f"color:{TEXT_MUTED}; font-size:8pt;")
        cclay.addWidget(self.plot_note)
        outer.addWidget(chart_card)

        # --- Metric cards row ---
        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(12)
        self.metric_cards: List[_MetricCard] = []
        for icon, label in [
            ("↗", "Interval regularity"),
            ("∿", "Jitter consistency"),
            ("☰", "Byte-size consistency"),
            ("▦", "Event support"),
        ]:
            card = _MetricCard(icon, label, None)
            self.metric_cards.append(card)
            metrics_row.addWidget(card, 1)
        outer.addLayout(metrics_row)

        # --- Evidence card ---
        ev_card = QFrame()
        ev_card.setObjectName("Card")
        eclay = QVBoxLayout(ev_card)
        eclay.setContentsMargins(20, 18, 20, 18)
        eclay.setSpacing(10)
        ehead = QHBoxLayout()
        etitle = QLabel("Evidence")
        etitle.setObjectName("CardTitle")
        ehead.addWidget(etitle)
        esub = QLabel("Raw connection samples leading to this destination.")
        esub.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        ehead.addWidget(esub)
        ehead.addStretch()
        eclay.addLayout(ehead)
        self.evidence_table = _EvidenceTable()
        eclay.addWidget(self.evidence_table)
        footer_note = QLabel(
            "ⓘ  Synthetic lab data  •  Metadata only  •  Not proof of compromise."
        )
        footer_note.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:8.5pt;")
        eclay.addWidget(footer_note)
        outer.addWidget(ev_card, 1)

        outer.addStretch()

    # ------------------------------------------------------------------ load
    def set_result(self, r: DestinationResult) -> None:
        self._current = r
        self.lbl_dest_breadcrumb.setText(f"{r.destination_address}:{r.destination_port}")
        self.lbl_dest.setText(f"{r.destination_address}:{r.destination_port}")
        # TEST-NET hint: if the address starts with a reserved range, show it.
        tag = ""
        if r.destination_address.startswith("203.0.113."):
            tag = "TEST-NET-3"
        elif r.destination_address.startswith("198.51.100."):
            tag = "TEST-NET-2"
        elif r.destination_address.startswith("192.0.2."):
            tag = "TEST-NET-1"
        elif ":" in r.destination_address:
            tag = "IPv6"
        self.lbl_tag.setText(tag)

        # Score block.
        self.donut._score = float(r.final_score)
        self.donut.update()
        self.lbl_score.setText(f"{r.final_score:.0f} / 100")
        if r.final_score >= 70:
            self.confidence_badge.setText("● High confidence")
            self.confidence_badge.setStyleSheet(
                f"background:{GREEN_BG}; color:{GREEN_FG}; border-radius:6px; "
                f"padding:3px 9px; font-size:8.5pt; font-weight:700;"
            )
        else:
            self.confidence_badge.setText("● Low confidence")
            self.confidence_badge.setStyleSheet(
                f"background:#F1F5F9; color:#475569; border-radius:6px; "
                f"padding:3px 9px; font-size:8.5pt; font-weight:700;"
            )
        self.review_badge.setVisible(r.status == "flagged")

        # Metadata line.
        self.lbl_first_seen.setText(
            f"First seen  {r.first_seen}" if r.first_seen else "First seen  —")
        self.lbl_last_seen.setText(
            f"Last seen  {r.last_seen}" if r.last_seen else "Last seen  —")
        self.lbl_total_conn.setText(f"Total connections  {r.event_count:,}")

        # Metric cards: order matches the spec — interval regularity,
        # jitter consistency, byte-size consistency, event support.
        names = ["interval_regularity", "jitter_consistency",
                 "byte_size_consistency", "connection_count"]
        comp_by_name = {c.name: c for c in r.components}
        for i, name in enumerate(names):
            c = comp_by_name.get(name)
            if c is not None:
                self.metric_cards[i].findChild(QLabel, None)
                # Update value label and progress bar.
                value_label = self.metric_cards[i].findChildren(QLabel)[1]
                value_label.setText(f"{c.raw_score:.0f}" if c.raw_score is not None else "n/a")
                bar = self.metric_cards[i].findChild(QProgressBar)
                if bar is not None:
                    bar.setValue(int(c.raw_score) if c.raw_score is not None else 0)
                # Update reason label.
                labels = self.metric_cards[i].findChildren(QLabel)
                if len(labels) >= 3:
                    labels[2].setText(c.reason)
            else:
                labels = self.metric_cards[i].findChildren(QLabel)
                if len(labels) >= 2:
                    labels[1].setText("n/a")
                bar = self.metric_cards[i].findChild(QProgressBar)
                if bar is not None:
                    bar.setValue(0)

        # Evidence table.
        self._populate_evidence(r)
        # Chart.
        self._draw_plot(r)

    def _populate_evidence(self, r: DestinationResult) -> None:
        if r.group is None:
            self.evidence_table.setRowCount(0)
            return
        events = r.group.events
        # Show newest first (matches the mockup ordering).
        events_sorted = sorted(events, key=lambda e: e.timestamp_utc, reverse=True)
        self.evidence_table.setRowCount(len(events_sorted))
        for i, e in enumerate(events_sorted):
            cells = [
                e.timestamp_utc.strftime("%Y-%m-%d %H:%M:%S"),
                e.source_address,
                f"{e.byte_size:,}" if e.byte_size is not None else "—",
                e.destination_address,
            ]
            for j, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if j == 2:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.evidence_table.setItem(i, j, item)

    def _draw_plot(self, r: DestinationResult) -> None:
        self.fig.clear()
        if r.group is None or r.group.interval_count < 1:
            ax = self.fig.add_subplot(111)
            ax.text(0.5, 0.5, "No intervals to plot (need ≥ 2 events)",
                    ha="center", va="center", transform=ax.transAxes,
                    color=TEXT_MUTED)
            ax.set_axis_off()
            self.canvas.draw()
            return
        intervals = r.group.intervals_seconds
        ax = self.fig.add_subplot(111)
        # Plot interval line with dot markers.
        ax.plot(range(1, len(intervals) + 1), intervals,
                marker="o", markersize=5, linewidth=1.5,
                color=ACCENT_TEAL_BRIGHT, markerfacecolor=ACCENT_TEAL_BRIGHT,
                markeredgecolor="white", label="Interval")
        # Jitter band overlay.
        if r.stats is not None and r.stats.base_period and r.stats.jitter_band_low and r.stats.jitter_band_high:
            ax.axhspan(r.stats.jitter_band_low, r.stats.jitter_band_high,
                       color=ACCENT_TEAL_BRIGHT, alpha=0.15, label="Jitter band")
            ax.axhline(r.stats.base_period, color="#94A3B8", linestyle="--",
                       linewidth=1.2, label=f"Median ({r.stats.base_period:.1f} s)")
        ax.set_xlabel("Interval index", color=TEXT_SECONDARY, fontsize=9)
        ax.set_ylabel("Interval (seconds)", color=TEXT_SECONDARY, fontsize=9)
        ax.tick_params(colors=TEXT_SECONDARY, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color(CARD_BORDER)
        ax.grid(True, color="#F1F5F9", linewidth=0.8)
        ax.set_axisbelow(True)
        # Legend in a bordered box (top-right inside the plot).
        leg = ax.legend(loc="upper right", fontsize=8, framealpha=1.0,
                        edgecolor=CARD_BORDER, facecolor="white")
        if leg:
            leg.get_frame().set_linewidth(0.8)
        self.fig.tight_layout(pad=0.5)
        self.canvas.draw()
