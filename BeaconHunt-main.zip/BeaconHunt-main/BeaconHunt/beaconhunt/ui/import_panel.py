"""Analyze File / Import page.

Layout matches the reference mockup:
  - Header with "Analyze a File" title and OFFLINE ANALYSIS badge.
  - File picker card (file icon tile + name + metadata + Select File).
  - Green privacy banner ("Analysis runs locally. Your file is not uploaded.").
  - File Format card with segmented control + 4 parameter cards.
  - Exclusions and Baseline card.
  - CSV Field Mapping card (6 fields with Detected status).
  - Footer with Analyze Offline (teal) + Cancel.
"""
from __future__ import annotations

import os
from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QFrame, QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QSpinBox, QVBoxLayout, QWidget,
)

from ..config.settings import AnalysisConfig
from ..parsers.base import BaseParser
from ..parsers.csv_parser import CANONICAL_FIELDS, ColumnMapping, HEADER_ALIASES
from ..parsers.text_parser import NAMED_FORMATS
from .styles import (
    ACCENT_TEAL, GREEN_FG, GREEN_BG, TEXT_PRIMARY, TEXT_SECONDARY,
)


class _Card(QFrame):
    """White rounded card container with a title row + body."""

    def __init__(self, title: str, hint: str = "") -> None:
        super().__init__()
        self.setObjectName("Card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(14)
        head = QHBoxLayout()
        head.setSpacing(10)
        t = QLabel(title)
        t.setObjectName("CardTitle")
        head.addWidget(t)
        head.addStretch()
        if hint:
            h = QLabel(hint)
            h.setObjectName("CardHint")
            head.addWidget(h)
        lay.addLayout(head)
        self.body = QVBoxLayout()
        self.body.setSpacing(10)
        lay.addLayout(self.body)


class _ParamCard(QFrame):
    """One of the four parameter cards in the File Format card."""

    def __init__(self, icon: str, label: str, value: str, desc: str) -> None:
        super().__init__()
        self.setObjectName("KpiCard")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(6)
        ih = QHBoxLayout()
        ic = QLabel(icon)
        ic.setStyleSheet(
            f"background:{GREEN_BG}; color:{GREEN_FG}; border-radius:8px; "
            f"padding:4px 6px; font-weight:800; min-width:24px; min-height:24px;"
        )
        ic.setAlignment(Qt.AlignCenter)
        ih.addWidget(ic)
        l = QLabel(label)
        l.setObjectName("CardLabel")
        ih.addWidget(l)
        ih.addStretch()
        lay.addLayout(ih)
        v = QLabel(value)
        v.setObjectName("CardValue")
        lay.addWidget(v)
        d = QLabel(desc)
        d.setObjectName("CardCaption")
        d.setWordWrap(True)
        lay.addWidget(d)


class ImportPanel(QWidget):
    """The redesigned Analyze File page."""

    start_analysis = Signal(dict)
    cancel_analysis = Signal()
    file_changed = Signal(str)

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("Content")
        self._path: Optional[str] = None
        self._input_type: str = "unknown"
        self._detected_header: list = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(32, 28, 32, 28)
        outer.setSpacing(18)

        # --- Header ---
        head = QHBoxLayout()
        head.setSpacing(12)
        title_col = QVBoxLayout()
        title_col.setSpacing(4)
        title = QLabel("Analyze a File")
        title.setObjectName("PageTitle")
        title_col.addWidget(title)
        sub = QLabel("Import a capture file and configure analysis settings to detect potential beacon behavior.")
        sub.setObjectName("PageSubtitle")
        sub.setWordWrap(True)
        title_col.addWidget(sub)
        head.addLayout(title_col)
        head.addStretch()
        badge = QLabel("◉ OFFLINE ANALYSIS")
        badge.setObjectName("BadgeOffline")
        head.addWidget(badge)
        outer.addLayout(head)

        # --- File picker card ---
        picker = _Card("File", "Choose a PCAP, CSV, or plain-text log to analyze.")
        body = QHBoxLayout()
        body.setSpacing(16)
        # Left: icon tile.
        tile = QLabel("▤")
        tile.setStyleSheet(
            f"background:#DBEAFE; color:#1E40AF; border-radius:10px; "
            f"padding:14px; font-size:24pt; font-weight:800; min-width:64px; min-height:64px;"
        )
        tile.setAlignment(Qt.AlignCenter)
        body.addWidget(tile)
        # Middle: filename + metadata.
        meta_col = QVBoxLayout()
        meta_col.setSpacing(4)
        self.lbl_filename = QLabel("No file selected")
        self.lbl_filename.setStyleSheet(
            f"color:{TEXT_PRIMARY}; font-size:13pt; font-weight:700;"
        )
        meta_col.addWidget(self.lbl_filename)
        self.lbl_meta = QLabel("Drop your file here, or click to browse")
        self.lbl_meta.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        meta_col.addWidget(self.lbl_meta)
        body.addLayout(meta_col, 1)
        # Right: Select File button.
        self.btn_pick = QPushButton("Select File")
        self.btn_pick.setProperty("outline", True)
        self.btn_pick.setMinimumWidth(120)
        self.btn_pick.clicked.connect(self._pick_file)
        body.addWidget(self.btn_pick)
        picker.body.addLayout(body)
        outer.addWidget(picker)

        # --- Privacy banner ---
        banner = QFrame()
        banner.setObjectName("PrivacyBanner")
        blay = QHBoxLayout(banner)
        blay.setContentsMargins(16, 12, 16, 12)
        blay.setSpacing(12)
        shield = QLabel("✓")
        shield.setStyleSheet(
            f"background:{GREEN_FG}; color:white; border-radius:12px; "
            f"padding:4px 8px; font-weight:800; min-width:24px; min-height:24px;"
        )
        shield.setAlignment(Qt.AlignCenter)
        blay.addWidget(shield)
        btext = QVBoxLayout()
        btext.setSpacing(0)
        b1 = QLabel("Analysis runs locally.")
        b1.setObjectName("PrivacyText")
        btext.addWidget(b1)
        b2 = QLabel("Your file is not uploaded.")
        b2.setObjectName("PrivacySub")
        btext.addWidget(b2)
        blay.addLayout(btext)
        blay.addStretch()
        # Right-side privacy icons.
        right_icons = QLabel("🌐  🔒  ⛁")
        right_icons.setStyleSheet(
            f"color:{GREEN_FG}; font-size:11pt; padding-left:20px;"
        )
        blay.addWidget(right_icons)
        outer.addWidget(banner)

        # --- File Format card ---
        fmt_card = _Card("File Format", "Select the format of your imported file.")
        # Segmented control.
        seg_row = QHBoxLayout()
        seg_row.setSpacing(8)
        track = QFrame()
        track.setObjectName("SegmentedTrack")
        track_lay = QHBoxLayout(track)
        track_lay.setContentsMargins(3, 3, 3, 3)
        track_lay.setSpacing(3)
        self.seg_group = QButtonGroup(self)
        self.seg_group.setExclusive(True)
        for label in ("PCAP / PCAPNG", "CSV", "Plain Text"):
            btn = QPushButton(label)
            btn.setObjectName("Segment")
            btn.setCheckable(True)
            self.seg_group.addButton(btn)
            track_lay.addWidget(btn)
        self.seg_buttons = list(self.seg_group.buttons())
        self.seg_buttons[0].setChecked(True)
        seg_row.addWidget(track)
        seg_row.addStretch()
        fmt_card.body.addLayout(seg_row)

        # 4 parameter cards in a row.
        params_row = QHBoxLayout()
        params_row.setSpacing(12)
        self.card_min_events = _ParamCard("▽", "Minimum events", "5",
                                           "Minimum events required to flag a beacon.")
        self.card_jitter = _ParamCard("∿", "Jitter tolerance", "20%",
                                       "Allowable variation in inter-event timing.")
        self.card_threshold = _ParamCard("◆", "Score threshold", "70",
                                          "Minimum confidence score for detection.")
        self.card_grouping = _ParamCard("⊞", "Group by", "Dest + Port",
                                         "Group events by destination and port pairs.")
        for c in (self.card_min_events, self.card_jitter,
                  self.card_threshold, self.card_grouping):
            params_row.addWidget(c, 1)
        fmt_card.body.addLayout(params_row)

        # Detailed editable settings (collapsible-style: always visible here).
        details_grid = QGridLayout()
        details_grid.setSpacing(8)
        labels_and_widgets = []

        self.sp_min_events = QSpinBox()
        self.sp_min_events.setRange(2, 10000)
        self.sp_min_events.setValue(AnalysisConfig().min_events)
        self.sp_min_events.valueChanged.connect(self._sync_param_cards)
        self.sp_min_events.setToolTip(
            "Minimum number of connection events a destination must have "
            "to be eligible for flagging. Groups below this threshold are "
            "always shown as 'Insufficient evidence' and never flagged. "
            "Default: 5."
        )
        labels_and_widgets.append(("Minimum event count", self.sp_min_events))

        self.sp_threshold = QDoubleSpinBox()
        self.sp_threshold.setRange(0, 100)
        self.sp_threshold.setSingleStep(1)
        self.sp_threshold.setDecimals(1)
        self.sp_threshold.setValue(AnalysisConfig().score_threshold)
        self.sp_threshold.valueChanged.connect(self._sync_param_cards)
        self.sp_threshold.setToolTip(
            "Final regularity score (0-100) required for a destination to be "
            "labeled 'Review'. Default: 70."
        )
        labels_and_widgets.append(("Beacon score threshold", self.sp_threshold))

        self.sp_jitter = QDoubleSpinBox()
        self.sp_jitter.setRange(0, 100)
        self.sp_jitter.setSingleStep(1)
        self.sp_jitter.setDecimals(1)
        self.sp_jitter.setValue(AnalysisConfig().jitter_percent)
        self.sp_jitter.setSuffix(" %")
        self.sp_jitter.valueChanged.connect(self._sync_param_cards)
        self.sp_jitter.setToolTip(
            "Jitter tolerance percentage. Intervals within "
            "base_period × (1 ± jitter/100) count toward the jitter-band "
            "fit percentage. Default: 20%."
        )
        labels_and_widgets.append(("Jitter tolerance", self.sp_jitter))

        self.sp_udp_timeout = QDoubleSpinBox()
        self.sp_udp_timeout.setRange(1, 65535)
        self.sp_udp_timeout.setSingleStep(1)
        self.sp_udp_timeout.setDecimals(1)
        self.sp_udp_timeout.setValue(AnalysisConfig().udp_idle_timeout)
        self.sp_udp_timeout.setSuffix(" s")
        self.sp_udp_timeout.setToolTip(
            "UDP idle timeout in seconds. A new UDP pseudo-flow event is "
            "recorded when the gap since the last packet exceeds this. "
            "Default: 120s."
        )
        labels_and_widgets.append(("UDP idle timeout", self.sp_udp_timeout))

        self.cmb_grouping = QComboBox()
        self.cmb_grouping.addItem("Destination + Port + Protocol", "dest_port_protocol")
        self.cmb_grouping.addItem("Destination + Port", "dest_port")
        self.cmb_grouping.addItem("Destination only", "dest_only")
        self.cmb_grouping.currentIndexChanged.connect(self._sync_param_cards)
        self.cmb_grouping.setToolTip(
            "How connection events are grouped into destinations. Default "
            "(dest + port + protocol) is the most conservative."
        )
        labels_and_widgets.append(("Grouping policy", self.cmb_grouping))

        self.cmb_tcp_policy = QComboBox()
        self.cmb_tcp_policy.addItem("SYN without ACK", "syn_no_ack")
        self.cmb_tcp_policy.addItem("First packet seen", "first_seen")
        self.cmb_tcp_policy.setToolTip(
            "TCP event policy. 'SYN without ACK' records a connection event "
            "only on the initiating SYN. 'First packet seen' is a fallback "
            "heuristic for captures that started mid-flow."
        )
        labels_and_widgets.append(("TCP event policy", self.cmb_tcp_policy))

        self.cmb_byte_source = QComboBox()
        self.cmb_byte_source.addItem("Captured frame length", "captured")
        self.cmb_byte_source.addItem("Original wire length", "wire")
        self.cmb_byte_source.addItem("Reported payload length", "reported")
        self.cmb_byte_source.setToolTip(
            "Which byte-size measure to use for PCAP inputs."
        )
        labels_and_widgets.append(("Byte-size source", self.cmb_byte_source))

        self.chk_population = QCheckBox("Population stddev (vs sample)")
        self.chk_population.setChecked(True)
        self.chk_population.setToolTip(
            "Population stddev treats intervals as the complete observed "
            "population. Sample stddev treats them as a sample."
        )
        labels_and_widgets.append(("", self.chk_population))

        self.chk_ascii_hist = QCheckBox("Include ASCII histogram in text report")
        self.chk_ascii_hist.setChecked(True)
        labels_and_widgets.append(("", self.chk_ascii_hist))

        for i, (label, w) in enumerate(labels_and_widgets):
            r = i // 2
            c = i % 2
            if label:
                lbl = QLabel(label)
                lbl.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
                details_grid.addWidget(lbl, r, c * 2)
                details_grid.addWidget(w, r, c * 2 + 1)
            else:
                details_grid.addWidget(w, r, c * 2, 1, 2)
        fmt_card.body.addLayout(details_grid)
        outer.addWidget(fmt_card)

        # --- Exclusions and Baseline card ---
        opt_card = _Card("Exclusions and Baseline",
                         "Optional: reduce noise and improve accuracy.")
        # Exclusion row.
        excl_row = QHBoxLayout()
        excl_row.setSpacing(10)
        self.btn_excl = QPushButton("⊙  Choose exclusion list")
        self.btn_excl.setProperty("outline", True)
        self.btn_excl.clicked.connect(self._pick_excl)
        excl_row.addWidget(self.btn_excl)
        self.lbl_excl = QLabel("No exclusion list selected")
        self.lbl_excl.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        excl_row.addWidget(self.lbl_excl, 1)
        opt_card.body.addLayout(excl_row)
        # Baseline row.
        base_row = QHBoxLayout()
        base_row.setSpacing(10)
        self.btn_base = QPushButton("⊞  Compare baseline")
        self.btn_base.setProperty("outline", True)
        self.btn_base.clicked.connect(self._pick_base)
        base_row.addWidget(self.btn_base)
        self.lbl_base = QLabel("No baseline selected")
        self.lbl_base.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        base_row.addWidget(self.lbl_base, 1)
        opt_card.body.addLayout(base_row)
        # Keep hidden line edits for the actual paths (used by _build_payload).
        self.ed_excl = QLineEdit()
        self.ed_excl.setVisible(False)
        self.ed_base = QLineEdit()
        self.ed_base.setVisible(False)
        opt_card.body.addWidget(self.ed_excl)
        opt_card.body.addWidget(self.ed_base)
        outer.addWidget(opt_card)

        # --- CSV Field Mapping card ---
        self.csv_card = _Card("CSV Field Mapping",
                              "Map your CSV columns to the expected fields.")
        grid = QGridLayout()
        grid.setSpacing(10)
        self.csv_mapping_inputs = {}
        self.csv_status_labels = {}
        labels = {
            "timestamp": "Timestamp",
            "source": "Source",
            "destination": "Destination",
            "destination_port": "Port",
            "protocol": "Protocol",
            "bytes": "Bytes",
        }
        for i, field in enumerate(CANONICAL_FIELDS):
            r = i // 3
            c = i % 3
            col = QVBoxLayout()
            col.setSpacing(4)
            lh = QHBoxLayout()
            pin = QLabel("◎")
            pin.setStyleSheet(
                f"color:{ACCENT_TEAL}; font-size:9pt; font-weight:700;"
            )
            lh.addWidget(pin)
            lbl = QLabel(labels[field])
            lbl.setStyleSheet(f"color:{TEXT_PRIMARY}; font-size:9pt; font-weight:600;")
            lh.addWidget(lbl)
            lh.addStretch()
            col.addLayout(lh)
            combo = QComboBox()
            combo.addItem("(auto-detect)", None)
            combo.addItem("(none)", "")
            combo.currentIndexChanged.connect(lambda _=0, f=field: self._update_csv_status(f))
            self.csv_mapping_inputs[field] = combo
            col.addWidget(combo)
            status = QLabel("—")
            status.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:8pt;")
            self.csv_status_labels[field] = status
            col.addWidget(status)
            wrap = QWidget()
            wrap.setLayout(col)
            grid.addWidget(wrap, r, c)
        self.csv_card.body.addLayout(grid)
        outer.addWidget(self.csv_card)

        # --- Text format selector (shown only when Plain Text is active) ---
        self.txt_card = _Card("Plain-Text Log Format",
                              "Pick a documented format or supply a custom regex.")
        trow = QHBoxLayout()
        trow.setSpacing(10)
        trow.addWidget(QLabel("Named format:"))
        self.txt_format = QComboBox()
        for name in NAMED_FORMATS:
            self.txt_format.addItem(name, name)
        self.txt_format.addItem("(custom regex)", "custom")
        trow.addWidget(self.txt_format, 1)
        self.txt_card.body.addLayout(trow)
        rrow = QHBoxLayout()
        rrow.setSpacing(10)
        rrow.addWidget(QLabel("Custom regex:"))
        self.txt_regex = QLineEdit()
        self.txt_regex.setPlaceholderText(
            r"e.g. (?P<ts>\S+)\s+SRC=(?P<src>\S+)\s+DST=(?P<dst>\S+)..."
        )
        rrow.addWidget(self.txt_regex, 1)
        self.txt_card.body.addLayout(rrow)
        outer.addWidget(self.txt_card)
        self.txt_card.setVisible(False)

        # --- Footer action bar ---
        footer = QHBoxLayout()
        footer.addStretch()
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setProperty("secondary", True)
        self.btn_cancel.setMinimumWidth(110)
        self.btn_cancel.clicked.connect(self.cancel_analysis.emit)
        footer.addWidget(self.btn_cancel)
        self.btn_analyze = QPushButton("◉  Analyze Offline")
        self.btn_analyze.setMinimumWidth(160)
        self.btn_analyze.setEnabled(False)
        self.btn_analyze.clicked.connect(self._emit_start)
        footer.addWidget(self.btn_analyze)
        outer.addLayout(footer)

        outer.addStretch()

        # Sync segment buttons to file type changes.
        self.seg_group.buttonToggled.connect(self._on_segment_toggled)

    # ------------------------------------------------------------------ slots
    def _on_segment_toggled(self, btn, checked) -> None:
        if not checked:
            return
        # Show / hide option cards based on selected segment.
        is_csv = btn.text() == "CSV"
        is_text = btn.text() == "Plain Text"
        self.csv_card.setVisible(is_csv)
        self.txt_card.setVisible(is_text)
        # Also reflect the chosen type back to _input_type so payload is right.
        if self._path:
            mapping = {"PCAP / PCAPNG": "pcap", "CSV": "csv", "Plain Text": "text"}
            self._input_type = mapping.get(btn.text(), self._input_type)

    def _pick_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open PCAP / Log", "",
            "PCAP files (*.pcap *.pcapng *.cap);;"
            "CSV/TSV (*.csv *.tsv);;"
            "Text logs (*.txt *.log);;"
            "All files (*.*)",
        )
        if path:
            self.set_path(path)

    def _pick_excl(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open exclusion list", "", "Text files (*.txt);;All files (*.*)")
        if path:
            self.ed_excl.setText(path)
            self.lbl_excl.setText(os.path.basename(path))

    def _pick_base(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open baseline", "", "JSON files (*.json);;All files (*.*)")
        if path:
            self.ed_base.setText(path)
            self.lbl_base.setText(os.path.basename(path))

    def set_path(self, path: str) -> None:
        if not path or not os.path.exists(path):
            self.lbl_filename.setText("No file selected")
            self.lbl_meta.setText("Drop your file here, or click to browse")
            self.btn_analyze.setEnabled(False)
            return
        self._path = path
        detected = BaseParser.detect_input_type(path)
        self._input_type = detected
        size = os.path.getsize(path)
        if size >= 1024 * 1024:
            size_str = f"{size/1024/1024:.1f} MB"
        elif size >= 1024:
            size_str = f"{size/1024:.1f} KB"
        else:
            size_str = f"{size} B"
        self.lbl_filename.setText(os.path.basename(path))
        # Try to count records/packets for the meta line.
        count_str = self._quick_count(path, detected)
        meta_parts = [size_str, detected.upper()]
        if count_str:
            meta_parts.insert(1, count_str)
        self.lbl_meta.setText("  •  ".join(meta_parts))
        # Switch the segmented control to match.
        target = {"pcap": 0, "csv": 1, "text": 2}.get(detected, 0)
        self.seg_buttons[target].setChecked(True)
        self._on_segment_toggled(self.seg_buttons[target], True)
        # If CSV, populate the column-mapping combos and run auto-detect.
        if detected == "csv":
            self._detect_from_header()
        self.btn_analyze.setEnabled(True)
        self.file_changed.emit(path)

    def _quick_count(self, path: str, input_type: str) -> str:
        """Return a short '1,245,892 packets' / '12 rows' string, or empty."""
        try:
            if input_type == "csv":
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    n = sum(1 for _ in fh) - 1  # minus header
                return f"{max(n,0):,} rows"
            if input_type == "text":
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    n = sum(1 for _ in fh)
                return f"{n:,} lines"
            if input_type == "pcap":
                # Reading every packet just for the count is expensive; we
                # show a placeholder for big files. The parser will report
                # the real number in the warnings/result.
                return "PCAP capture"
        except OSError:
            return ""
        return ""

    def _detect_from_header(self) -> None:
        import csv as _csv
        if not self._path or self._input_type != "csv":
            return
        try:
            with open(self._path, "r", newline="", encoding="utf-8", errors="replace") as fh:
                reader = _csv.reader(fh)
                try:
                    header = next(reader)
                except StopIteration:
                    header = []
        except OSError:
            header = []
        self._detected_header = header
        auto = ColumnMapping.from_header_row(header)
        for field, combo in self.csv_mapping_inputs.items():
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("(auto-detect)", None)
            combo.addItem("(none)", "")
            for col in header:
                combo.addItem(col, col)
            combo.blockSignals(False)
            detected_value = getattr(auto, field)
            if detected_value is not None:
                idx = combo.findData(detected_value)
                if idx >= 0:
                    combo.setCurrentIndex(idx)
            self._update_csv_status(field)

    def _update_csv_status(self, field: str) -> None:
        combo = self.csv_mapping_inputs[field]
        value = combo.currentData()
        if value is None and combo.currentIndex() == 0 and self._detected_header:
            # Auto-detect path: check whether the auto-detect found a column.
            auto = ColumnMapping.from_header_row(self._detected_header)
            value = getattr(auto, field)
        if value:
            self.csv_status_labels[field].setText("✓ Detected")
            self.csv_status_labels[field].setStyleSheet(
                f"color:{GREEN_FG}; font-size:8pt; font-weight:700;"
            )
        else:
            self.csv_status_labels[field].setText("Not mapped")
            self.csv_status_labels[field].setStyleSheet(
                f"color:{TEXT_SECONDARY}; font-size:8pt;"
            )

    def _sync_param_cards(self) -> None:
        # Keep the four summary cards in sync with the editable fields.
        self.card_min_events.findChild(QLabel, "CardValue").setText(
            str(self.sp_min_events.value()))
        self.card_jitter.findChild(QLabel, "CardValue").setText(
            f"{self.sp_jitter.value():.0f}%")
        self.card_threshold.findChild(QLabel, "CardValue").setText(
            f"{self.sp_threshold.value():.0f}")
        gp = self.cmb_grouping.currentData()
        label = {"dest_port_protocol": "Dest + Port + Proto",
                 "dest_port": "Dest + Port",
                 "dest_only": "Dest only"}.get(gp, gp or "")
        self.card_grouping.findChild(QLabel, "CardValue").setText(label)

    def _build_payload(self) -> dict:
        cfg = AnalysisConfig(
            min_events=self.sp_min_events.value(),
            score_threshold=self.sp_threshold.value(),
            jitter_percent=self.sp_jitter.value(),
            udp_idle_timeout=self.sp_udp_timeout.value(),
            grouping_policy=self.cmb_grouping.currentData(),
            tcp_event_policy=self.cmb_tcp_policy.currentData(),
            byte_size_source=self.cmb_byte_source.currentData(),
            use_population_std=self.chk_population.isChecked(),
            include_ascii_histogram_in_text=self.chk_ascii_hist.isChecked(),
        )
        csv_mapping = None
        if self._input_type == "csv":
            csv_mapping = ColumnMapping(
                timestamp=self.csv_mapping_inputs["timestamp"].currentData(),
                source=self.csv_mapping_inputs["source"].currentData(),
                destination=self.csv_mapping_inputs["destination"].currentData(),
                destination_port=self.csv_mapping_inputs["destination_port"].currentData(),
                protocol=self.csv_mapping_inputs["protocol"].currentData(),
                bytes=self.csv_mapping_inputs["bytes"].currentData(),
            )
        text_format = None
        text_regex = None
        if self._input_type == "text":
            data = self.txt_format.currentData()
            if data == "custom":
                text_regex = self.txt_regex.text().strip() or None
            else:
                text_format = data
        return {
            "path": self._path,
            "input_type": self._input_type,
            "config": cfg,
            "column_mapping": csv_mapping,
            "text_format_name": text_format,
            "text_custom_regex": text_regex,
            "exclusion_path": self.ed_excl.text().strip() or None,
            "baseline_path": self.ed_base.text().strip() or None,
        }

    def _emit_start(self) -> None:
        if not self._path:
            return
        self.start_analysis.emit(self._build_payload())
