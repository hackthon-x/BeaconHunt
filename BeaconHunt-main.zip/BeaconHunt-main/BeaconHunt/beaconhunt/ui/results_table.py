"""Results dashboard — ranked table with filters and search.

Status badges use background color + a text label so they never rely on
color alone. Clicking a row emits `row_selected` for the details panel.
"""
from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget,
)

from ..analysis.scoring import DestinationResult
from ..analysis.engine import AnalysisReport
from .styles import status_color, status_fg_color


COLUMNS = [
    ("Rank", 60),
    ("Status", 170),
    ("Destination", 200),
    ("Port", 60),
    ("Proto", 60),
    ("Score", 60),
    ("Events", 60),
    ("Intervals", 70),
    ("Mean s", 70),
    ("Median s", 70),
    ("Std", 70),
    ("CV", 60),
    ("AbsJit", 70),
    ("RelJit%", 70),
    ("JitFit%", 70),
    ("ByteMin", 70),
    ("ByteMax", 70),
    ("ByteCV", 70),
    ("Srcs", 50),
    ("Baseline", 80),
    ("First seen", 160),
    ("Last seen", 160),
]


class ResultsTableWidget(QWidget):
    row_selected = Signal(object)  # DestinationResult

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._all_results: List[DestinationResult] = []
        self._filtered: List[DestinationResult] = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        # Filter bar
        filt = QHBoxLayout()
        filt.addWidget(QLabel("Filter:"))
        self.cmb_status = QComboBox()
        self.cmb_status.addItems(["All", "flagged", "not_flagged", "excluded", "insufficient_evidence"])
        self.cmb_status.currentIndexChanged.connect(self._refilter)
        filt.addWidget(QLabel("Status"))
        filt.addWidget(self.cmb_status)

        self.ed_dst = QLineEdit()
        self.ed_dst.setPlaceholderText("Destination contains…")
        self.ed_dst.textChanged.connect(self._refilter)
        filt.addWidget(QLabel("Destination"))
        filt.addWidget(self.ed_dst, 1)

        self.sp_port = QSpinBox()
        self.sp_port.setRange(0, 65535)
        self.sp_port.setSpecialValueText("Any")
        self.sp_port.valueChanged.connect(self._refilter)
        filt.addWidget(QLabel("Port"))
        filt.addWidget(self.sp_port)

        self.cmb_proto = QComboBox()
        self.cmb_proto.currentIndexChanged.connect(self._refilter)
        filt.addWidget(QLabel("Proto"))
        filt.addWidget(self.cmb_proto)

        self.sp_score_min = QSpinBox()
        self.sp_score_min.setRange(0, 100)
        self.sp_score_min.setSpecialValueText("0")
        self.sp_score_min.valueChanged.connect(self._refilter)
        filt.addWidget(QLabel("Score ≥"))
        filt.addWidget(self.sp_score_min)

        self.cmb_baseline = QComboBox()
        self.cmb_baseline.addItems(["Any", "new", "known", "n/a"])
        self.cmb_baseline.currentIndexChanged.connect(self._refilter)
        filt.addWidget(QLabel("Baseline"))
        filt.addWidget(self.cmb_baseline)

        self.ed_search = QLineEdit()
        self.ed_search.setPlaceholderText("Search anywhere…")
        self.ed_search.textChanged.connect(self._refilter)
        filt.addWidget(QLabel("Search"))
        filt.addWidget(self.ed_search, 1)

        self.btn_clear = QPushButton("Clear filters")
        self.btn_clear.setProperty("secondary", True)
        self.btn_clear.clicked.connect(self._clear_filters)
        filt.addWidget(self.btn_clear)
        layout.addLayout(filt)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(len(COLUMNS))
        self.table.setHorizontalHeaderLabels([c[0] for c in COLUMNS])
        for i, (_, w) in enumerate(COLUMNS):
            self.table.setColumnWidth(i, w)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.itemSelectionChanged.connect(self._on_selection)
        layout.addWidget(self.table, 1)

        # Status line
        self.lbl_count = QLabel("0 destinations")
        self.lbl_count.setProperty("muted", True)
        layout.addWidget(self.lbl_count)

    def set_report(self, report: AnalysisReport) -> None:
        self._all_results = list(report.results)
        # Populate the proto combo from data.
        protos = sorted({r.protocol for r in self._all_results})
        self.cmb_proto.blockSignals(True)
        self.cmb_proto.clear()
        self.cmb_proto.addItem("Any", None)
        for p in protos:
            self.cmb_proto.addItem(p, p)
        self.cmb_proto.blockSignals(False)
        self._refilter()

    def _clear_filters(self) -> None:
        self.cmb_status.setCurrentIndex(0)
        self.ed_dst.clear()
        self.sp_port.setValue(0)
        self.cmb_proto.setCurrentIndex(0)
        self.sp_score_min.setValue(0)
        self.cmb_baseline.setCurrentIndex(0)
        self.ed_search.clear()

    def _refilter(self) -> None:
        if not self._all_results:
            self.table.setRowCount(0)
            self.lbl_count.setText("0 destinations")
            return
        status = self.cmb_status.currentText()
        dst_q = self.ed_dst.text().strip().lower()
        port_q = self.sp_port.value()
        proto_q = self.cmb_proto.currentData()
        score_min = self.sp_score_min.value()
        base_q = self.cmb_baseline.currentText()
        search_q = self.ed_search.text().strip().lower()

        filtered: List[DestinationResult] = []
        for r in self._all_results:
            if status != "All" and r.status != status:
                continue
            if dst_q and dst_q not in r.destination_address.lower():
                continue
            if port_q != 0 and r.destination_port != port_q:
                continue
            if proto_q is not None and r.protocol != proto_q:
                continue
            if r.final_score < score_min:
                continue
            if base_q != "Any" and r.baseline_status != base_q:
                continue
            if search_q:
                blob = " ".join(str(x) for x in (
                    r.destination_address, r.destination_port, r.protocol,
                    r.status, r.key_reason, r.first_seen, r.last_seen,
                )).lower()
                if search_q not in blob:
                    continue
            filtered.append(r)
        self._filtered = filtered
        self._populate_table(filtered)

    def _populate_table(self, rows: List[DestinationResult]) -> None:
        self.table.setRowCount(len(rows))
        bg = QBrush(QColor(status_color("none")))
        for i, r in enumerate(rows):
            row_bg = QColor(status_color(r.status))
            row_fg = QColor(status_fg_color(r.status))
            cells = [
                str(r.rank), r.status, r.destination_address, str(r.destination_port),
                r.protocol, f"{r.final_score:.1f}", str(r.event_count), str(r.interval_count),
                self._fmt(r.mean_interval), self._fmt(r.median_interval),
                self._fmt(r.std_interval), self._fmt(r.cv_interval),
                self._fmt(r.absolute_jitter), self._fmt(r.relative_jitter_pct),
                self._fmt(r.jitter_band_fit_pct),
                self._fmt(r.byte_min), self._fmt(r.byte_max),
                self._fmt(r.byte_cv), str(r.source_address_count),
                r.baseline_status, r.first_seen or "", r.last_seen or "",
            ]
            for j, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, r)
                if j == 1:
                    # Status column: bold + colored background.
                    item.setBackground(row_bg)
                    item.setForeground(row_fg)
                elif r.status == "flagged":
                    item.setBackground(row_bg)
                item.setTextAlignment(Qt.AlignLeft if j in (2, 20, 21) else Qt.AlignCenter)
                self.table.setItem(i, j, item)
        self.lbl_count.setText(
            f"{len(rows)} of {len(self._all_results)} destinations shown · "
            f"{sum(1 for r in self._all_results if r.status=='flagged')} flagged"
        )

    @staticmethod
    def _fmt(v) -> str:
        if v is None:
            return "—"
        if isinstance(v, float):
            if abs(v) >= 1000:
                return f"{v:.0f}"
            if abs(v) >= 100:
                return f"{v:.1f}"
            if abs(v) >= 10:
                return f"{v:.2f}"
            return f"{v:.3f}"
        return str(v)

    def _on_selection(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        r = items[0].data(Qt.UserRole)
        if r is not None:
            self.row_selected.emit(r)
