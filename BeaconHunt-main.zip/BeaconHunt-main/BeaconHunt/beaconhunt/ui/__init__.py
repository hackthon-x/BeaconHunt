"""UI package — BeaconHunt PySide6 widgets."""
from .main_window import MainWindow
from .sidebar import Sidebar, NAV_ITEMS
from .dashboard import OverviewPage, KpiCard
from .import_panel import ImportPanel
from .results_table import ResultsTableWidget
from .details_panel import DetailsPanel
from .progress_dialog import ProgressDialog
from .styles import QSS

__all__ = [
    "MainWindow",
    "Sidebar",
    "NAV_ITEMS",
    "OverviewPage",
    "KpiCard",
    "ImportPanel",
    "ResultsTableWidget",
    "DetailsPanel",
    "ProgressDialog",
    "QSS",
]
