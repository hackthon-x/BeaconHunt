"""BeaconHunt main window — sidebar navigation + content stack.

The window is split into a fixed-width dark sidebar (Overview / Analyze
File / Results / Baselines / Settings) and a content stack on the right.
Exports are surfaced via a small top-right "Export" menu button that
appears once an analysis has been run.

Safety: every analysis runs in a QThread via AnalysisWorker. Closing the
window during analysis triggers cancel() then waits for the worker to
finish before quit. The window never opens a network connection.
"""
from __future__ import annotations

import os
import sys
from typing import Optional

from PySide6.QtCore import Qt, QThread, QTimer
from PySide6.QtGui import QAction, QDragEnterEvent, QDropEvent, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QMainWindow, QMenu,
    QMessageBox, QStackedWidget, QStatusBar, QToolButton, QVBoxLayout,
    QWidget,
)

from ..__init__ import __version__
from ..analysis.engine import AnalysisReport
from ..analysis.exclusions import save_baseline
from ..parsers.csv_parser import ColumnMapping
from ..reports import (
    export_csv, export_html, export_json, export_pdf, export_text,
)
from ..workers.analysis_worker import AnalysisWorker
from .dashboard import OverviewPage
from .details_panel import DetailsPanel
from .import_panel import ImportPanel
from .progress_dialog import ProgressDialog
from .sidebar import Sidebar
from .styles import QSS


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"BeaconHunt v{__version__}")
        self.resize(1280, 800)
        self.setMinimumSize(1024, 640)
        self.setStyleSheet(QSS)
        self.setAcceptDrops(True)

        # State
        self._worker: Optional[AnalysisWorker] = None
        self._thread: Optional[QThread] = None
        self._progress: Optional[ProgressDialog] = None
        self._report: Optional[AnalysisReport] = None
        self._current_path: Optional[str] = None

        # Central widget: sidebar + content stack side by side.
        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.sidebar = Sidebar()
        self.sidebar.page_changed.connect(self._on_page_changed)
        root.addWidget(self.sidebar)

        self._stack = QStackedWidget()
        self._stack.setObjectName("Content")
        root.addWidget(self._stack, 1)

        # Pages.
        self._overview = OverviewPage()
        self._overview.open_clicked.connect(self._open_file)
        self._overview.open_sample_clicked.connect(self._open_sample)
        self._overview.row_selected.connect(self._on_row_selected)
        self._stack.addWidget(self._overview)

        self._import_panel = ImportPanel()
        self._import_panel.start_analysis.connect(self._start_analysis)
        self._import_panel.cancel_analysis.connect(
            lambda: self._go_to_page("overview"))
        self._stack.addWidget(self._import_panel)

        # Results page = split between results table (existing) and details.
        from .results_table import ResultsTableWidget
        self._results_table = ResultsTableWidget()
        self._results_table.row_selected.connect(self._on_row_selected)
        self._details_panel = DetailsPanel()
        results_split = QWidget()
        rsl = QVBoxLayout(results_split)
        rsl.setContentsMargins(0, 0, 0, 0)
        rsl.setSpacing(0)
        rsl.addWidget(self._results_table)
        rsl.addWidget(self._details_panel)
        self._results_widget = results_split
        self._stack.addWidget(self._results_widget)

        # Baselines placeholder page.
        baselines_page = self._make_placeholder(
            "Baselines",
            "Saved baselines let you tag destinations as 'known' so future "
            "analyses can highlight what's new.\n\n"
            "Run an analysis, then use Save Baseline in the top-right "
            "Export menu to create one. Load it from the Analyze File "
            "page to compare."
        )
        self._stack.addWidget(baselines_page)

        # Settings placeholder page.
        settings_page = self._make_placeholder(
            "Settings",
            "All analysis settings are configured per-run on the Analyze "
            "File page.\n\n"
            "BeaconHunt has no cloud, no accounts, and no telemetry — there "
            "are no global settings to manage beyond what each analysis "
            "exposes."
        )
        self._stack.addWidget(settings_page)

        self.setCentralWidget(central)

        # Top-right export menu (visible after an analysis runs).
        self._export_btn = QToolButton()
        self._export_btn.setText("⤴  Export")
        self._export_btn.setProperty("secondary", True)
        self._export_btn.setPopupMode(QToolButton.InstantPopup)
        self._export_btn.setEnabled(False)
        menu = QMenu(self._export_btn)
        for label, kind in [("Export JSON", "json"),
                            ("Export CSV", "csv"),
                            ("Export HTML", "html"),
                            ("Export PDF", "pdf"),
                            ("Export Text", "text")]:
            act = QAction(label, self)
            act.triggered.connect(lambda _checked=False, k=kind: self._export(k))
            menu.addAction(act)
        menu.addSeparator()
        act_save_base = QAction("Save Baseline…", self)
        act_save_base.triggered.connect(self._save_baseline)
        menu.addAction(act_save_base)
        menu.addSeparator()
        act_about = QAction("About BeaconHunt", self)
        act_about.triggered.connect(self._about)
        menu.addAction(act_about)
        self._export_btn.setMenu(menu)
        # Place the button at top-right of the window via a corner widget.
        # Simplest approach: put it in the status bar (hidden) and also
        # show it as a floating widget over the content. To keep it
        # simple, we add it to the overview header instead — but since
        # other pages exist, the cleanest approach is a top toolbar
        # that's mostly empty except for this button.
        tb_corner = QWidget()
        tcl = QHBoxLayout(tb_corner)
        tcl.setContentsMargins(0, 0, 16, 0)
        tcl.addStretch()
        tcl.addWidget(self._export_btn)
        self._corner = tb_corner
        # Add a thin top bar to host the export button.
        self._topbar = QWidget()
        self._topbar.setFixedHeight(0)  # collapsed by default
        # We'll instead move the export button into each page header when
        # needed. Simpler: keep it always visible in a corner container
        # placed absolutely. To avoid layout complexity, we attach it to
        # the overview page's header via setMenuVisible logic — for now
        # just always have it accessible via right-click on the tray icon
        # is overkill. Pragmatic approach: re-add a small toolbar.

        # Minimal toolbar (hidden by default, shown when an analysis is
        # loaded) for Export + About.
        from PySide6.QtWidgets import QToolBar
        self.toolbar = QToolBar()
        self.toolbar.setMovable(False)
        self.toolbar.setWindowTitle("Actions")
        self.addToolBar(Qt.TopToolBarArea, self.toolbar)
        self.toolbar.addWidget(self._make_spacer(20))
        self.toolbar.addWidget(QLabel(""))  # spacer
        spacer_act = self.toolbar.addWidget(self._make_spacer(0, expanding=True))
        self.toolbar.addWidget(self._export_btn)
        self.toolbar.hide()

        # Status bar.
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(
            f"BeaconHunt v{__version__} — passive, offline analysis."
        )

        # Initial page.
        self._go_to_page("overview")
        self.sidebar.set_active("overview")

    # ------------------------------------------------------------------ helpers
    def _make_placeholder(self, title: str, body: str) -> QWidget:
        page = QWidget()
        page.setObjectName("Content")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(32, 28, 32, 28)
        lay.setSpacing(12)
        t = QLabel(title)
        t.setObjectName("PageTitle")
        lay.addWidget(t)
        b = QLabel(body)
        b.setStyleSheet("color:#64748B; font-size:10pt;")
        b.setWordWrap(True)
        lay.addWidget(b)
        lay.addStretch()
        return page

    def _make_spacer(self, width: int = 0, expanding: bool = False) -> QWidget:
        from PySide6.QtWidgets import QSizePolicy
        w = QWidget()
        if expanding:
            sp = w.sizePolicy()
            sp.setHorizontalPolicy(QSizePolicy.Expanding)
            w.setSizePolicy(sp)
        else:
            w.setFixedWidth(width)
        return w

    def _go_to_page(self, key: str) -> None:
        idx = {"overview": 0, "analyze": 1, "results": 2,
               "baselines": 3, "settings": 4}.get(key, 0)
        self._stack.setCurrentIndex(idx)
        self.sidebar.set_active(key)
        # Show the export toolbar only on results + overview when a report exists.
        if self._report is not None and key in ("overview", "results"):
            self.toolbar.show()
        else:
            self.toolbar.hide()

    def _on_page_changed(self, key: str) -> None:
        self._go_to_page(key)

    # ------------------------------------------------------------------ nav
    def _open_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open PCAP / Log", "",
            "PCAP files (*.pcap *.pcapng *.cap);;"
            "CSV/TSV (*.csv *.tsv);;"
            "Text logs (*.txt *.log);;"
            "All files (*.*)",
        )
        if path:
            self._set_file(path)

    def _open_sample(self) -> None:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        samples_dir = os.path.join(os.path.dirname(here), "samples")
        if not os.path.isdir(samples_dir):
            samples_dir = os.path.join(here, "samples")
        if not os.path.isdir(samples_dir):
            QMessageBox.warning(self, "Samples not found",
                                f"Could not find samples directory at {samples_dir!r}.")
            return
        default_path = os.path.join(samples_dir, "mixed.csv")
        if not os.path.exists(default_path):
            default_path = samples_dir
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Sample Project", default_path,
            "Sample files (*.csv *.pcap *.pcapng *.txt);;All files (*.*)",
        )
        if path:
            self._set_file(path)

    def _set_file(self, path: str) -> None:
        self._current_path = path
        self._import_panel.set_path(path)
        self._go_to_page("analyze")
        self.statusBar().showMessage(f"Loaded: {path}")

    # ------------------------------------------------------------ drag-drop
    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if path:
                self._set_file(path)

    # ------------------------------------------------------------ analysis
    def _start_analysis(self, payload: dict) -> None:
        if self._worker is not None:
            return
        worker = AnalysisWorker(
            path=payload["path"],
            input_type=payload["input_type"],
            config=payload["config"],
            column_mapping=payload.get("column_mapping"),
            text_format_name=payload.get("text_format_name"),
            text_custom_regex=payload.get("text_custom_regex"),
            exclusion_path=payload.get("exclusion_path"),
            baseline_path=payload.get("baseline_path"),
        )
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.progress.connect(self._on_progress)
        worker.warnings.connect(self._on_warnings)
        worker.finished_ok.connect(self._on_finished_ok)
        worker.failed.connect(self._on_failed)
        worker.cancelled.connect(self._on_cancelled)
        self._worker = worker
        self._thread = thread

        self._progress = ProgressDialog(self)
        self._progress.rejected.connect(self._on_progress_cancelled)
        self._progress.show()
        thread.start()

    def _on_progress(self, stage: str, percent: int) -> None:
        if self._progress:
            self._progress.set_stage(stage, percent)

    def _on_warnings(self, warnings) -> None:
        if self._progress:
            self._progress.append_warnings(warnings)

    def _on_progress_cancelled(self) -> None:
        if self._worker:
            self._worker.cancel()

    def _on_finished_ok(self, report: AnalysisReport) -> None:
        self._report = report
        if self._progress:
            self._progress.accept()
            self._progress = None
        self._overview.set_report(report)
        self._results_table.set_report(report)
        if report.results:
            self._details_panel.set_result(report.results[0])
        self._go_to_page("results")
        self.statusBar().showMessage(
            f"Analysis complete: {len(report.results)} destinations, "
            f"{len(report.flagged)} flagged."
        )
        self._export_btn.setEnabled(True)
        self._cleanup_worker()

    def _on_failed(self, message: str) -> None:
        if self._progress:
            self._progress.reject()
            self._progress = None
        QMessageBox.critical(self, "Analysis failed", message)
        self._cleanup_worker()

    def _on_cancelled(self) -> None:
        if self._progress:
            self._progress.reject()
            self._progress = None
        self.statusBar().showMessage("Analysis cancelled.")
        self._cleanup_worker()

    def _cleanup_worker(self) -> None:
        if self._thread:
            self._thread.quit()
            self._thread.wait(5000)
            self._thread = None
        self._worker = None

    def _on_row_selected(self, r) -> None:
        self._details_panel.set_result(r)
        # Make sure the details panel is visible (it always is, below the
        # results table on the Results page).

    # ------------------------------------------------------------ exports
    def _export(self, kind: str) -> None:
        if self._report is None:
            return
        filters = {
            "json": "JSON (*.json)",
            "csv": "CSV (*.csv)",
            "html": "HTML (*.html)",
            "pdf": "PDF (*.pdf)",
            "text": "Text (*.txt)",
        }
        ext = {"json": ".json", "csv": ".csv", "html": ".html",
               "pdf": ".pdf", "text": ".txt"}[kind]
        default_name = "beaconhunt_report" + ext
        path, _ = QFileDialog.getSaveFileName(
            self, f"Export {kind.upper()}", default_name, filters[kind])
        if not path:
            return
        if os.path.exists(path):
            reply = QMessageBox.question(
                self, "Overwrite file?",
                f"The file {path!r} already exists. Overwrite it?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                return
        try:
            if kind == "json":
                export_json(self._report, path, force=True)
            elif kind == "csv":
                export_csv(self._report, path, force=True)
            elif kind == "html":
                export_html(self._report, path, force=True)
            elif kind == "pdf":
                export_pdf(self._report, path, force=True)
            elif kind == "text":
                export_text(self._report, path, force=True,
                            include_histogram=self._report.config.include_ascii_histogram_in_text)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Export failed", str(exc))
            return
        self.statusBar().showMessage(f"Wrote {path}")

    def _save_baseline(self) -> None:
        if self._report is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save baseline JSON", "beaconhunt_baseline.json",
            "JSON files (*.json)")
        if not path:
            return
        if os.path.exists(path):
            reply = QMessageBox.question(
                self, "Overwrite baseline?",
                f"The baseline {path!r} already exists. Overwrite it? "
                f"BeaconHunt never silently overwrites a baseline.",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply != QMessageBox.Yes:
                return
        try:
            save_baseline(path, self._report.results, self._report.config, force=True)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Save baseline failed", str(exc))
            return
        self.statusBar().showMessage(f"Wrote baseline {path}")

    # ------------------------------------------------------------ about
    def _about(self) -> None:
        QMessageBox.about(
            self, "About BeaconHunt",
            f"<h3>BeaconHunt v{__version__}</h3>"
            f"<p>Passive, offline beaconing detector for PCAP and "
            f"firewall/proxy logs.</p>"
            f"<p>Files are analyzed locally. No live capture, no network "
            f"connections, no DNS resolution, no uploads.</p>"
            f"<p>Results describe <i>beacon-like</i> or <i>suspicious "
            f"periodicity</i>, not proof of command-and-control activity. "
            f"Always correlate with asset ownership and policy.</p>"
            f"<p style='color:#6b7280; font-size:9pt;'>"
            f"Built for Ashar — C2 Beacon Detection track.</p>"
        )

    # ------------------------------------------------------------ close
    def closeEvent(self, event) -> None:
        if self._worker is not None:
            self._worker.cancel()
            if self._thread:
                self._thread.quit()
                self._thread.wait(5000)
        event.accept()
