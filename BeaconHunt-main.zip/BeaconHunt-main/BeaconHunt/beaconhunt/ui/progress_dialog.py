"""Modal progress dialog shown while the worker runs.

Shows the current stage, a determinate progress bar (or indeterminate when
the percent is -1), a Cancel button, and a scrollable warnings list that
fills in as the worker emits warnings.
"""
from __future__ import annotations

from typing import List

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton, QTextEdit,
    QVBoxLayout,
)


class ProgressDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Analyzing…")
        self.setModal(True)
        self.setMinimumWidth(420)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        self.lbl_stage = QLabel("Starting…")
        layout.addWidget(self.lbl_stage)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        layout.addWidget(self.bar)

        self.lbl_warnings = QLabel("Warnings:")
        self.lbl_warnings.setStyleSheet("color: #6b7280; font-size: 9pt;")
        layout.addWidget(self.lbl_warnings)

        self.txt_warnings = QTextEdit()
        self.txt_warnings.setReadOnly(True)
        self.txt_warnings.setMaximumHeight(120)
        self.txt_warnings.setStyleSheet("font-size: 9pt;")
        layout.addWidget(self.txt_warnings)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setProperty("danger", True)
        self.btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(self.btn_cancel)
        layout.addLayout(btn_row)

    def set_stage(self, message: str, percent: int) -> None:
        self.lbl_stage.setText(message)
        if percent < 0:
            self.bar.setRange(0, 0)  # indeterminate
        else:
            self.bar.setRange(0, 100)
            self.bar.setValue(percent)

    def append_warnings(self, warnings: List) -> None:
        if not warnings:
            return
        text = self.txt_warnings.toPlainText()
        for w in warnings:
            text += str(w) + "\n"
        self.txt_warnings.setPlainText(text)
        self.txt_warnings.verticalScrollBar().setValue(
            self.txt_warnings.verticalScrollBar().maximum()
        )
