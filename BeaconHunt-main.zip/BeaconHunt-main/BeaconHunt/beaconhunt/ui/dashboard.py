"""Overview / Dashboard page.

Shows the BeaconHunt welcome header, the LOCAL ONLY badge, three KPI
cards (Destinations Analyzed, Beacon-Like Candidates, Parsing Warnings),
the teal privacy banner, and — when an analysis has been run — a summary
table of the top suspicious destinations with status badges and the
footer caveat about scores being investigative leads.

When no analysis is loaded, the KPI values show "—" and a friendly
empty-state message invites the user to open a sample project.
"""
from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult
from .styles import (
    badge_qss, status_label, ACCENT_TEAL, AMBER_FG, GREEN_FG, TEXT_PRIMARY,
    TEXT_SECONDARY,
)


def _hbox(parent_layout, *widgets, stretch_last=True):
    row = QHBoxLayout()
    row.setSpacing(10)
    for w in widgets:
        row.addWidget(w)
    if stretch_last:
        row.addStretch()
    parent_layout.addLayout(row)
    return row


class KpiCard(QFrame):
    """One stat tile: icon + title + big value + caption."""

    def __init__(self, icon_text: str, icon_variant: str,
                 title: str, value: str, caption: str) -> None:
        super().__init__()
        self.setObjectName("KpiCard")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 18, 18, 18)
        lay.setSpacing(14)

        icon = QLabel(icon_text)
        icon.setObjectName(
            {"teal": "KpiIconTeal", "green": "KpiIconGreen", "amber": "KpiIconAmber"}[icon_variant]
        )
        icon.setFixedSize(40, 40)
        lay.addWidget(icon)

        col = QVBoxLayout()
        col.setSpacing(2)
        t = QLabel(title)
        t.setObjectName("KpiTitle")
        col.addWidget(t)
        v = QLabel(value)
        v.setObjectName("KpiValue")
        col.addWidget(v)
        c = QLabel(caption)
        c.setObjectName("KpiCaption")
        col.addWidget(c)
        lay.addLayout(col, 1)


class OverviewPage(QWidget):
    """The first page users see when the app starts."""

    open_clicked = Signal()
    open_sample_clicked = Signal()
    row_selected = Signal(object)   # DestinationResult

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setObjectName("Content")
        self._report: Optional[AnalysisReport] = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(32, 28, 32, 28)
        outer.setSpacing(20)

        # --- Header row ---
        header = QHBoxLayout()
        header.setSpacing(12)
        title_col = QVBoxLayout()
        title_col.setSpacing(4)
        title = QLabel("BeaconHunt")
        title.setObjectName("PageTitle")
        title_col.addWidget(title)
        sub = QLabel("Offline Beacon Analysis")
        sub.setObjectName("PageSubtitle")
        title_col.addWidget(sub)
        header.addLayout(title_col)
        header.addStretch()
        badge = QLabel("◉ LOCAL ONLY")
        badge.setObjectName("BadgeLocal")
        header.addWidget(badge)
        outer.addLayout(header)

        # --- KPI row ---
        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(16)
        self.kpi_destinations = KpiCard("◎", "teal", "Destinations Analyzed", "—",
                                        "Unique destinations processed")
        self.kpi_beacons = KpiCard("⚠", "amber", "Beacon-Like Candidates", "—",
                                   "Highly suspicious destinations")
        self.kpi_warnings = KpiCard("!", "green", "Parsing Warnings", "—",
                                    "Issues encountered during parsing")
        for kpi in (self.kpi_destinations, self.kpi_beacons, self.kpi_warnings):
            kpi_row.addWidget(kpi, 1)
        outer.addLayout(kpi_row)

        # --- Privacy banner ---
        banner = QFrame()
        banner.setObjectName("PrivacyBanner")
        blay = QHBoxLayout(banner)
        blay.setContentsMargins(16, 12, 16, 12)
        blay.setSpacing(12)
        shield = QLabel("✓")
        shield.setStyleSheet(
            f"background:{GREEN_FG}; color:white; border-radius:12px; "
            f"padding:4px 8px; font-weight:800; min-width:24px; min-height:24px;"
        )
        shield.setAlignment(Qt.AlignCenter)
        blay.addWidget(shield)
        btext = QVBoxLayout()
        btext.setSpacing(0)
        btitle = QLabel("Local analysis environment")
        btitle.setObjectName("PrivacyText")
        btext.addWidget(btitle)
        bsub = QLabel("All processing performed locally. No data is sent to external servers.")
        bsub.setObjectName("PrivacySub")
        btext.addWidget(bsub)
        blay.addLayout(btext)
        blay.addStretch()
        outer.addWidget(banner)

        # --- Summary card (table) ---
        table_card = QFrame()
        table_card.setObjectName("Card")
        tclay = QVBoxLayout(table_card)
        tclay.setContentsMargins(20, 18, 20, 18)
        tclay.setSpacing(12)

        thead = QHBoxLayout()
        thead.setSpacing(8)
        th_title = QLabel("Suspicious destinations")
        th_title.setObjectName("CardTitle")
        thead.addWidget(th_title)
        thead.addStretch()
        self.btn_open = QPushButton("Open PCAP / Log…")
        self.btn_open.setProperty("secondary", True)
        self.btn_open.clicked.connect(self.open_clicked.emit)
        thead.addWidget(self.btn_open)
        self.btn_sample = QPushButton("Open Sample Project")
        self.btn_sample.setProperty("outline", True)
        self.btn_sample.clicked.connect(self.open_sample_clicked.emit)
        thead.addWidget(self.btn_sample)
        tclay.addLayout(thead)

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(
            ["Rank", "Destination", "Status", "Score",
             "Median Interval", "Events", "Bytes"])
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setHighlightSections(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignLeft)
        self.table.horizontalHeader().setStretchLastSection(False)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.itemSelectionChanged.connect(self._on_row_selected)
        tclay.addWidget(self.table)

        # Footer
        foot = QHBoxLayout()
        foot.setSpacing(6)
        info = QLabel("ⓘ  Scores are investigative leads, not proof of C2.")
        info.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        foot.addWidget(info)
        foot.addStretch()
        self.page_label = QLabel("")
        self.page_label.setStyleSheet(f"color:{TEXT_SECONDARY}; font-size:9pt;")
        foot.addWidget(self.page_label)
        tclay.addLayout(foot)

        outer.addWidget(table_card, 1)

        # Empty-state overlay (just a label centered over the table area).
        self.empty_label = QLabel(
            "No analysis loaded yet.\n\nClick Open PCAP / Log to choose a file,\n"
            "or Open Sample Project to try BeaconHunt on bundled synthetic data."
        )
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setStyleSheet(
            f"color:{TEXT_SECONDARY}; font-size:11pt; padding:40px;"
        )
        tclay.addWidget(self.empty_label)

    # ------------------------------------------------------------------ data
    def set_report(self, report: AnalysisReport) -> None:
        self._report = report
        flagged = len(report.flagged)
        warnings = (len(report.parse_result.warnings) +
                    len(report.exclusion_warnings) +
                    len(report.baseline_warnings))
        self.kpi_destinations.findChild(QLabel, "KpiValue").setText(
            f"{len(report.results):,}")
        self.kpi_beacons.findChild(QLabel, "KpiValue").setText(f"{flagged:,}")
        self.kpi_warnings.findChild(QLabel, "KpiValue").setText(f"{warnings:,}")
        self._populate_table(report.results)
        self.empty_label.setVisible(False)

    def _populate_table(self, results: List[DestinationResult]) -> None:
        # Show top 8 by rank (pagination placeholder).
        top = results[:8]
        self.table.setRowCount(len(top))
        for i, r in enumerate(top):
            dest_text = f"{r.destination_address}:{r.destination_port}/{r.protocol}"
            chip = QLabel(dest_text)
            chip.setObjectName("DestChip")
            status = QLabel(status_label(r.status))
            status.setStyleSheet(badge_qss(r.status))
            score = QLabel(f"{r.final_score:.0f}")
            score.setStyleSheet(
                f"color:{TEXT_PRIMARY}; font-weight:800; font-size:12pt; padding-left:6px;"
            )
            med = f"{r.median_interval:.1f} s" if r.median_interval is not None else "n/a"
            bytes_text = (
                f"{r.byte_min}–{r.byte_max} B" if r.byte_min is not None and r.byte_max is not None
                else "n/a"
            )
            cells = [
                (str(r.rank), Qt.AlignCenter),
                (dest_text, Qt.AlignLeft),
                (status_label(r.status), Qt.AlignLeft),
                (f"{r.final_score:.0f}", Qt.AlignCenter),
                (med, Qt.AlignLeft),
                (str(r.event_count), Qt.AlignCenter),
                (bytes_text, Qt.AlignLeft),
            ]
            for j, (text, align) in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, r)
                if j == 2:
                    item.setForeground(Qt.GlobalColor.transparent)  # hide text, show badge
                if align == Qt.AlignCenter:
                    item.setTextAlignment(Qt.AlignCenter)
                item.setToolTip(r.key_reason)
                self.table.setItem(i, j, item)
            # Replace the destination cell with the chip widget.
            self.table.setCellWidget(i, 1, chip)
            # Replace the status cell with the badge widget.
            self.table.setCellWidget(i, 2, status)
            # Replace the score cell with the bold score widget.
            self.table.setCellWidget(i, 3, score)
        if len(results) > 8:
            self.page_label.setText("Page 1 of %d  ·  showing top 8" % ((len(results) + 7) // 8))
        else:
            self.page_label.setText("")

    def _on_row_selected(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        r = items[0].data(Qt.UserRole)
        if r is not None:
            self.row_selected.emit(r)
