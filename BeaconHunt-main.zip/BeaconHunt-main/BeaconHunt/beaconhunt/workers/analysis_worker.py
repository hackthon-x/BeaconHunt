"""Background worker that runs parsing + analysis off the GUI thread.

Uses QThread + Qt signals so the UI stays responsive during long parses.
The worker can be cancelled cooperatively: the cancel() slot sets a flag
that the parser checks between packets/rows. (Scapy's rdpcap reads the
whole file in one call, so for very large PCAPs cancellation is honoured
only between the parse and analysis stages. This is documented in the
README and surfaced in the UI.)
"""
from __future__ import annotations

import os
from typing import Optional

from PySide6.QtCore import QThread, Signal, QObject

from ..config.settings import AnalysisConfig
from ..parsers.base import BaseParser, ParseResult
from ..parsers.pcap_parser import PcapParser
from ..parsers.csv_parser import CsvParser, ColumnMapping
from ..parsers.text_parser import TextParser
from ..analysis.engine import run_analysis, AnalysisReport


class AnalysisWorker(QObject):
    """Runs on a background thread. Emits progress, warnings, and result."""

    progress = Signal(str, int)   # (stage_message, percent 0-100 or -1 for indeterminate)
    warnings = Signal(list)       # list[ParseWarning]
    finished_ok = Signal(object)  # AnalysisReport
    failed = Signal(str)          # error message
    cancelled = Signal()

    def __init__(
        self,
        path: str,
        input_type: str,
        config: AnalysisConfig,
        column_mapping: Optional[ColumnMapping] = None,
        text_format_name: Optional[str] = None,
        text_custom_regex: Optional[str] = None,
        exclusion_path: Optional[str] = None,
        baseline_path: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.path = path
        self.input_type = input_type
        self.config = config
        self.column_mapping = column_mapping
        self.text_format_name = text_format_name
        self.text_custom_regex = text_custom_regex
        self.exclusion_path = exclusion_path
        self.baseline_path = baseline_path
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    def run(self) -> None:
        try:
            self.progress.emit("Reading file…", -1)
            parser = self._make_parser()
            if self._cancel:
                self.cancelled.emit()
                return
            self.progress.emit("Parsing…", 25)
            parse_result = parser.parse(self.path)
            if self._cancel:
                self.cancelled.emit()
                return
            self.progress.emit("Grouping…", 50)
            if self._cancel:
                self.cancelled.emit()
                return
            self.progress.emit("Computing statistics…", 70)
            report = run_analysis(
                parse_result, self.config,
                exclusion_path=self.exclusion_path,
                baseline_path=self.baseline_path,
            )
            if self._cancel:
                self.cancelled.emit()
                return
            self.progress.emit("Generating report…", 90)
            self.warnings.emit(parse_result.warnings + report.exclusion_warnings + report.baseline_warnings)
            self.progress.emit("Done", 100)
            self.finished_ok.emit(report)
        except Exception as exc:  # noqa: BLE001
            self.failed.emit(f"{type(exc).__name__}: {exc}")

    def _make_parser(self) -> BaseParser:
        if self.input_type == "pcap":
            return PcapParser(
                tcp_event_policy=self.config.tcp_event_policy,
                udp_idle_timeout=self.config.udp_idle_timeout,
                byte_size_source=self.config.byte_size_source,
            )
        if self.input_type == "csv":
            return CsvParser(mapping=self.column_mapping)
        if self.input_type == "text":
            return TextParser(
                format_name=self.text_format_name,
                custom_regex=self.text_custom_regex,
            )
        # Auto-detect by extension.
        from ..parsers.base import BaseParser as _BP
        detected = _BP.detect_input_type(self.path)
        if detected == "pcap":
            return PcapParser()
        if detected == "csv":
            return CsvParser()
        if detected == "text":
            return TextParser()
        raise ValueError(f"could not detect input type for {self.path!r}")
