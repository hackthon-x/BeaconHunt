"""BeaconHunt application entry point.

Run with:
    python -m beaconhunt.app
or:
    python beaconhunt/app.py

Framework choice
----------------
BeaconHunt uses PySide6 (Qt 6 for Python). PySide6 was selected over the
alternatives for these reasons:

  * Tkinter — built into Python but lacks a polished table widget, drag-and
    -drop file support, and an embeddable matplotlib canvas comparable to
    Qt's. Building the required results dashboard, details panel with tabs,
    and the in-window plots would mean reimplementing a great deal of
    infrastructure that Qt provides off the shelf.

  * PyQt6 — feature-equivalent to PySide6 but distributed under the GPL or a
    commercial license. PySide6 is LGPL, which is more permissive for a
    student project that may later be shared or extended.

  * Dear PyGui / customtkinter — attractive but smaller communities and
    weaker accessibility support (focus states, screen-reader-friendly
    labels, keyboard navigation) than Qt.

PySide6 ships its own Qt runtime, so no system Qt install is required.
"""
from __future__ import annotations

import sys
import os

# Ensure the bundled samples directory is on the path when running from a
# source checkout.
HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Matplotlib uses the QtAgg backend so it can embed in PySide6 widgets.
import matplotlib
matplotlib.use("QtAgg")

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt

from beaconhunt.__init__ import __version__
from beaconhunt.ui import MainWindow, QSS


def main() -> int:
    # High DPI is on by default in Qt 6; we just enable smooth scaling.
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    app = QApplication(sys.argv)
    app.setApplicationName("BeaconHunt")
    app.setApplicationVersion(__version__)
    app.setStyleSheet(QSS)
    win = MainWindow()
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
