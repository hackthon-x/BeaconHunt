"""Export the ranked results to JSON."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import List

from ..__init__ import __version__
from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult


def export_json(report: AnalysisReport, path: str, force: bool = False) -> str:
    if os.path.exists(path) and not force:
        raise FileExistsError(f"file already exists: {path}")
    payload = {
        "tool": "BeaconHunt",
        "version": __version__,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "input": {
            "filename": os.path.basename(report.parse_result.input_source),
            "input_type": report.parse_result.input_type,
            "byte_size_source": report.parse_result.byte_size_source,
            "total_records_seen": report.parse_result.total_records_seen,
            "skipped_records": report.parse_result.skipped_records,
            "records_analyzed": len(report.parse_result.records),
        },
        "settings": report.config.as_dict(),
        "flow_policy": report.flow_policy_note,
        "limitations": report.limitations_note,
        "parsing_warnings": [str(w) for w in report.parse_result.warnings],
        "exclusion_warnings": [str(w) for w in report.exclusion_warnings],
        "baseline_warnings": [str(w) for w in report.baseline_warnings],
        "results": [_result_to_dict(r) for r in report.results],
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, default=str)
    return path


def _result_to_dict(r: DestinationResult) -> dict:
    return {
        "rank": r.rank,
        "status": r.status,
        "destination_address": r.destination_address,
        "destination_port": r.destination_port,
        "protocol": r.protocol,
        "final_score": r.final_score,
        "event_count": r.event_count,
        "interval_count": r.interval_count,
        "mean_interval": r.mean_interval,
        "median_interval": r.median_interval,
        "std_interval": r.std_interval,
        "cv_interval": r.cv_interval,
        "absolute_jitter": r.absolute_jitter,
        "relative_jitter_pct": r.relative_jitter_pct,
        "jitter_band_fit_count": r.jitter_band_fit_count,
        "jitter_band_fit_pct": r.jitter_band_fit_pct,
        "byte_min": r.byte_min,
        "byte_max": r.byte_max,
        "byte_mean": r.byte_mean,
        "byte_cv": r.byte_cv,
        "byte_count": r.byte_count,
        "byte_missing_count": r.byte_missing_count,
        "first_seen": r.first_seen,
        "last_seen": r.last_seen,
        "source_address_count": r.source_address_count,
        "baseline_status": r.baseline_status,
        "exclusion_reason": r.exclusion_reason,
        "key_reason": r.key_reason,
        "components": [
            {
                "name": c.name,
                "weight": c.weight,
                "raw_score": c.raw_score,
                "weighted_score": c.weighted_score,
                "used": c.used,
                "reason": c.reason,
            }
            for c in r.components
        ],
        "notes": r.notes,
    }
