"""CSV export of the ranked results table."""
from __future__ import annotations

import csv
import os
from typing import List

from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult


COLUMNS = [
    "rank", "status", "destination_address", "destination_port", "protocol",
    "final_score", "event_count", "interval_count", "mean_interval",
    "median_interval", "std_interval", "cv_interval", "absolute_jitter",
    "relative_jitter_pct", "jitter_band_fit_count", "jitter_band_fit_pct",
    "byte_min", "byte_max", "byte_mean", "byte_cv", "byte_count",
    "byte_missing_count", "first_seen", "last_seen", "source_address_count",
    "baseline_status", "exclusion_reason", "key_reason",
]


def export_csv(report: AnalysisReport, path: str, force: bool = False) -> str:
    if os.path.exists(path) and not force:
        raise FileExistsError(f"file already exists: {path}")
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for r in report.results:
            w.writerow([getattr(r, c) for c in COLUMNS])
    return path
