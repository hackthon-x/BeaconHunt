"""Plain-text report with optional ASCII interval histogram.

This is the human-readable export used for quick sharing and as the source
of the PDF/HTML report body. The ASCII histogram is included when
`config.include_ascii_histogram_in_text` is True.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List

from ..__init__ import __version__
from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult


def _ascii_histogram(values: List[float], bins: int = 20, width: int = 40) -> str:
    if not values:
        return "  (no intervals to plot)"
    lo = min(values)
    hi = max(values)
    if hi == lo:
        # All same value -> single bar.
        bar = "#" * width
        return f"  [{lo:.2f}] {bar} ({len(values)})"
    span = hi - lo
    bin_w = span / bins if bins > 0 else 1
    counts = [0] * bins
    for v in values:
        idx = int((v - lo) / bin_w)
        if idx >= bins:
            idx = bins - 1
        counts[idx] += 1
    max_c = max(counts) or 1
    lines = []
    for i, c in enumerate(counts):
        lo_b = lo + i * bin_w
        hi_b = lo + (i + 1) * bin_w
        bar = "#" * int(width * c / max_c)
        lines.append(f"  [{lo_b:7.2f} - {hi_b:7.2f}] {bar} ({c})")
    return "\n".join(lines)


def export_text(report: AnalysisReport, path: str, force: bool = False,
                include_histogram: bool = True) -> str:
    if os.path.exists(path) and not force:
        raise FileExistsError(f"file already exists: {path}")
    lines: List[str] = []
    lines.append("BeaconHunt Analysis Report")
    lines.append("=" * 60)
    lines.append(f"Tool: BeaconHunt v{__version__}")
    lines.append(f"Generated: {datetime.now(timezone.utc).isoformat()}")
    lines.append(f"Input: {os.path.basename(report.parse_result.input_source)} "
                 f"({report.parse_result.input_type})")
    lines.append(f"Records seen: {report.parse_result.total_records_seen}; "
                 f"skipped: {report.parse_result.skipped_records}; "
                 f"analyzed: {len(report.parse_result.records)}")
    lines.append(f"Settings: {report.config.describe()}")
    lines.append(f"Flow policy: {report.flow_policy_note}")
    lines.append("")
    lines.append("Limitations")
    lines.append("-" * 60)
    lines.append(report.limitations_note)
    lines.append("")
    if report.parse_result.warnings:
        lines.append("Parsing warnings")
        lines.append("-" * 60)
        for w in report.parse_result.warnings:
            lines.append(f"  {w}")
        lines.append("")
    if report.exclusion_warnings:
        lines.append("Exclusion-list warnings")
        lines.append("-" * 60)
        for w in report.exclusion_warnings:
            lines.append(f"  {w}")
        lines.append("")
    if report.baseline_warnings:
        lines.append("Baseline warnings")
        lines.append("-" * 60)
        for w in report.baseline_warnings:
            lines.append(f"  {w}")
        lines.append("")
    lines.append("Ranked results")
    lines.append("-" * 60)
    header = (f"{'#':>3} {'Status':<22} {'Destination':<40} "
              f"{'Score':>6} {'Ev':>4} {'Int':>4} {'Med':>9} {'JitFit':>7}")
    lines.append(header)
    for r in report.results:
        dst = f"{r.destination_address}:{r.destination_port}/{r.protocol}"
        med = f"{r.median_interval:.1f}s" if r.median_interval is not None else "n/a"
        jit = f"{r.jitter_band_fit_pct:.0f}%" if r.jitter_band_fit_pct is not None else "n/a"
        lines.append(f"{r.rank:>3} {r.status:<22} {dst:<40} "
                     f"{r.final_score:>6.1f} {r.event_count:>4} "
                     f"{r.interval_count:>4} {med:>9} {jit:>7}")
    lines.append("")
    if report.flagged:
        lines.append("Evidence for flagged destinations")
        lines.append("-" * 60)
        for r in report.flagged:
            lines.append(_detail_block(r, include_histogram=include_histogram))
            lines.append("")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def _detail_block(r: DestinationResult, include_histogram: bool = True) -> str:
    out: List[str] = []
    out.append(f"Destination: {r.destination_address}:{r.destination_port}/{r.protocol}")
    out.append(f"  Status: {r.status}; final score: {r.final_score:.1f}; "
               f"reason: {r.key_reason}")
    out.append(f"  Events: {r.event_count}; intervals: {r.interval_count}; "
               f"sources: {r.source_address_count}")
    if r.median_interval is not None:
        out.append(f"  Interval median: {r.median_interval:.2f}s; "
                   f"mean: {r.mean_interval:.2f}s; "
                   f"std: {r.std_interval:.3f}s; "
                   f"CV: {r.cv_interval:.3f}" if r.cv_interval is not None
                   else f"  Interval median: {r.median_interval:.2f}s; "
                        f"mean: {r.mean_interval:.2f}s; CV: n/a")
        out.append(f"  Absolute jitter (MAD): {r.absolute_jitter:.3f}s; "
                   f"relative jitter: "
                   f"{r.relative_jitter_pct:.1f}%" if r.relative_jitter_pct is not None
                   else f"  Absolute jitter: n/a")
        out.append(f"  Jitter-band fit: {r.jitter_band_fit_pct:.1f}% "
                   f"({r.jitter_band_fit_count}/{r.interval_count})" if r.jitter_band_fit_pct is not None
                   else "  Jitter-band fit: n/a")
    if r.byte_count > 0:
        out.append(f"  Byte size: min={r.byte_min}, max={r.byte_max}, "
                   f"mean={r.byte_mean:.0f}, CV={r.byte_cv:.3f} "
                   f"({r.byte_count} samples, {r.byte_missing_count} missing)")
    else:
        out.append("  Byte size: not available for this destination")
    out.append(f"  First seen: {r.first_seen}; last seen: {r.last_seen}")
    if r.baseline_status != "n/a":
        out.append(f"  Baseline: {r.baseline_status}")
    if r.exclusion_reason:
        out.append(f"  Excluded because: {r.exclusion_reason}")
    out.append("  Score components:")
    for c in r.components:
        rs = f"{c.raw_score:.1f}" if c.raw_score is not None else "n/a"
        ws = f"{c.weighted_score:.1f}" if c.used else "n/a"
        out.append(f"    - {c.name:<22} weight={c.weight:.2f} "
                   f"raw={rs:>5} weighted={ws:>5}  [{c.reason}]")
    if include_histogram and r.stats is not None and r.group is not None:
        intervals = r.group.intervals_seconds
        if intervals:
            out.append("  Interval histogram (ASCII):")
            out.append(_ascii_histogram(intervals))
    return "\n".join(out)
