"""HTML export — single self-contained file, no external assets."""
from __future__ import annotations

import html
import os
from datetime import datetime, timezone
from typing import List

from ..__init__ import __version__
from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult
from .text_export import _ascii_histogram


CSS = """
body { font-family: 'Segoe UI', 'Helvetica Neue', Arial, sans-serif; margin: 24px; color: #1f2937; }
h1 { color: #0f172a; margin-bottom: 0; }
.meta { color: #6b7280; font-size: 0.9em; margin-top: 4px; }
table { border-collapse: collapse; width: 100%; margin-top: 16px; font-size: 0.9em; }
th, td { border: 1px solid #e5e7eb; padding: 6px 8px; text-align: left; }
th { background: #f3f4f6; font-weight: 600; }
tr.flagged { background: #fef3c7; }
tr.excluded { background: #f3f4f6; color: #6b7280; }
tr.insufficient_evidence { background: #fafafa; color: #9ca3af; }
.status-badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.85em; font-weight: 600; }
.status-flagged { background: #fde68a; color: #78350f; }
.status-not_flagged { background: #dbeafe; color: #1e40af; }
.status-excluded { background: #e5e7eb; color: #374151; }
.status-insufficient_evidence { background: #f3f4f6; color: #6b7280; }
.score-high { font-weight: 700; color: #b45309; }
pre.ascii { background: #f9fafb; border: 1px solid #e5e7eb; padding: 8px; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 0.85em; overflow-x: auto; }
.note { color: #6b7280; font-size: 0.85em; }
.warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 6px 10px; margin: 6px 0; font-size: 0.9em; }
.limitations { background: #eff6ff; border-left: 4px solid #3b82f6; padding: 8px 12px; margin-top: 12px; }
"""


def _esc(s) -> str:
    return html.escape(str(s) if s is not None else "")


def export_html(report: AnalysisReport, path: str, force: bool = False) -> str:
    if os.path.exists(path) and not force:
        raise FileExistsError(f"file already exists: {path}")
    rows_html: List[str] = []
    for r in report.results:
        score_cls = "score-high" if r.status == "flagged" else ""
        dst = f"{_esc(r.destination_address)}:{r.destination_port}/{_esc(r.protocol)}"
        med = f"{r.median_interval:.1f}s" if r.median_interval is not None else "n/a"
        jit = f"{r.jitter_band_fit_pct:.0f}%" if r.jitter_band_fit_pct is not None else "n/a"
        rows_html.append(
            f"<tr class='{r.status}'>"
            f"<td>{r.rank}</td>"
            f"<td><span class='status-badge status-{r.status}'>{_esc(r.status)}</span></td>"
            f"<td>{dst}</td>"
            f"<td class='{score_cls}'>{r.final_score:.1f}</td>"
            f"<td>{r.event_count}</td>"
            f"<td>{r.interval_count}</td>"
            f"<td>{med}</td>"
            f"<td>{jit}</td>"
            f"<td>{r.byte_min or '-'}</td>"
            f"<td>{r.byte_max or '-'}</td>"
            f"<td>{r.source_address_count}</td>"
            f"<td>{_esc(r.first_seen)}</td>"
            f"<td>{_esc(r.last_seen)}</td>"
            f"<td>{_esc(r.key_reason)}</td>"
            f"</tr>"
        )

    warnings_html = ""
    for w in (report.parse_result.warnings + report.exclusion_warnings + report.baseline_warnings):
        warnings_html += f"<div class='warning'>{_esc(str(w))}</div>"

    flagged_blocks = ""
    for r in report.flagged:
        flagged_blocks += (
            "<div class='flagged-detail'>"
            f"<h3>{_esc(r.destination_address)}:{r.destination_port}/{_esc(r.protocol)} "
            f"— score {r.final_score:.1f}</h3>"
            f"<p class='note'>{_esc(r.key_reason)}</p>"
            "<table><tr><th>Component</th><th>Weight</th><th>Raw</th><th>Weighted</th><th>Reason</th></tr>"
        )
        for c in r.components:
            flagged_blocks += (
                "<tr>"
                f"<td>{_esc(c.name)}</td>"
                f"<td>{c.weight:.2f}</td>"
                f"<td>{f'{c.raw_score:.1f}' if c.raw_score is not None else 'n/a'}</td>"
                f"<td>{f'{c.weighted_score:.1f}' if c.used else 'n/a'}</td>"
                f"<td class='note'>{_esc(c.reason)}</td>"
                "</tr>"
            )
        flagged_blocks += "</table>"
        if r.group is not None:
            intervals = r.group.intervals_seconds
            if intervals:
                flagged_blocks += "<p class='note'>Interval histogram (ASCII):</p>"
                flagged_blocks += f"<pre class='ascii'>{_esc(_ascii_histogram(intervals))}</pre>"
        flagged_blocks += "</div>"

    page = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>BeaconHunt Report</title>
<style>{CSS}</style>
</head>
<body>
<h1>BeaconHunt Analysis Report</h1>
<div class="meta">
  Tool: BeaconHunt v{__version__} &middot;
  Generated: {_esc(datetime.now(timezone.utc).isoformat())} &middot;
  Input: {_esc(os.path.basename(report.parse_result.input_source))}
  ({_esc(report.parse_result.input_type)})
</div>
<div class="meta">
  Records seen: {report.parse_result.total_records_seen};
  skipped: {report.parse_result.skipped_records};
  analyzed: {len(report.parse_result.records)}
</div>
<div class="meta">Settings: {_esc(report.config.describe())}</div>
<div class="meta">Flow policy: {_esc(report.flow_policy_note)}</div>
<div class="limitations"><strong>Limitations:</strong> {_esc(report.limitations_note)}</div>
{warnings_html}
<h2>Ranked results</h2>
<table>
<thead><tr>
<th>#</th><th>Status</th><th>Destination</th><th>Score</th>
<th>Ev</th><th>Int</th><th>Median</th><th>JitFit</th>
<th>ByteMin</th><th>ByteMax</th><th>Srcs</th>
<th>First seen</th><th>Last seen</th><th>Reason</th>
</tr></thead>
<tbody>
{''.join(rows_html)}
</tbody>
</table>
{f'<h2>Evidence for flagged destinations</h2>{flagged_blocks}' if flagged_blocks else ''}
</body>
</html>
"""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(page)
    return path
