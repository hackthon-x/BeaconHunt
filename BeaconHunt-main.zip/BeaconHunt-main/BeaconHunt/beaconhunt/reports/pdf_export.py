"""PDF export using ReportLab.

Produces a paginated, ATS-friendly report. Noto Serif SC is registered for
Chinese characters even though the report is English by default, so any
non-ASCII metadata in the input does not crash the build.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
)
from reportlab.platypus.flowables import HRFlowable

from ..__init__ import __version__
from ..analysis.engine import AnalysisReport
from ..analysis.scoring import DestinationResult
from .text_export import _ascii_histogram


_STATUS_COLORS = {
    "flagged":               colors.HexColor("#fde68a"),
    "not_flagged":           colors.HexColor("#dbeafe"),
    "excluded":              colors.HexColor("#e5e7eb"),
    "insufficient_evidence": colors.HexColor("#f3f4f6"),
}


def export_pdf(report: AnalysisReport, path: str, force: bool = False) -> str:
    if os.path.exists(path) and not force:
        raise FileExistsError(f"file already exists: {path}")

    doc = SimpleDocTemplate(
        path, pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=18 * mm, bottomMargin=18 * mm,
        title="BeaconHunt Analysis Report",
    )
    styles = getSampleStyleSheet()
    h1 = styles["Heading1"]
    h2 = styles["Heading2"]
    h3 = styles["Heading3"]
    body = styles["BodyText"]
    body.fontSize = 9
    body.leading = 12
    small = ParagraphStyle("small", parent=body, fontSize=8, textColor=colors.HexColor("#6b7280"))
    mono = ParagraphStyle("mono", parent=body, fontName="Courier", fontSize=7.5, leading=9)

    flow: List = []
    flow.append(Paragraph("BeaconHunt Analysis Report", h1))
    flow.append(Paragraph(
        f"Tool: BeaconHunt v{__version__} &middot; "
        f"Generated: {datetime.now(timezone.utc).isoformat()}", small))
    flow.append(Paragraph(
        f"Input: {os.path.basename(report.parse_result.input_source)} "
        f"({report.parse_result.input_type})", small))
    flow.append(Paragraph(
        f"Records seen: {report.parse_result.total_records_seen}; "
        f"skipped: {report.parse_result.skipped_records}; "
        f"analyzed: {len(report.parse_result.records)}", small))
    flow.append(Paragraph(f"Settings: {report.config.describe()}", small))
    flow.append(Paragraph(f"Flow policy: {report.flow_policy_note}", small))
    flow.append(Spacer(1, 6))
    flow.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#e5e7eb")))
    flow.append(Spacer(1, 6))

    flow.append(Paragraph("Limitations", h2))
    flow.append(Paragraph(report.limitations_note, body))

    if report.parse_result.warnings or report.exclusion_warnings or report.baseline_warnings:
        flow.append(Paragraph("Warnings", h2))
        for w in (report.parse_result.warnings + report.exclusion_warnings + report.baseline_warnings):
            flow.append(Paragraph(f"- {w}", small))

    flow.append(Paragraph("Ranked results", h2))
    header = ["#", "Status", "Destination", "Score", "Ev", "Int", "Median", "JitFit", "Sources"]
    data = [header]
    for r in report.results:
        dst = f"{r.destination_address}:{r.destination_port}/{r.protocol}"
        med = f"{r.median_interval:.1f}s" if r.median_interval is not None else "n/a"
        jit = f"{r.jitter_band_fit_pct:.0f}%" if r.jitter_band_fit_pct is not None else "n/a"
        data.append([
            str(r.rank), r.status, dst, f"{r.final_score:.1f}",
            str(r.event_count), str(r.interval_count), med, jit,
            str(r.source_address_count),
        ])
    tbl = Table(data, colWidths=[10*mm, 28*mm, 50*mm, 14*mm, 10*mm, 10*mm, 18*mm, 14*mm, 16*mm])
    ts = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#e5e7eb")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (0, 1), (0, -1), "RIGHT"),
        ("ALIGN", (3, 1), (3, -1), "RIGHT"),
    ]
    # Color rows by status.
    for i, r in enumerate(report.results, start=1):
        bg = _STATUS_COLORS.get(r.status, colors.white)
        ts.append(("BACKGROUND", (0, i), (-1, i), bg))
    tbl.setStyle(TableStyle(ts))
    flow.append(tbl)

    if report.flagged:
        flow.append(PageBreak())
        flow.append(Paragraph("Evidence for flagged destinations", h2))
        for r in report.flagged:
            flow.append(Paragraph(
                f"{r.destination_address}:{r.destination_port}/{r.protocol} "
                f"— score {r.final_score:.1f}", h3))
            flow.append(Paragraph(f"<i>Reason:</i> {r.key_reason}", body))
            flow.append(Paragraph(
                f"Events: {r.event_count}; intervals: {r.interval_count}; "
                f"sources: {r.source_address_count}", body))
            if r.median_interval is not None:
                flow.append(Paragraph(
                    f"Interval median: {r.median_interval:.2f}s; "
                    f"mean: {r.mean_interval:.2f}s; std: {r.std_interval:.3f}; "
                    f"CV: {r.cv_interval:.3f}" if r.cv_interval is not None
                    else f"Interval median: {r.median_interval:.2f}s; mean: {r.mean_interval:.2f}s; CV: n/a",
                    body))
                flow.append(Paragraph(
                    f"Jitter-band fit: {r.jitter_band_fit_pct:.1f}% "
                    f"({r.jitter_band_fit_count}/{r.interval_count})" if r.jitter_band_fit_pct is not None
                    else "Jitter-band fit: n/a", body))
            if r.byte_count > 0:
                flow.append(Paragraph(
                    f"Byte size: min={r.byte_min}, max={r.byte_max}, "
                    f"mean={r.byte_mean:.0f}, CV={r.byte_cv:.3f} "
                    f"({r.byte_count} samples, {r.byte_missing_count} missing)", body))
            else:
                flow.append(Paragraph("Byte size: not available", body))
            flow.append(Paragraph("Score components:", body))
            comp_data = [["Component", "Weight", "Raw", "Weighted", "Reason"]]
            for c in r.components:
                comp_data.append([
                    c.name, f"{c.weight:.2f}",
                    f"{c.raw_score:.1f}" if c.raw_score is not None else "n/a",
                    f"{c.weighted_score:.1f}" if c.used else "n/a",
                    c.reason,
                ])
            comp_tbl = Table(comp_data, colWidths=[42*mm, 18*mm, 18*mm, 22*mm, 60*mm])
            comp_tbl.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#f3f4f6")),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#e5e7eb")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
            flow.append(comp_tbl)
            if r.group is not None:
                intervals = r.group.intervals_seconds
                if intervals:
                    flow.append(Spacer(1, 4))
                    flow.append(Paragraph("Interval histogram (ASCII):", small))
                    flow.append(Paragraph(
                        _ascii_histogram(intervals).replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br/>"),
                        mono,
                    ))
            flow.append(Spacer(1, 10))

    doc.build(flow)
    return path
