"""Normalized connection record and parser-warning model.

Every parser (PCAP/Scapy, CSV, plain-text) must produce a list of
ConnectionRecord objects. The analysis engine never sees the original file
format — it only consumes these records. This separation is what lets the
analysis engine stay independent of the parser choice.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass(frozen=True)
class ConnectionRecord:
    """One normalized connection event.

    Attributes
    ----------
    timestamp_utc : datetime
        Timezone-aware timestamp normalized to UTC.
    source_address : str
        Source IP address (IPv4 or IPv6) as a string.
    destination_address : str
        Destination IP address.
    destination_port : Optional[int]
        Destination L4 port, or None for protocols without ports.
    protocol : Optional[str]
        L4 protocol name (e.g. "TCP", "UDP") or L3 hint when L4 is unknown.
    byte_size : Optional[int]
        Bytes attributed to this connection/event, or None when the source
        format does not report a byte size. We deliberately use None rather
        than 0 so the analysis engine can distinguish "unknown" from "zero
        bytes captured."
    input_source : str
        Filename plus a packet/line number reference, e.g.
        "capture.pcap#42" or "firewall.log#123".
    direction_hint : Optional[str]
        Optional metadata used by the TCP flow policy to suppress counting
        both directions of a bidirectional flow. Values: "outbound",
        "inbound", or None.
    raw_ref : Optional[int]
        Original packet number or log line number kept for cross-reference.
    """

    timestamp_utc: datetime
    source_address: str
    destination_address: str
    destination_port: Optional[int]
    protocol: Optional[str]
    byte_size: Optional[int]
    input_source: str
    direction_hint: Optional[str] = None
    raw_ref: Optional[int] = None

    def group_key(self, policy: str = "dest_port_protocol") -> tuple:
        """Return the grouping key for this record under the given policy.

        The default policy is (destination_address, destination_port,
        protocol). Alternative policies are documented in the analysis module.
        """
        if policy == "dest_port_protocol":
            return (self.destination_address, self.destination_port, self.protocol)
        if policy == "dest_port":
            return (self.destination_address, self.destination_port)
        if policy == "dest_only":
            return (self.destination_address,)
        # Fallback to default.
        return (self.destination_address, self.destination_port, self.protocol)


@dataclass(frozen=True)
class ParseWarning:
    """A non-fatal parsing issue (malformed row, unknown protocol, ...).

    Warnings are surfaced to the UI with line/packet context and echoed into
    every exported report so the analyst can audit parsing quality.
    """
    input_source: str
    location: str  # e.g. "packet 42", "line 17"
    message: str
    severity: str = "warning"  # warning | error

    def __str__(self) -> str:
        return f"{self.input_source} {self.location}: {self.message}"


def parse_iso_to_utc(value: str) -> datetime:
    """Parse an ISO-8601 or common log timestamp string to UTC datetime.

    Handles a trailing 'Z', explicit offsets like +05:00, and bare naive
    timestamps (treated as UTC and flagged by the caller as needed).
    """
    s = value.strip()
    if not s:
        raise ValueError("empty timestamp")
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError as exc:
        raise ValueError(f"unparseable timestamp {value!r}: {exc}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)
