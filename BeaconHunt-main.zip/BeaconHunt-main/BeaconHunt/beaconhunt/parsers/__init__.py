"""Parsers package — PCAP/Scapy, CSV, plain-text. All produce ConnectionRecord."""
from .base import BaseParser, ParseResult
from .pcap_parser import PcapParser
from .csv_parser import CsvParser, ColumnMapping, CANONICAL_FIELDS, HEADER_ALIASES
from .text_parser import TextParser, NAMED_FORMATS

__all__ = [
    "BaseParser",
    "ParseResult",
    "PcapParser",
    "CsvParser",
    "ColumnMapping",
    "CANONICAL_FIELDS",
    "HEADER_ALIASES",
    "TextParser",
    "NAMED_FORMATS",
]
