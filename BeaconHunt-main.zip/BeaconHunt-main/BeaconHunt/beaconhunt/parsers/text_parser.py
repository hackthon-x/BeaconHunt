"""Plain-text log parser.

Two modes:
  1. Named format — a small set of documented, fixed formats the parser
     knows about (e.g. "firewall_kv" for `SRC=... DST=... DPT=...`).
  2. Custom regex — the user supplies a Python regular expression with named
     groups: `ts`, `src`, `dst`, `dport`, `proto`, `bytes`. The `bytes` group
     is optional; everything else is required.

Both modes produce the same ConnectionRecord type as the PCAP and CSV
parsers, so the analysis engine does not care which input produced the
records.
"""
from __future__ import annotations

import os
import re
from typing import Dict, List, Optional

from ..models.records import ConnectionRecord, ParseWarning, parse_iso_to_utc
from .base import BaseParser, ParseResult


# ---------------------------------------------------------------------------
# Documented named formats
# ---------------------------------------------------------------------------
NAMED_FORMATS: Dict[str, str] = {
    "firewall_kv": (
        r"(?P<ts>\S+)\s+SRC=(?P<src>\S+)\s+DST=(?P<dst>\S+)\s+"
        r"DPT=(?P<dport>\d+)\s+PROTO=(?P<proto>\S+)(?:\s+BYTES=(?P<bytes>\d+))?"
    ),
    "squid_common": (
        r"(?P<ts>\d+\.\d+)\s+\d+\s+(?P<src>\S+)\s+\S+/(?P<proto>\S+)/\d+\.\d+\.\d+\.\d+"
    ),
}


class TextParser(BaseParser):
    """Plain-text log parser."""

    def __init__(self, format_name: Optional[str] = None,
                 custom_regex: Optional[str] = None) -> None:
        if format_name is None and custom_regex is None:
            # Default to the documented firewall_kv format.
            format_name = "firewall_kv"
        if custom_regex:
            try:
                self.pattern = re.compile(custom_regex)
            except re.error as exc:
                raise ValueError(f"invalid regex: {exc}") from exc
            self.format_label = "custom_regex"
        elif format_name in NAMED_FORMATS:
            self.pattern = re.compile(NAMED_FORMATS[format_name])
            self.format_label = format_name
        else:
            raise ValueError(
                f"unknown format {format_name!r}; choose from "
                f"{list(NAMED_FORMATS)} or provide custom_regex"
            )

    def parse(self, path: str) -> ParseResult:
        if not os.path.exists(path):
            raise FileNotFoundError(f"log file not found: {path}")
        if os.path.getsize(path) == 0:
            return ParseResult(
                records=[],
                warnings=[ParseWarning(path, "file", "empty log file", "error")],
                input_type="text",
                input_source=path,
                byte_size_source="reported",
            )

        warnings: List[ParseWarning] = []
        records: List[ConnectionRecord] = []
        total = 0
        skipped = 0

        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for lineno, line in enumerate(fh, start=1):
                total += 1
                line = line.rstrip("\n")
                if not line.strip():
                    continue
                m = self.pattern.search(line)
                if not m:
                    skipped += 1
                    warnings.append(ParseWarning(
                        path, f"line {lineno}",
                        f"line did not match {self.format_label} pattern",
                    ))
                    continue
                gd = m.groupdict()
                ts_raw = gd.get("ts")
                src = gd.get("src")
                dst = gd.get("dst")
                if not ts_raw or not src or not dst:
                    skipped += 1
                    warnings.append(ParseWarning(
                        path, f"line {lineno}",
                        "match missing required groups (ts/src/dst)",
                    ))
                    continue
                try:
                    # Allow Unix epoch floats for the squid_common format.
                    try:
                        ts = parse_iso_to_utc(ts_raw)
                    except ValueError:
                        ts_float = float(ts_raw)
                        from datetime import datetime, timezone
                        ts = datetime.fromtimestamp(ts_float, tz=timezone.utc)
                except Exception as exc:  # noqa: BLE001
                    skipped += 1
                    warnings.append(ParseWarning(path, f"line {lineno}", f"bad timestamp: {exc}"))
                    continue

                dport_raw = gd.get("dport")
                dport: Optional[int] = None
                if dport_raw is not None and dport_raw != "":
                    try:
                        dport = int(dport_raw)
                    except ValueError:
                        skipped += 1
                        warnings.append(ParseWarning(
                            path, f"line {lineno}",
                            f"bad dport {dport_raw!r}",
                        ))
                        continue

                proto = gd.get("proto")
                if proto is not None:
                    proto = proto.upper()

                bytes_raw = gd.get("bytes")
                byte_size: Optional[int] = None
                if bytes_raw is not None and bytes_raw != "":
                    try:
                        byte_size = int(bytes_raw)
                        if byte_size < 0:
                            raise ValueError("negative")
                    except ValueError:
                        warnings.append(ParseWarning(
                            path, f"line {lineno}",
                            f"bad bytes {bytes_raw!r}; setting byte_size=None",
                        ))

                records.append(ConnectionRecord(
                    timestamp_utc=ts,
                    source_address=src,
                    destination_address=dst,
                    destination_port=dport,
                    protocol=proto,
                    byte_size=byte_size,
                    input_source=f"{os.path.basename(path)}#{lineno}",
                    direction_hint=None,
                    raw_ref=lineno,
                ))

        return ParseResult(
            records=records,
            warnings=warnings,
            input_type="text",
            input_source=path,
            byte_size_source="reported",
            total_records_seen=total,
            skipped_records=skipped,
        )
