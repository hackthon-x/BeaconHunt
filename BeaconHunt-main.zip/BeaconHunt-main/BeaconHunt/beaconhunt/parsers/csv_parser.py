"""CSV / TSV log parser with column-mapping support.

The parser accepts an explicit ColumnMapping that maps canonical fields to
the CSV's actual column names. If no mapping is supplied, the parser
auto-detects headers using a small alias dictionary.
"""
from __future__ import annotations

import csv
import os
from typing import Dict, Iterable, Optional

from ..models.records import ConnectionRecord, ParseWarning, parse_iso_to_utc
from .base import BaseParser, ParseResult


CANONICAL_FIELDS = (
    "timestamp",
    "source",
    "destination",
    "destination_port",
    "protocol",
    "bytes",
)

HEADER_ALIASES = {
    "timestamp": {"timestamp", "ts", "time", "datetime", "date", "epoch"},
    "source": {"source", "src", "src_ip", "source_ip", "client"},
    "destination": {"destination", "dst", "dst_ip", "dest", "dest_ip", "server"},
    "destination_port": {"destination_port", "dst_port", "dport", "dest_port", "port", "dpt"},
    "protocol": {"protocol", "proto", "l4_proto", "proto_name"},
    "bytes": {"bytes", "byte_size", "size", "length", "bytes_in", "bytes_out", "size_x"},
}


class ColumnMapping:
    """Maps canonical field names to actual CSV column names."""

    def __init__(
        self,
        timestamp: Optional[str] = None,
        source: Optional[str] = None,
        destination: Optional[str] = None,
        destination_port: Optional[str] = None,
        protocol: Optional[str] = None,
        bytes: Optional[str] = None,
    ) -> None:
        self.timestamp = timestamp
        self.source = source
        self.destination = destination
        self.destination_port = destination_port
        self.protocol = protocol
        self.bytes = bytes

    def as_dict(self) -> Dict[str, Optional[str]]:
        return {
            "timestamp": self.timestamp,
            "source": self.source,
            "destination": self.destination,
            "destination_port": self.destination_port,
            "protocol": self.protocol,
            "bytes": self.bytes,
        }

    @classmethod
    def from_header_row(cls, header: Iterable[str]) -> "ColumnMapping":
        """Auto-detect mapping from the CSV header row."""
        norm = {}
        for raw in header:
            key = raw.strip().lower().replace(" ", "_")
            norm[key] = raw
        mapping = cls()
        for canonical, aliases in HEADER_ALIASES.items():
            for alias in aliases:
                if alias in norm:
                    setattr(mapping, canonical, norm[alias])
                    break
        return mapping

    def missing_required(self) -> list:
        """Return list of canonical fields that are required but unmapped."""
        # timestamp, source, destination are required.
        missing = []
        for field in ("timestamp", "source", "destination"):
            if getattr(self, field) is None:
                missing.append(field)
        return missing


class CsvParser(BaseParser):
    """Parse CSV/TSV logs into normalized ConnectionRecords."""

    def __init__(self, mapping: Optional[ColumnMapping] = None, delimiter: str = ",") -> None:
        self.mapping = mapping
        self.delimiter = delimiter

    def parse(self, path: str) -> ParseResult:
        if not os.path.exists(path):
            raise FileNotFoundError(f"CSV file not found: {path}")
        if os.path.getsize(path) == 0:
            return ParseResult(
                records=[],
                warnings=[ParseWarning(path, "file", "empty CSV file", "error")],
                input_type="csv",
                input_source=path,
                byte_size_source="reported",
            )

        warnings: List[ParseWarning] = []
        records: List[ConnectionRecord] = []
        total = 0
        skipped = 0

        with open(path, "r", newline="", encoding="utf-8", errors="replace") as fh:
            reader = csv.reader(fh, delimiter=self.delimiter)
            try:
                header = next(reader)
            except StopIteration:
                return ParseResult(
                    records=[],
                    warnings=[ParseWarning(path, "file", "CSV has no header row", "error")],
                    input_type="csv",
                    input_source=path,
                    byte_size_source="reported",
                )

            mapping = self.mapping or ColumnMapping.from_header_row(header)
            missing = mapping.missing_required()
            if missing:
                # Build a fallback empty mapping that will warn per-row but
                # still surface the file's header so the user can configure
                # mapping in the GUI.
                warnings.append(ParseWarning(
                    path, "header",
                    f"required column mapping missing for: {', '.join(missing)}; "
                    f"detected header: {header}",
                    "error",
                ))
                # Try to continue with whatever we have, skipping rows.

            idx = {name: i for i, name in enumerate(header)}

            def get(row, canonical):
                col = getattr(mapping, canonical, None)
                if col is None or col not in idx:
                    return None
                if idx[col] >= len(row):
                    return None
                v = row[idx[col]].strip()
                return v if v != "" else None

            for lineno, row in enumerate(reader, start=2):
                total += 1
                ts_raw = get(row, "timestamp")
                src = get(row, "source")
                dst = get(row, "destination")
                if not ts_raw or not src or not dst:
                    skipped += 1
                    warnings.append(ParseWarning(
                        path, f"line {lineno}",
                        f"skipped row: missing required field "
                        f"(ts={'yes' if ts_raw else 'no'}, "
                        f"src={'yes' if src else 'no'}, "
                        f"dst={'yes' if dst else 'no'})",
                    ))
                    continue
                try:
                    ts = parse_iso_to_utc(ts_raw)
                except ValueError as exc:
                    skipped += 1
                    warnings.append(ParseWarning(path, f"line {lineno}", f"bad timestamp: {exc}"))
                    continue

                dport_raw = get(row, "destination_port")
                dport: Optional[int] = None
                if dport_raw is not None:
                    try:
                        dport = int(dport_raw)
                        if not (0 <= dport <= 65535):
                            raise ValueError("out of range")
                    except ValueError:
                        skipped += 1
                        warnings.append(ParseWarning(
                            path, f"line {lineno}",
                            f"bad destination_port {dport_raw!r}",
                        ))
                        continue

                proto = get(row, "protocol")
                if proto is not None:
                    proto = proto.upper()

                bytes_raw = get(row, "bytes")
                byte_size: Optional[int] = None
                if bytes_raw is not None:
                    try:
                        bs = int(bytes_raw)
                        if bs < 0:
                            raise ValueError("negative")
                        byte_size = bs
                    except ValueError:
                        skipped += 1
                        warnings.append(ParseWarning(
                            path, f"line {lineno}",
                            f"bad byte count {bytes_raw!r}",
                        ))
                        continue

                records.append(ConnectionRecord(
                    timestamp_utc=ts,
                    source_address=src,
                    destination_address=dst,
                    destination_port=dport,
                    protocol=proto,
                    byte_size=byte_size,
                    input_source=f"{os.path.basename(path)}#{lineno}",
                    direction_hint=None,
                    raw_ref=lineno,
                ))

        return ParseResult(
            records=records,
            warnings=warnings,
            input_type="csv",
            input_source=path,
            byte_size_source="reported",
            total_records_seen=total,
            skipped_records=skipped,
        )
