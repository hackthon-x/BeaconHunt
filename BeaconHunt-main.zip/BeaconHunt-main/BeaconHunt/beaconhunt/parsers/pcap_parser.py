"""Offline PCAP/PCAPNG parser built on Scapy.

Why Scapy rather than dpkt
--------------------------
Both libraries are suitable for offline parsing. Scapy is used here because:

  1. It supports PCAPNG and IPv6 cleanly out of the box.
  2. Its high-level layer access (`pkt[IP].src`, `pkt[TCP].dport`) yields
     parser code that is easy to read and audit, which matters for a
     defensive tool whose parsing logic must be reviewable.
  3. It does not require live capture privileges; `rdpcap()` is purely
     offline.

The parser is hidden behind the BaseParser interface, so swapping to dpkt
later would not touch the analysis engine.

Safety
------
This module never opens a socket, sends a packet, or resolves a hostname.
Scapy's `conf.L3socket`/`conf.L2socket` are not used. The only Scapy entry
point invoked is `rdpcap()` for offline reading.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List, Optional

# Suppress Scapy's noisy runtime warnings at import time.
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

from scapy.all import rdpcap, IP, IPv6, TCP, UDP, Raw  # noqa: E402

from ..models.records import ConnectionRecord, ParseWarning
from .base import BaseParser, ParseResult


# TCP flags bitmask helpers
TCP_SYN = 0x02
TCP_ACK = 0x10


class PcapParser(BaseParser):
    """Parse PCAP/PCAPNG files into normalized ConnectionRecords.

    Flow / event policy
    -------------------
    For TCP, the default event policy is `syn_no_ack`: a connection event
    is recorded when a packet has the SYN flag set and the ACK flag clear
    (i.e. an initiating SYN). This prevents counting both directions of a
    bidirectional flow as separate outbound connections. If the capture has
    no observable SYN-no-ACK packets (e.g. a capture started mid-flow), the
    `first_seen` policy treats the first packet of each (src, dst, dport,
    proto) tuple as the connection event and adds a warning.

    For UDP, no connection-start flag exists. We use a configurable idle
    timeout (default 120 s): a new event is recorded when the gap since the
    last packet in the same flow exceeds the timeout.

    Byte size
    ---------
    `byte_size_source` is configurable. By default the parser uses the
    *captured* frame length (`len(pkt)`), not the original wire length,
    because the captured length is what an analyst can reproduce from the
    file. Scapy exposes the wire length as `pkt.wirelen` when available;
    pass `byte_size_source='wire'` to use it instead. The chosen source is
    recorded in ParseResult so reports can document it.
    """

    def __init__(
        self,
        tcp_event_policy: str = "syn_no_ack",
        udp_idle_timeout: float = 120.0,
        byte_size_source: str = "captured",
    ) -> None:
        if tcp_event_policy not in ("syn_no_ack", "first_seen"):
            raise ValueError(
                f"unknown tcp_event_policy {tcp_event_policy!r}; "
                "expected 'syn_no_ack' or 'first_seen'"
            )
        if byte_size_source not in ("captured", "wire", "reported"):
            raise ValueError(
                f"unknown byte_size_source {byte_size_source!r}"
            )
        self.tcp_event_policy = tcp_event_policy
        self.udp_idle_timeout = float(udp_idle_timeout)
        self.byte_size_source = byte_size_source

    def parse(self, path: str) -> ParseResult:
        if not os.path.exists(path):
            raise FileNotFoundError(f"PCAP file not found: {path}")
        if os.path.getsize(path) == 0:
            return ParseResult(
                records=[], warnings=[ParseWarning(path, "file", "empty PCAP file", "error")],
                input_type="pcap", input_source=path,
                byte_size_source=self.byte_size_source,
            )

        warnings: List[ParseWarning] = []
        records: List[ConnectionRecord] = []
        total = 0
        try:
            packets = rdpcap(path)
        except Exception as exc:  # noqa: BLE001 - parser must surface the cause
            return ParseResult(
                records=[],
                warnings=[ParseWarning(path, "file", f"PCAP unreadable: {exc}", "error")],
                input_type="pcap",
                input_source=path,
                byte_size_source=self.byte_size_source,
            )

        # UDP idle-timeout state keyed by (src, dst, dport, proto).
        udp_last_ts: dict = {}
        # TCP first-seen state used by both policies.
        tcp_seen_keys: set = set()
        first_seen_used = False

        for i, pkt in enumerate(packets, start=1):
            total += 1
            try:
                ts = self._extract_ts(pkt)
            except Exception as exc:  # noqa: BLE001
                warnings.append(ParseWarning(path, f"packet {i}", f"bad timestamp: {exc}"))
                continue

            l3 = pkt[IP] if IP in pkt else (pkt[IPv6] if IPv6 in pkt else None)
            if l3 is None:
                # Non-IP traffic (ARP, etc.) is skipped silently; it is not
                # connection-oriented and cannot beacon.
                continue

            src = getattr(l3, "src", None)
            dst = getattr(l3, "dst", None)
            if not src or not dst:
                warnings.append(ParseWarning(path, f"packet {i}", "missing L3 addresses"))
                continue

            if TCP in pkt:
                proto = "TCP"
                l4 = pkt[TCP]
            elif UDP in pkt:
                proto = "UDP"
                l4 = pkt[UDP]
            else:
                # Non-TCP/UDP IP traffic — record with protocol name from IP.
                proto = self._ip_protocol_name(l3)
                l4 = None

            dport = int(l4.dport) if l4 is not None and hasattr(l4, "dport") else None
            byte_size = self._extract_bytes(pkt)

            if proto == "TCP":
                key = (src, dst, dport, proto)
                if self.tcp_event_policy == "syn_no_ack":
                    flags = int(getattr(l4, "flags", 0))
                    is_init_syn = bool(flags & TCP_SYN) and not (flags & TCP_ACK)
                    if is_init_syn:
                        records.append(ConnectionRecord(
                            timestamp_utc=ts,
                            source_address=src,
                            destination_address=dst,
                            destination_port=dport,
                            protocol=proto,
                            byte_size=byte_size,
                            input_source=f"{os.path.basename(path)}#{i}",
                            direction_hint="outbound",
                            raw_ref=i,
                        ))
                    # else: mid-flow packet, do not create a new event.
                else:  # first_seen policy
                    if key not in tcp_seen_keys:
                        tcp_seen_keys.add(key)
                        records.append(ConnectionRecord(
                            timestamp_utc=ts,
                            source_address=src,
                            destination_address=dst,
                            destination_port=dport,
                            protocol=proto,
                            byte_size=byte_size,
                            input_source=f"{os.path.basename(path)}#{i}",
                            direction_hint="outbound",
                            raw_ref=i,
                        ))
                    first_seen_used = True

            elif proto == "UDP":
                key = (src, dst, dport, proto)
                last = udp_last_ts.get(key)
                if last is None or (ts - last).total_seconds() > self.udp_idle_timeout:
                    records.append(ConnectionRecord(
                        timestamp_utc=ts,
                        source_address=src,
                        destination_address=dst,
                        destination_port=dport,
                        protocol=proto,
                        byte_size=byte_size,
                        input_source=f"{os.path.basename(path)}#{i}",
                        direction_hint="outbound",
                        raw_ref=i,
                    ))
                udp_last_ts[key] = ts

            else:
                # Non-TCP/UDP IP traffic — record each packet as a distinct
                # event with protocol name. These are uncommon in beacon
                # captures but we surface them for completeness.
                records.append(ConnectionRecord(
                    timestamp_utc=ts,
                    source_address=src,
                    destination_address=dst,
                    destination_port=dport,
                    protocol=proto,
                    byte_size=byte_size,
                    input_source=f"{os.path.basename(path)}#{i}",
                    direction_hint="outbound",
                    raw_ref=i,
                ))

        if first_seen_used and self.tcp_event_policy == "first_seen":
            warnings.append(ParseWarning(
                path, "policy",
                "TCP event policy 'first_seen' is a heuristic; "
                "no SYN-only packets were required. Mid-flow captures may "
                "produce false positives.",
            ))

        if total == 0:
            warnings.append(ParseWarning(path, "file", "PCAP contained no packets", "error"))

        result = ParseResult(
            records=records,
            warnings=warnings,
            input_type="pcap",
            input_source=path,
            byte_size_source=self.byte_size_source,
            total_records_seen=total,
        )
        return result

    # --- helpers --------------------------------------------------------
    @staticmethod
    def _extract_ts(pkt) -> datetime:
        ts = float(getattr(pkt, "time", 0.0))
        return datetime.fromtimestamp(ts, tz=timezone.utc)

    def _extract_bytes(self, pkt) -> Optional[int]:
        if self.byte_size_source == "wire":
            wl = getattr(pkt, "wirelen", None)
            if wl is not None and wl >= 0:
                return int(wl)
            # Fall back to captured length if wire length is unavailable.
            return int(len(pkt))
        if self.byte_size_source == "reported":
            # 'reported' means "the L4 payload length" if present.
            if Raw in pkt:
                return int(len(pkt[Raw].load))
            return None
        # captured (default)
        return int(len(pkt))

    @staticmethod
    def _ip_protocol_name(l3) -> str:
        proto_num = getattr(l3, "proto", None) or getattr(l3, "nh", None)
        names = {1: "ICMP", 2: "IGMP", 6: "TCP", 17: "UDP", 58: "ICMPv6", 89: "OSPF"}
        if proto_num is not None:
            return names.get(int(proto_num), f"IP-{int(proto_num)}")
        return "IP"
