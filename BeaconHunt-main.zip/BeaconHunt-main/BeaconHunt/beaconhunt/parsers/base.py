"""Parser interface and shared utilities.

Every parser implements `parse(path) -> ParseResult`, where ParseResult
contains normalized ConnectionRecords plus any ParseWarnings. The analysis
engine is fully decoupled from the parser implementation: swapping Scapy for
dpkt only requires writing a new PcapParser class that produces the same
ConnectionRecord objects.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional

from ..models.records import ConnectionRecord, ParseWarning


@dataclass
class ParseResult:
    """Output of one parser run."""
    records: List[ConnectionRecord] = field(default_factory=list)
    warnings: List[ParseWarning] = field(default_factory=list)
    input_type: str = "unknown"   # pcap | pcapng | csv | text | unknown
    input_source: str = ""        # file path
    byte_size_source: str = "captured"  # documentation field echoed into reports
    total_records_seen: int = 0   # rows/packets seen before validation
    skipped_records: int = 0      # rows/packets skipped due to validation

    def __post_init__(self) -> None:
        self.skipped_records = self.total_records_seen - len(self.records) \
            if self.total_records_seen >= len(self.records) else self.skipped_records


class BaseParser(ABC):
    """Abstract parser interface."""

    @abstractmethod
    def parse(self, path: str) -> ParseResult:
        """Parse the given file and return normalized records + warnings."""
        raise NotImplementedError

    @staticmethod
    def detect_input_type(path: str) -> str:
        """Detect input type from filename extension and magic bytes."""
        lower = path.lower()
        if lower.endswith(".pcap") or lower.endswith(".pcapng") or lower.endswith(".cap"):
            return "pcap"
        if lower.endswith(".csv") or lower.endswith(".tsv"):
            return "csv"
        if lower.endswith(".txt") or lower.endswith(".log"):
            return "text"
        # Fall back to magic-byte sniffing.
        try:
            with open(path, "rb") as fh:
                head = fh.read(4)
            if head[:4] in (b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\xc3\xd4",
                            b"\x4d\x3c\xb2\xa1", b"\xa1\xb2\x3c\x4d",
                            b"\x0a\x0d\x0d\x0a"):
                return "pcap"
        except OSError:
            pass
        return "unknown"
