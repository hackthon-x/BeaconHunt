"""High-level analysis pipeline that ties parsers, grouping, statistics,
scoring, exclusions, and baseline comparison together."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from ..config.settings import AnalysisConfig
from ..models.records import ConnectionRecord, ParseWarning
from ..parsers.base import ParseResult
from .grouping import group_records
from .scoring import DestinationResult, score_group, rank_results
from .exclusions import ExclusionList, Baseline, load_exclusion_list, load_baseline


@dataclass
class AnalysisReport:
    """Final output of an analysis run, ready for the UI and exporters."""
    config: AnalysisConfig
    parse_result: ParseResult
    results: List[DestinationResult] = field(default_factory=list)
    exclusion_warnings: List[ParseWarning] = field(default_factory=list)
    baseline_warnings: List[ParseWarning] = field(default_factory=list)
    flow_policy_note: str = ""
    limitations_note: str = ""

    @property
    def flagged(self) -> List[DestinationResult]:
        return [r for r in self.results if r.status == "flagged"]

    @property
    def new_in_baseline(self) -> List[DestinationResult]:
        return [r for r in self.results if r.baseline_status == "new"]


def run_analysis(
    parse_result: ParseResult,
    config: AnalysisConfig,
    exclusion_path: Optional[str] = None,
    baseline_path: Optional[str] = None,
) -> AnalysisReport:
    """Run the full pipeline on a ParseResult."""
    records = parse_result.records
    exclusion_list: Optional[ExclusionList] = None
    if exclusion_path:
        exclusion_list = load_exclusion_list(exclusion_path)

    baseline: Optional[Baseline] = None
    if baseline_path:
        baseline = load_baseline(baseline_path, config.as_dict())

    groups = group_records(records, config)
    results: List[DestinationResult] = []
    known_keys = baseline.known_keys() if baseline else set()

    for g in groups:
        r = score_group(g, config)
        # Exclusions
        if exclusion_list is not None:
            hit = exclusion_list.matches(r.destination_address, r.destination_port)
            if hit is not None:
                r.status = "excluded"
                r.exclusion_reason = hit
                r.key_reason = f"matched exclusion entry: {hit}"
        # Baseline
        if baseline is not None:
            key = (r.destination_address, r.destination_port, r.protocol)
            if key in known_keys:
                r.baseline_status = "known"
            else:
                r.baseline_status = "new"
        results.append(r)

    results = rank_results(results)

    flow_policy = (
        f"TCP event policy: {config.tcp_event_policy}; "
        f"UDP idle timeout: {config.udp_idle_timeout}s; "
        f"grouping policy: {config.grouping_policy}; "
        f"byte_size_source: {config.byte_size_source}"
    )
    limitations = (
        "Metadata-only analysis. A high regularity score indicates "
        "suspicious periodicity, not proof of command-and-control. "
        "Legitimate scheduled services (software update checks, monitoring "
        "agents, NTP, telemetry) can also produce beacon-like patterns. "
        "Always correlate with asset ownership and policy before acting."
    )

    return AnalysisReport(
        config=config,
        parse_result=parse_result,
        results=results,
        exclusion_warnings=(exclusion_list.warnings if exclusion_list else []),
        baseline_warnings=(baseline.load_warnings if baseline else []),
        flow_policy_note=flow_policy,
        limitations_note=limitations,
    )
