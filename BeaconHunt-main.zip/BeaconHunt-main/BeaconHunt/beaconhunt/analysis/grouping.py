"""Grouping and interval computation.

Sort records by timestamp, group by destination address + port + protocol,
and compute intervals (in seconds) between successive events in each group.

N events produce N-1 intervals. Groups with fewer than `min_events` records
produce zero intervals and are marked "insufficient_evidence" downstream.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from ..models.records import ConnectionRecord
from ..config.settings import AnalysisConfig


@dataclass
class Group:
    """One destination group and its observed events + computed intervals."""
    key: Tuple
    destination_address: str
    destination_port: int
    protocol: str
    events: List[ConnectionRecord] = field(default_factory=list)

    @property
    def event_count(self) -> int:
        return len(self.events)

    @property
    def interval_count(self) -> int:
        """Number of intervals = N-1 where N is the event count."""
        return max(0, len(self.events) - 1)

    @property
    def source_addresses(self) -> List[str]:
        return sorted({e.source_address for e in self.events})

    @property
    def source_address_count(self) -> int:
        return len(self.source_addresses)

    @property
    def first_seen(self):
        return self.events[0].timestamp_utc if self.events else None

    @property
    def last_seen(self):
        return self.events[-1].timestamp_utc if self.events else None

    @property
    def intervals_seconds(self) -> List[float]:
        """Return the list of inter-event intervals in seconds."""
        if len(self.events) < 2:
            return []
        out = []
        for a, b in zip(self.events, self.events[1:]):
            delta = (b.timestamp_utc - a.timestamp_utc).total_seconds()
            out.append(float(delta))
        return out

    @property
    def byte_sizes(self) -> List[int]:
        """Return non-None byte sizes (missing values are excluded, not zeroed)."""
        return [e.byte_size for e in self.events if e.byte_size is not None]


def group_records(records: List[ConnectionRecord], config: AnalysisConfig) -> List[Group]:
    """Group records by the configured policy and sort within group by time."""
    if not records:
        return []
    grouped: Dict[Tuple, Group] = {}
    for rec in records:
        key = rec.group_key(config.grouping_policy)
        if key not in grouped:
            grouped[key] = Group(
                key=key,
                destination_address=rec.destination_address,
                destination_port=rec.destination_port if rec.destination_port is not None else 0,
                protocol=rec.protocol or "UNKNOWN",
                events=[],
            )
        grouped[key].events.append(rec)
    groups = list(grouped.values())
    for g in groups:
        g.events.sort(key=lambda r: r.timestamp_utc)
    return groups
