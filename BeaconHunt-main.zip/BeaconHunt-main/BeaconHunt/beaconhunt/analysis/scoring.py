"""Scoring and ranking.

Each qualifying group (>= min_events) is scored on a transparent 0-100 scale
combining four components:

  1. Interval regularity      (default weight 0.35)
  2. Jitter consistency       (default weight 0.30) — uses jitter-band fit %
     when base_period > 0; otherwise falls back to relative jitter.
  3. Byte-size consistency    (default weight 0.20) — uses byte-size CV.
  4. Connection-count support (default weight 0.15) — rewards more events
     up to a saturating cap.

Each component is normalized to 0-100. Missing components are dropped and
the remaining weights are renormalized to sum to 1.0. A destination is
NEVER given a zero score merely because byte-size data is unavailable.

A destination is labeled:
  * flagged            — meets min_events AND final_score >= score_threshold
  * not_flagged        — meets min_events AND final_score < score_threshold
  * insufficient_evidence — event_count < min_events
  * excluded           — matched an exclusion-list entry (assigned by caller)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from ..config.settings import AnalysisConfig, ScoringWeights
from ..models.records import ConnectionRecord
from .grouping import Group
from .statistics import GroupStatistics, compute_statistics


# Saturating cap for the connection-count component.
# 12+ events already provide strong statistical support; we cap at 24 so
# that very large groups do not dominate the score solely on count.
CONN_COUNT_CAP = 24


@dataclass
class ComponentScore:
    name: str
    weight: float
    raw_score: Optional[float]
    weighted_score: float
    used: bool
    reason: str = ""


@dataclass
class DestinationResult:
    """One row of the ranked results table."""
    rank: int = 0
    status: str = "not_flagged"  # flagged | not_flagged | excluded | insufficient_evidence
    destination_address: str = ""
    destination_port: int = 0
    protocol: str = ""
    final_score: float = 0.0
    event_count: int = 0
    interval_count: int = 0
    mean_interval: Optional[float] = None
    median_interval: Optional[float] = None
    std_interval: Optional[float] = None
    cv_interval: Optional[float] = None
    absolute_jitter: Optional[float] = None
    relative_jitter_pct: Optional[float] = None
    jitter_band_fit_count: int = 0
    jitter_band_fit_pct: Optional[float] = None
    byte_min: Optional[int] = None
    byte_max: Optional[int] = None
    byte_mean: Optional[float] = None
    byte_cv: Optional[float] = None
    byte_count: int = 0
    byte_missing_count: int = 0
    first_seen: Optional[str] = None
    last_seen: Optional[str] = None
    source_address_count: int = 0
    baseline_status: str = "n/a"  # n/a | known | new
    exclusion_reason: Optional[str] = None
    key_reason: str = ""
    components: List[ComponentScore] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)
    # Back-references for the details view.
    group: Optional[Group] = None
    stats: Optional[GroupStatistics] = None


def _interval_regularity_score(stats: GroupStatistics) -> Tuple[Optional[float], str]:
    """Lower CV => higher score. CV is bounded for sanity."""
    if stats.cv_interval is None:
        return None, "CV unavailable (zero mean or fewer than 2 intervals)"
    cv = max(0.0, min(stats.cv_interval, 2.0))
    score = 100.0 * max(0.0, 1.0 - cv / 0.5)  # CV <= 0.5 -> full; CV >= 0.5 -> 0
    if cv < 0.1:
        reason = f"very low CV ({cv:.3f})"
    elif cv < 0.3:
        reason = f"low CV ({cv:.3f})"
    else:
        reason = f"high CV ({cv:.3f})"
    return float(score), reason


def _jitter_consistency_score(stats: GroupStatistics) -> Tuple[Optional[float], str]:
    """Use jitter-band fit % when base_period > 0; else relative jitter."""
    if stats.jitter_band_fit_pct is not None:
        s = float(stats.jitter_band_fit_pct)
        return s, f"jitter-band fit: {s:.1f}% of intervals within ± band"
    if stats.relative_jitter_pct is not None:
        # Lower relative jitter => higher score. 0% -> 100; 50%+ -> 0.
        rj = max(0.0, min(stats.relative_jitter_pct, 50.0))
        s = 100.0 * (1.0 - rj / 50.0)
        return float(s), f"relative jitter {rj:.1f}%"
    return None, "jitter metrics unavailable"


def _byte_size_consistency_score(stats: GroupStatistics) -> Tuple[Optional[float], str]:
    if stats.byte_cv is None or stats.byte_count < 2:
        return None, "byte-size data insufficient or missing"
    cv = max(0.0, min(stats.byte_cv, 1.0))
    s = 100.0 * (1.0 - cv)
    return float(s), f"byte-size CV {cv:.3f} over {stats.byte_count} samples"


def _connection_count_score(stats: GroupStatistics) -> Tuple[float, str]:
    n = stats.event_count
    # Saturating curve: 5 events -> ~56, 10 -> ~83, 24+ -> 100.
    raw = 100.0 * (1.0 - math.exp(-n / 8.0))
    capped = min(raw, 100.0)
    return float(capped), f"{n} events"


def score_group(group: Group, config: AnalysisConfig) -> DestinationResult:
    """Score one group and produce a DestinationResult (without rank)."""
    stats = compute_statistics(group, config)
    result = DestinationResult(
        destination_address=group.destination_address,
        destination_port=group.destination_port,
        protocol=group.protocol,
        event_count=stats.event_count,
        interval_count=stats.interval_count,
        mean_interval=stats.mean_interval,
        median_interval=stats.median_interval,
        std_interval=stats.std_interval,
        cv_interval=stats.cv_interval,
        absolute_jitter=stats.absolute_jitter,
        relative_jitter_pct=stats.relative_jitter_pct,
        jitter_band_fit_count=stats.jitter_band_fit_count,
        jitter_band_fit_pct=stats.jitter_band_fit_pct,
        byte_min=stats.byte_min,
        byte_max=stats.byte_max,
        byte_mean=stats.byte_mean,
        byte_cv=stats.byte_cv,
        byte_count=stats.byte_count,
        byte_missing_count=stats.byte_missing_count,
        first_seen=group.first_seen.isoformat() if group.first_seen else None,
        last_seen=group.last_seen.isoformat() if group.last_seen else None,
        source_address_count=stats.source_address_count,
        notes=list(stats.notes),
        group=group,
        stats=stats,
    )

    if stats.event_count < config.min_events:
        result.status = "insufficient_evidence"
        result.key_reason = (
            f"only {stats.event_count} event(s); minimum is {config.min_events}"
        )
        result.final_score = 0.0
        return result

    # Compute component scores.
    w = config.weights
    raw_components = {
        "interval_regularity":   (w.interval_regularity,   *_interval_regularity_score(stats)),
        "jitter_consistency":    (w.jitter_consistency,    *_jitter_consistency_score(stats)),
        "byte_size_consistency": (w.byte_size_consistency, *_byte_size_consistency_score(stats)),
        "connection_count":      (w.connection_count_support, *_connection_count_score(stats)),
    }
    components: List[ComponentScore] = []
    used_weight_total = 0.0
    used_weighted_sum = 0.0
    for name, (weight, raw_score, reason) in raw_components.items():
        used = raw_score is not None
        components.append(ComponentScore(
            name=name,
            weight=weight,
            raw_score=raw_score,
            weighted_score=(raw_score * weight) if used else 0.0,
            used=used,
            reason=reason,
        ))
        if used:
            used_weight_total += weight
            used_weighted_sum += raw_score * weight

    # Renormalize weights over used components only.
    if used_weight_total > 0:
        final = used_weighted_sum / used_weight_total
    else:
        final = 0.0
    # Re-scale each component's weighted_score to reflect renormalization,
    # so the displayed breakdown still sums to `final`.
    if used_weight_total > 0:
        scale = 1.0 / used_weight_total
        for c in components:
            if c.used:
                c.weighted_score = c.raw_score * c.weight * scale

    result.components = components
    result.final_score = round(float(final), 2)
    if result.final_score >= config.score_threshold:
        result.status = "flagged"
        result.key_reason = (
            f"score {result.final_score:.1f} >= threshold "
            f"{config.score_threshold:.1f} over {stats.event_count} events"
        )
    else:
        result.status = "not_flagged"
        result.key_reason = (
            f"score {result.final_score:.1f} below threshold "
            f"{config.score_threshold:.1f}"
        )
    return result


def rank_results(results: List[DestinationResult]) -> List[DestinationResult]:
    """Assign ranks: highest score first, with flagged before not-flagged."""
    # We rank only non-excluded, non-insufficient results for the top
    # positions but keep all results in the table.
    def sort_key(r: DestinationResult) -> Tuple:
        status_priority = {
            "flagged": 0,
            "not_flagged": 1,
            "insufficient_evidence": 2,
            "excluded": 3,
        }.get(r.status, 4)
        return (status_priority, -r.final_score, r.destination_address,
                r.destination_port, r.protocol)
    ordered = sorted(results, key=sort_key)
    for i, r in enumerate(ordered, start=1):
        r.rank = i
    return ordered


def analyze_records(
    records: List[ConnectionRecord], config: AnalysisConfig,
) -> List[DestinationResult]:
    """Full pipeline: group -> score -> rank. Exclusions are applied by caller."""
    groups = _group_records_safe(records, config)
    results = [score_group(g, config) for g in groups]
    return rank_results(results)


def _group_records_safe(records: List[ConnectionRecord], config: AnalysisConfig) -> List[Group]:
    # Local import to avoid a circular dependency at module load time.
    from .grouping import group_records
    return group_records(records, config)
