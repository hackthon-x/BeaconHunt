"""Exclusion-list and baseline handling.

Exclusion list format
---------------------
Plain-text, one entry per line. Lines starting with `#` are comments.
Blank lines are ignored. Each entry is either:
  * an exact IP address           -> 192.0.2.5
  * an address:port pair           -> 192.0.2.5:443
  * a CIDR range (IPv4 only)       -> 192.0.2.0/24
Hostname exclusions are NOT supported because BeaconHunt never resolves
hostnames online. If a hostname is encountered in the list, the line is
flagged as invalid and ignored with a visible warning.

Baseline format
---------------
Local JSON file with:
  {
    "tool": "BeaconHunt",
    "version": "1.0.0",
    "created_at": "ISO-8601 UTC",
    "settings": { ... analysis settings at creation time ... },
    "destinations": [
      {"destination_address": "...", "destination_port": 443, "protocol": "TCP"},
      ...
    ]
  }

Baselines are NEVER overwritten silently. Each create/update requires an
explicit user action, and the GUI confirms before replacing an existing
file.
"""
from __future__ import annotations

import ipaddress
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set, Tuple

from ..__init__ import __version__
from ..models.records import ParseWarning


@dataclass
class ExclusionEntry:
    """One parsed exclusion-list entry."""
    raw: str
    address: Optional[str] = None       # exact IP string, normalized
    port: Optional[int] = None
    network: Optional[ipaddress._BaseNetwork] = None  # CIDR
    invalid_reason: Optional[str] = None


@dataclass
class ExclusionList:
    entries: List[ExclusionEntry] = field(default_factory=list)
    warnings: List[ParseWarning] = field(default_factory=list)
    source_file: str = ""

    def matches(self, address: str, port: Optional[int]) -> Optional[str]:
        """Return the matching raw entry string, or None if no match."""
        for e in self.entries:
            if e.invalid_reason:
                continue
            if e.network is not None:
                try:
                    ip = ipaddress.ip_address(address)
                    if ip in e.network:
                        return e.raw
                except ValueError:
                    continue
                continue
            if e.address == address:
                if e.port is None or (port is not None and e.port == port):
                    return e.raw
        return None


def load_exclusion_list(path: str) -> ExclusionList:
    """Parse an exclusion-list file into an ExclusionList."""
    if not os.path.exists(path):
        return ExclusionList(warnings=[ParseWarning(
            path, "file", "exclusion file not found", "error"
        )])
    out = ExclusionList(source_file=path)
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for lineno, raw in enumerate(fh, start=1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            entry = ExclusionEntry(raw=line)
            # Try address:port
            if ":" in line and not line.startswith("["):
                addr_part, _, port_part = line.rpartition(":")
                try:
                    entry.port = int(port_part)
                    if not (0 <= entry.port <= 65535):
                        raise ValueError("port out of range")
                    entry.address = _normalize_addr(addr_part)
                    if entry.address is None:
                        # maybe IPv6 in brackets
                        if addr_part.startswith("[") and addr_part.endswith("]"):
                            entry.address = _normalize_addr(addr_part[1:-1])
                except ValueError:
                    entry.invalid_reason = f"invalid port in {line!r}"
                    out.warnings.append(ParseWarning(
                        path, f"line {lineno}", entry.invalid_reason))
                    out.entries.append(entry)
                    continue
            else:
                # Try CIDR first, then plain address.
                if "/" in line:
                    try:
                        entry.network = ipaddress.ip_network(line, strict=False)
                    except ValueError as exc:
                        entry.invalid_reason = f"invalid CIDR {line!r}: {exc}"
                        out.warnings.append(ParseWarning(
                            path, f"line {lineno}", entry.invalid_reason))
                else:
                    addr = _normalize_addr(line)
                    if addr is None:
                        entry.invalid_reason = (
                            f"hostname exclusions are not supported "
                            f"(would require online DNS): {line!r}"
                        )
                        out.warnings.append(ParseWarning(
                            path, f"line {lineno}", entry.invalid_reason))
                    else:
                        entry.address = addr
            out.entries.append(entry)
    return out


def _normalize_addr(s: str) -> Optional[str]:
    try:
        ip = ipaddress.ip_address(s)
        return str(ip)
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------
@dataclass
class Baseline:
    tool: str
    version: str
    created_at: str
    settings: Dict
    destinations: List[Dict]
    source_file: str = ""
    load_warnings: List[ParseWarning] = field(default_factory=list)
    incompatible_reason: Optional[str] = None

    def known_keys(self) -> Set[Tuple[str, int, str]]:
        """Return the set of (dst, port, proto) tuples in the baseline."""
        keys: Set[Tuple[str, int, str]] = set()
        for d in self.destinations:
            addr = d.get("destination_address")
            port = d.get("destination_port")
            proto = (d.get("protocol") or "UNKNOWN")
            if addr is not None and port is not None:
                keys.add((addr, int(port), proto))
        return keys


def load_baseline(path: str, current_settings: Optional[Dict] = None) -> Baseline:
    """Load a baseline JSON file and validate compatibility."""
    if not os.path.exists(path):
        return Baseline(
            tool="BeaconHunt", version=__version__,
            created_at=datetime.now(timezone.utc).isoformat(),
            settings={}, destinations=[],
            load_warnings=[ParseWarning(path, "file", "baseline file not found", "error")],
        )
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        return Baseline(
            tool="BeaconHunt", version=__version__,
            created_at=datetime.now(timezone.utc).isoformat(),
            settings={}, destinations=[],
            load_warnings=[ParseWarning(path, "file", f"baseline unreadable: {exc}", "error")],
        )

    bl = Baseline(
        tool=data.get("tool", "unknown"),
        version=data.get("version", "unknown"),
        created_at=data.get("created_at", ""),
        settings=data.get("settings", {}),
        destinations=data.get("destinations", []),
        source_file=path,
    )
    # Compatibility check: we only warn (we do not refuse) when settings
    # differ; the comparison is informational.
    if current_settings:
        for k in ("grouping_policy",):
            if bl.settings.get(k) and current_settings.get(k) and \
               bl.settings.get(k) != current_settings.get(k):
                bl.incompatible_reason = (
                    f"baseline setting {k}={bl.settings.get(k)!r} differs "
                    f"from current {current_settings.get(k)!r}; comparison "
                    f"may be misleading."
                )
                bl.load_warnings.append(ParseWarning(
                    path, "compatibility", bl.incompatible_reason, "warning"))
    return bl


def save_baseline(path: str, results, config, force: bool = False) -> str:
    """Write a baseline JSON file from the current analysis results.

    Returns the path on success. Raises FileExistsError if the file exists
    and `force` is False (the GUI must confirm before force=True).
    """
    if os.path.exists(path) and not force:
        raise FileExistsError(
            f"baseline file {path!r} already exists; "
            "pass force=True after explicit user confirmation"
        )
    destinations = []
    for r in results:
        destinations.append({
            "destination_address": r.destination_address,
            "destination_port": r.destination_port,
            "protocol": r.protocol,
        })
    payload = {
        "tool": "BeaconHunt",
        "version": __version__,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "settings": config.as_dict(),
        "destinations": destinations,
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    return path
