"""Statistics and jitter metrics for one destination group.

All metrics are computed on the list of inter-event intervals (seconds)
produced by grouping.intervals_seconds.

Definitions
-----------
mean                Arithmetic mean of intervals.
median              Median of intervals.
std                 Standard deviation. We use *population* stddev by default
                    (ddof=0) because the intervals are the complete
                    observed population, not a sample of a larger process.
                    Sample stddev (ddof=1) is selectable via config.
cv                  Coefficient of variation = std / mean. Safe for zero
                    mean: returns None and the scoring layer treats it as
                    missing rather than dividing by zero.
absolute_jitter     Median absolute deviation from the median interval
                    (MAD-median). Robust to outliers.
relative_jitter     absolute_jitter / median, as a percentage.
min_interval,
max_interval        Range of observed intervals.
byte_size stats     Mean / median / min / max / std / cv of byte sizes,
                    computed only when at least 2 non-None byte sizes exist.
                    Missing byte sizes are excluded, never silently zeroed.

jitter-band fit
---------------
Given a candidate base period P (default: median interval) and jitter
percentage J (default 20%), count intervals within:
    P * (1 - J/100)  to  P * (1 + J/100)
Report the count and the percentage of intervals in band.
"""
from __future__ import annotations

import statistics as py_stats
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

from ..config.settings import AnalysisConfig
from .grouping import Group


@dataclass
class GroupStatistics:
    """All statistics computed for one destination group."""
    # Core interval statistics
    mean_interval: Optional[float] = None
    median_interval: Optional[float] = None
    std_interval: Optional[float] = None
    cv_interval: Optional[float] = None
    min_interval: Optional[float] = None
    max_interval: Optional[float] = None
    # Jitter
    absolute_jitter: Optional[float] = None
    relative_jitter_pct: Optional[float] = None
    # Jitter-band fit
    base_period: Optional[float] = None
    jitter_band_low: Optional[float] = None
    jitter_band_high: Optional[float] = None
    jitter_band_fit_count: int = 0
    jitter_band_fit_pct: Optional[float] = None
    # Byte-size stats
    byte_mean: Optional[float] = None
    byte_median: Optional[float] = None
    byte_min: Optional[int] = None
    byte_max: Optional[int] = None
    byte_std: Optional[float] = None
    byte_cv: Optional[float] = None
    byte_count: int = 0
    byte_missing_count: int = 0
    # Metadata
    event_count: int = 0
    interval_count: int = 0
    source_address_count: int = 0
    notes: List[str] = field(default_factory=list)


def _safe_mean(values: List[float]) -> Optional[float]:
    if not values:
        return None
    return float(np.mean(values))


def _safe_median(values: List[float]) -> Optional[float]:
    if not values:
        return None
    return float(np.median(values))


def _safe_std(values: List[float], population: bool = True) -> Optional[float]:
    if len(values) < 2:
        return None
    return float(np.std(values, ddof=0 if population else 1))


def _safe_cv(values: List[float], mean: Optional[float], std: Optional[float]) -> Optional[float]:
    if not values or mean is None or std is None:
        return None
    if mean == 0:
        return None  # safe handling for zero mean
    return float(std / mean)


def _mad_median(intervals: List[float], median: Optional[float]) -> Optional[float]:
    """Median absolute deviation from the median."""
    if len(intervals) < 2 or median is None:
        return None
    abs_devs = [abs(x - median) for x in intervals]
    return float(np.median(abs_devs))


def _byte_stats(sizes: List[int], population: bool = True) -> dict:
    if len(sizes) < 1:
        return {}
    out = {
        "byte_mean": float(np.mean(sizes)),
        "byte_median": float(np.median(sizes)),
        "byte_min": int(min(sizes)),
        "byte_max": int(max(sizes)),
        "byte_count": len(sizes),
    }
    if len(sizes) >= 2:
        out["byte_std"] = float(np.std(sizes, ddof=0 if population else 1))
        if out["byte_mean"] != 0:
            out["byte_cv"] = float(out["byte_std"] / out["byte_mean"])
    return out


def compute_statistics(group: Group, config: AnalysisConfig) -> GroupStatistics:
    """Compute every statistic for a single group."""
    stats = GroupStatistics(
        event_count=group.event_count,
        interval_count=group.interval_count,
        source_address_count=len(group.source_addresses),
    )

    intervals = group.intervals_seconds
    sizes = group.byte_sizes

    if group.interval_count == 0:
        stats.notes.append("insufficient events for intervals (N-1 = 0)")
        # Still record byte stats if any.
        if sizes:
            stats.byte_count = len(sizes)
            stats.byte_missing_count = group.event_count - len(sizes)
            bs = _byte_stats(sizes, config.use_population_std)
            for k, v in bs.items():
                setattr(stats, k, v)
        return stats

    # Interval stats
    stats.mean_interval = _safe_mean(intervals)
    stats.median_interval = _safe_median(intervals)
    stats.std_interval = _safe_std(intervals, config.use_population_std)
    stats.cv_interval = _safe_cv(intervals, stats.mean_interval, stats.std_interval)
    stats.min_interval = float(min(intervals)) if intervals else None
    stats.max_interval = float(max(intervals)) if intervals else None

    # Jitter (MAD-median)
    stats.absolute_jitter = _mad_median(intervals, stats.median_interval)
    if stats.absolute_jitter is not None and stats.median_interval not in (None, 0):
        stats.relative_jitter_pct = float(100.0 * stats.absolute_jitter / stats.median_interval)
    elif stats.absolute_jitter is not None and stats.median_interval == 0:
        stats.notes.append("median interval is zero; relative jitter undefined")

    # Jitter-band fit
    stats.base_period = stats.median_interval
    if stats.base_period is not None and stats.base_period > 0:
        low = stats.base_period * (1 - config.jitter_percent / 100.0)
        high = stats.base_period * (1 + config.jitter_percent / 100.0)
        stats.jitter_band_low = float(low)
        stats.jitter_band_high = float(high)
        in_band = sum(1 for x in intervals if low <= x <= high)
        stats.jitter_band_fit_count = in_band
        stats.jitter_band_fit_pct = float(100.0 * in_band / len(intervals))
    elif stats.base_period == 0:
        stats.notes.append("base period (median interval) is zero; jitter-band fit skipped")

    # Byte-size stats
    stats.byte_missing_count = group.event_count - len(sizes)
    if len(sizes) >= 1:
        bs = _byte_stats(sizes, config.use_population_std)
        for k, v in bs.items():
            setattr(stats, k, v)
    if len(sizes) < 2:
        stats.notes.append("byte-size statistics require at least 2 non-missing values")
    if stats.byte_missing_count > 0:
        stats.notes.append(
            f"{stats.byte_missing_count} event(s) had missing byte size; "
            "missing values were excluded, not treated as zero"
        )

    return stats
