"""Deterministic synthetic test-data generator.

Every sample produced here is fake and was generated locally with a fixed
random seed. No real network traffic is captured, read, or referenced.

Categories produced (one CSV + one PCAP per category where useful):
  * strict_periodic     — exact 60 s beacons to one destination.
  * jittered_periodic   — 60 s base + ±20% jitter (beacon-like but noisy).
  * irregular_human     — random human-like inter-event times.
  * mixed               — a single file with several destinations of each kind.
  * below_threshold     — only 3 events, below the default min_events=5.
  * missing_bytes       — byte_size column sometimes blank.
  * ipv6                — IPv6 records.
  * timezone_offset     — timestamps with a +05:00 offset.
  * malformed_csv       — broken rows that the parser must skip with warnings.
  * empty_file          — zero bytes.
  * truncated_pcap      — a PCAP cut mid-packet.
  * baseline_known      — destinations present in a saved baseline.
  * baseline_new        — destinations NOT in the saved baseline.

The generator is also importable from tests/samples so unit tests can build
exactly the fixtures they need.
"""
from __future__ import annotations

import csv
import io
import os
import random
import struct
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

# All generators accept a seed so output is reproducible.
DEFAULT_SEED = 20260421


def _utc(year=2026, month=4, day=21, hour=8, minute=0, second=0) -> datetime:
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


def _write_pcap(path: str, packets: List[Tuple[float, bytes]]):
    """Write a minimal libpcap file (little-endian, microsecond resolution).

    Each entry in `packets` is (timestamp_seconds_float, raw_bytes).
    The PCAP global header is version 2.4, link-type 1 (Ethernet).
    """
    # Global header: magic, version_major, version_minor, thiszone,
    # sigfigs, snaplen, network (1 = Ethernet).
    glb = struct.pack(
        "<IHHiIII",
        0xA1B2C3D4,  # magic (little-endian microsecond)
        2, 4, 0, 0, 65535, 1,
    )
    out = bytearray(glb)
    for ts, data in packets:
        ts_sec = int(ts)
        ts_usec = int((ts - ts_sec) * 1_000_000)
        # Packet header: ts_sec, ts_usec, incl_len, orig_len.
        out += struct.pack("<IIII", ts_sec, ts_usec, len(data), len(data))
        out += data
    with open(path, "wb") as fh:
        fh.write(bytes(out))


def _ether_ip_tcp(
    src_ip: str, dst_ip: str, src_port: int, dst_port: int,
    payload: bytes = b"", flags: int = 0x02,  # SYN by default
) -> bytes:
    """Build a minimal Ethernet/IPv4/TCP packet as raw bytes.

    Used by the truncated_pcap and ipv4 PCAP samples. Scapy is not used here
    so the generator itself has no dependency on Scapy being importable at
    sample-creation time.
    """
    # Ethernet header: dst, src, type 0x0800
    eth = bytes.fromhex("001122334455") + bytes.fromhex("aabbccddeeff") + b"\x08\x00"
    # IPv4 header (no options): ver/ihl, tos, total_len, id, flags/frag,
    # ttl, proto, checksum, src, dst. Checksum left 0 — Scapy recalculates.
    total_len = 20 + 20 + len(payload)
    ip = struct.pack(
        ">BBHHHBBH4s4s",
        0x45, 0, total_len, 0x1234, 0x4000, 64, 6, 0,
        bytes(int(p) for p in src_ip.split(".")),
        bytes(int(p) for p in dst_ip.split(".")),
    )
    # TCP header (no options): src, dst, seq, ack, off=5, flags, window, sum, urg
    tcp = struct.pack(
        ">HHIIBBHHH",
        src_port, dst_port, 1000, 0, 0x50, flags, 65535, 0, 0,
    )
    return eth + ip + tcp + payload


def _ether_ipv6_tcp(
    src_ip: str, dst_ip: str, src_port: int, dst_port: int, payload: bytes = b"",
    flags: int = 0x02,
) -> bytes:
    """Minimal Ethernet/IPv6/TCP packet for the IPv6 sample."""
    import socket as _socket
    eth = bytes.fromhex("001122334455") + bytes.fromhex("aabbccddeeff") + b"\x86\xDD"
    def _ip6(addr: str) -> bytes:
        return _socket.inet_pton(_socket.AF_INET6, addr)
    # IPv6 header: 4 bytes (ver + traffic class + flow label) + payload length
    # (2 bytes, just the upper-layer TCP header + payload) + next header (TCP=6)
    # + hop limit.
    ip6 = struct.pack(">IHBB", 0x60000000, 20 + len(payload), 6, 64) + _ip6(src_ip) + _ip6(dst_ip)
    tcp = struct.pack(
        ">HHIIBBHHH",
        src_port, dst_port, 1000, 0, 0x50, flags, 65535, 0, 0,
    )
    return eth + ip6 + tcp + payload


def _ether_ip_udp(
    src_ip: str, dst_ip: str, src_port: int, dst_port: int, payload: bytes = b"",
) -> bytes:
    eth = bytes.fromhex("001122334455") + bytes.fromhex("aabbccddeeff") + b"\x08\x00"
    total_len = 20 + 8 + len(payload)
    ip = struct.pack(
        ">BBHHHBBH4s4s",
        0x45, 0, total_len, 0x1234, 0x4000, 64, 17, 0,
        bytes(int(p) for p in src_ip.split(".")),
        bytes(int(p) for p in dst_ip.split(".")),
    )
    udp = struct.pack(">HHHH", src_port, dst_port, 8 + len(payload), 0)
    return eth + ip + udp + payload


# ---------------------------------------------------------------------------
# CSV generators
# ---------------------------------------------------------------------------
CSV_HEADER = ["timestamp", "src_ip", "dst_ip", "dst_port", "protocol", "bytes"]


def _write_csv(path: str, rows: List[Tuple]) -> None:
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(CSV_HEADER)
        for r in rows:
            w.writerow(r)


def _rows_strict_periodic(n: int = 12, dst: str = "203.0.113.10", port: int = 443) -> List[Tuple]:
    start = _utc()
    rows = []
    for i in range(n):
        ts = (start + timedelta(seconds=60 * i)).isoformat()
        rows.append((ts, "198.51.100.7", dst, port, "TCP", 256 + i))
    return rows


def _rows_jittered_periodic(
    n: int = 12, dst: str = "203.0.113.20", port: int = 8443,
    base: float = 60.0, jitter_pct: float = 0.20, seed: int = DEFAULT_SEED,
) -> List[Tuple]:
    rng = random.Random(seed)
    start = _utc()
    rows = []
    t = 0.0
    for i in range(n):
        t += base * (1 + rng.uniform(-jitter_pct, jitter_pct))
        ts = (start + timedelta(seconds=t)).isoformat()
        rows.append((ts, "198.51.100.7", dst, port, "TCP", 240 + (i % 4)))
    return rows


def _rows_irregular_human(n: int = 10, dst: str = "203.0.113.30", port: int = 80, seed: int = DEFAULT_SEED + 1) -> List[Tuple]:
    rng = random.Random(seed)
    start = _utc()
    rows = []
    t = 0.0
    for i in range(n):
        t += rng.expovariate(1 / 180)  # mean 180 s, highly skewed
        ts = (start + timedelta(seconds=t)).isoformat()
        rows.append((ts, "198.51.100.7", dst, port, "TCP", rng.randint(100, 900)))
    return rows


def _rows_mixed() -> List[Tuple]:
    rows = []
    rows += _rows_strict_periodic(n=12, dst="203.0.113.10", port=443)
    rows += _rows_jittered_periodic(n=12, dst="203.0.113.20", port=8443)
    rows += _rows_irregular_human(n=8, dst="203.0.113.30", port=80)
    rows += _rows_strict_periodic(n=3, dst="203.0.113.40", port=53)  # below threshold
    return rows


def _rows_below_threshold() -> List[Tuple]:
    return _rows_strict_periodic(n=3, dst="203.0.113.40", port=53)


def _rows_missing_bytes(n: int = 10, seed: int = DEFAULT_SEED + 2) -> List[Tuple]:
    rng = random.Random(seed)
    rows = _rows_strict_periodic(n=n, dst="203.0.113.50", port=443)
    out = []
    for i, r in enumerate(rows):
        if rng.random() < 0.4:
            r = (r[0], r[1], r[2], r[3], r[4], "")  # blank bytes
        out.append(r)
    return out


def _rows_ipv6() -> List[Tuple]:
    start = _utc()
    rows = []
    for i in range(8):
        ts = (start + timedelta(seconds=30 * i)).isoformat()
        rows.append((ts, "2001:db8::1", "2001:db8:dead:beef::10", 443, "TCP", 200))
    return rows


def _rows_timezone_offset() -> List[Tuple]:
    """ISO timestamps written in +05:00; the parser must normalize to UTC."""
    # 08:00 local +05:00 == 03:00 UTC
    base_local = datetime(2026, 4, 21, 8, 0, 0, tzinfo=timezone(timedelta(hours=5)))
    rows = []
    for i in range(8):
        ts = (base_local + timedelta(seconds=60 * i)).isoformat()
        rows.append((ts, "198.51.100.7", "203.0.113.60", 443, "TCP", 300))
    return rows


def _rows_malformed_csv() -> List[str]:
    """Return raw CSV lines (not parsed tuples) including some broken rows."""
    lines = [",".join(CSV_HEADER)]
    lines.append("2026-04-21T08:00:00+00:00,198.51.100.7,203.0.113.70,443,TCP,256")
    lines.append("not-a-timestamp,198.51.100.7,203.0.113.70,443,TCP,256")  # bad ts
    lines.append("2026-04-21T08:02:00+00:00,198.51.100.7,203.0.113.70,notaport,TCP,256")  # bad port
    lines.append("2026-04-21T08:03:00+00:00,198.51.100.7")  # missing fields
    lines.append("2026-04-21T08:04:00+00:00,198.51.100.7,203.0.113.70,443,TCP,-5")  # negative bytes
    lines.append("2026-04-21T08:05:00+00:00,198.51.100.7,203.0.113.70,443,TCP,256")
    return lines


# ---------------------------------------------------------------------------
# Top-level "build all samples" entrypoint
# ---------------------------------------------------------------------------
def build_all(out_dir: str, seed: int = DEFAULT_SEED) -> List[str]:
    """Generate the full synthetic sample set under out_dir and return paths."""
    random.seed(seed)
    os.makedirs(out_dir, exist_ok=True)
    paths: List[str] = []

    csv_sets = {
        "strict_periodic.csv": _rows_strict_periodic(),
        "jittered_periodic.csv": _rows_jittered_periodic(),
        "irregular_human.csv": _rows_irregular_human(),
        "mixed.csv": _rows_mixed(),
        "below_threshold.csv": _rows_below_threshold(),
        "missing_bytes.csv": _rows_missing_bytes(),
        "ipv6.csv": _rows_ipv6(),
        "timezone_offset.csv": _rows_timezone_offset(),
    }
    for name, rows in csv_sets.items():
        p = os.path.join(out_dir, name)
        _write_csv(p, rows)
        paths.append(p)

    # Malformed CSV (raw lines so we can include broken rows verbatim).
    p = os.path.join(out_dir, "malformed.csv")
    with open(p, "w", newline="") as fh:
        fh.write("\n".join(_rows_malformed_csv()) + "\n")
    paths.append(p)

    # Empty file.
    p = os.path.join(out_dir, "empty.csv")
    open(p, "w").close()
    paths.append(p)

    # Truncated PCAP: write a strict periodic PCAP then cut the last packet.
    p_full = os.path.join(out_dir, "periodic.pcap")
    pkts = []
    start = _utc()
    for i in range(10):
        ts = (start + timedelta(seconds=60 * i)).timestamp()
        data = _ether_ip_tcp("198.51.100.7", "203.0.113.10", 51000 + i, 443, flags=0x02)
        pkts.append((ts, data))
    _write_pcap(p_full, pkts)
    paths.append(p_full)

    # Truncated variant: chop 4 bytes off the end.
    with open(p_full, "rb") as fh:
        buf = fh.read()
    p_trunc = os.path.join(out_dir, "truncated.pcap")
    with open(p_trunc, "wb") as fh:
        fh.write(buf[:-4])
    paths.append(p_trunc)

    # IPv6 PCAP (8 beacons to a v6 destination).
    p6 = os.path.join(out_dir, "ipv6.pcap")
    pkts6 = []
    for i in range(8):
        ts = (start + timedelta(seconds=30 * i)).timestamp()
        data = _ether_ipv6_tcp("2001:db8::1", "2001:db8:dead:beef::10", 51000 + i, 443)
        pkts6.append((ts, data))
    _write_pcap(p6, pkts6)
    paths.append(p6)

    # UDP PCAP (8 packets, 90s apart, with payload bytes).
    p_udp = os.path.join(out_dir, "udp_periodic.pcap")
    pkts_udp = []
    for i in range(8):
        ts = (start + timedelta(seconds=90 * i)).timestamp()
        data = _ether_ip_udp("198.51.100.7", "203.0.113.80", 53000 + i, 5353, payload=b"\x00" * 64)
        pkts_udp.append((ts, data))
    _write_pcap(p_udp, pkts_udp)
    paths.append(p_udp)

    # Plain-text log using a documented format.
    p_txt = os.path.join(out_dir, "firewall.txt")
    with open(p_txt, "w") as fh:
        for r in _rows_strict_periodic(n=12, dst="203.0.113.90", port=443):
            fh.write(
                f"{r[0]} SRC={r[1]} DST={r[2]} DPT={r[3]} PROTO={r[4]} BYTES={r[5]}\n"
            )
    paths.append(p_txt)

    # Exclusion list (known-good).
    p_exc = os.path.join(out_dir, "exclusions.txt")
    with open(p_exc, "w") as fh:
        fh.write("# BeaconHunt exclusion list (known-good destinations)\n")
        fh.write("# Format: address or address:port, one per line. Lines starting with # are comments.\n")
        fh.write("203.0.113.10\n")
        fh.write("203.0.113.90:443\n")
        fh.write("# an intentionally invalid line follows\n")
        fh.write("not-an-ip\n")
    paths.append(p_exc)

    # Baseline JSON (saved baseline mode).
    p_base = os.path.join(out_dir, "baseline.json")
    with open(p_base, "w") as fh:
        import json
        json.dump({
            "tool": "BeaconHunt",
            "version": "1.0.0",
            "created_at": _utc().isoformat(),
            "settings": {
                "min_events": 5,
                "score_threshold": 70.0,
                "jitter_percent": 20.0,
                "udp_idle_timeout": 120.0,
                "grouping_policy": "dest_port_protocol",
            },
            "destinations": [
                {"destination_address": "203.0.113.10", "destination_port": 443, "protocol": "TCP"},
                {"destination_address": "203.0.113.90", "destination_port": 443, "protocol": "TCP"},
            ],
        }, fh, indent=2)
    paths.append(p_base)

    return paths


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "samples"
    for p in build_all(out):
        print("wrote", p)
