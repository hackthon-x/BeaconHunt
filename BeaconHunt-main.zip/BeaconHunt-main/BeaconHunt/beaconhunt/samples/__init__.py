"""Synthetic sample-data package.

The samples bundled here are all fake, generated locally with a fixed seed
(see generator.DEFAULT_SEED). They must never be replaced with real network
captures without written authorization.
"""
from .generator import build_all, DEFAULT_SEED

__all__ = ["build_all", "DEFAULT_SEED"]
