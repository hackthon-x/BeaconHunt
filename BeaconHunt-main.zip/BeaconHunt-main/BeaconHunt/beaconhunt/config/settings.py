"""Default analysis configuration and tunable constants.

All values here can be overridden at runtime through the GUI "Analysis
Settings" panel. The dataclass is the single source of truth for both the
worker thread and the export module (which echoes the active settings into
every report).
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Optional


DEFAULT_MIN_EVENTS = 5
DEFAULT_SCORE_THRESHOLD = 70.0
DEFAULT_JITTER_PERCENT = 20.0
DEFAULT_UDP_IDLE_TIMEOUT = 120.0  # seconds
DEFAULT_MAX_EVENTS_PER_GROUP = 200_000  # safety cap to keep the UI responsive


@dataclass(frozen=True)
class ScoringWeights:
    """Component weights for the 0-100 regularity score.

    The four weights MUST sum to 1.0; AnalysisConfig.normalize_weights() will
    renormalize them automatically when a component cannot be computed (e.g.
    when byte sizes are unavailable).
    """
    interval_regularity: float = 0.35
    jitter_consistency: float = 0.30
    byte_size_consistency: float = 0.20
    connection_count_support: float = 0.15

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class AnalysisConfig:
    """Configuration carried through one analysis run."""
    min_events: int = DEFAULT_MIN_EVENTS
    score_threshold: float = DEFAULT_SCORE_THRESHOLD
    jitter_percent: float = DEFAULT_JITTER_PERCENT
    udp_idle_timeout: float = DEFAULT_UDP_IDLE_TIMEOUT
    grouping_policy: str = "dest_port_protocol"  # default grouping key
    exclusion_file: Optional[str] = None
    baseline_file: Optional[str] = None
    weights: ScoringWeights = field(default_factory=ScoringWeights)
    use_population_std: bool = True  # population stddev by default
    byte_size_source: str = "captured"  # captured | wire | reported
    tcp_event_policy: str = "syn_no_ack"  # syn_no_ack | first_seen
    include_ascii_histogram_in_text: bool = True

    def as_dict(self) -> dict:
        d = asdict(self)
        return d

    def describe(self) -> str:
        """Human-readable summary used in exports."""
        return (
            f"min_events={self.min_events}, "
            f"score_threshold={self.score_threshold}, "
            f"jitter_percent={self.jitter_percent}%, "
            f"udp_idle_timeout={self.udp_idle_timeout}s, "
            f"grouping={self.grouping_policy}, "
            f"tcp_event_policy={self.tcp_event_policy}, "
            f"byte_size_source={self.byte_size_source}, "
            f"stddev={'population' if self.use_population_std else 'sample'}"
        )
