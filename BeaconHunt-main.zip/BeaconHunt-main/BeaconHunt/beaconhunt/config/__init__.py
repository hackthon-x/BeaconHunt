"""Configuration package for BeaconHunt."""
from .settings import AnalysisConfig, ScoringWeights

__all__ = ["AnalysisConfig", "ScoringWeights"]
