# BeaconHunt — False-Positive Discussion

BeaconHunt is a metadata-only detector. A high regularity score indicates
**suspicious periodicity**, not proof of command-and-control activity.
This document discusses the most common sources of false positives and how
to suppress them with BeaconHunt's features.

## 1. Scheduled legitimate services

Many benign services contact a fixed destination on a regular schedule and
will produce a textbook beacon signature: tight intervals, low jitter, high
jitter-band fit, consistent byte sizes.

| Service | Typical pattern | Why it false-positives |
|---|---|---|
| **NTP clients** | Sync to one NTP server every 64-1024 s | Default polling interval is fixed; jitter is essentially zero. |
| **Software update checkers** | Windows Update, apt-daily.timer, Chrome update checker | Phone home every few hours on a strict schedule. |
| **Monitoring and telemetry agents** | Datadog, Splunk forwarder, Prometheus node_exporter, OSSEC/Wazuh | Push metrics on a fixed scrape interval (often 10-60 s). |
| **Cloud sync clients** | OneDrive, Dropbox, Google Drive | Long-poll or fixed-interval sync to vendor endpoints. |
| **Mail clients** | IMAP IDLE / polling | Polling produces fixed-interval connections to the mail server. |
| **Cron-driven outbound HTTPS** | Any scheduled task that hits a URL | Anything scripted on a timer produces a beacon. |
| **Push notification keepalives** | Mobile (and desktop) push services | Persistent TCP with application-layer keepalives on a regular cadence. |

### How BeaconHunt helps

* **Exclusion list** — maintain a list of known-good destinations (vendor IP
  ranges, internal update servers, monitoring endpoints) in a plain-text
  file. CIDR entries work for vendor ranges. Hostname entries are
  deliberately refused to avoid online DNS resolution; map hostnames to IPs
  out-of-band and exclude the IPs.
* **Baseline mode** — load a previously saved baseline so known
  destinations are tagged "known" and the analyst can filter to "new" only.
* **Score threshold** — raise it (e.g. 80 or 85) to reduce sensitivity at
  the cost of missing noisier beacons.
* **Jitter tolerance** — legitimate scheduled services often have *very*
  low jitter (system clocks are precise). Real C2 beacons usually add a
  small amount of jitter to evade detection. Counter-intuitively, a
  destination with *exactly* zero jitter may be more likely to be a system
  service than a C2 channel.

## 2. Monitoring agents and shared destinations contacted by many hosts

When many internal hosts all check the same update or monitoring server on
the same schedule, the destination accumulates many events from many source
addresses. BeaconHunt will score it highly.

### How BeaconHunt helps

* The **source-address count** column distinguishes a single-host beacon
  (source count = 1) from a multi-host legitimate service (source count
  high).
* The **baseline mode** catches destinations that have appeared recently
  and were not in the previous baseline — a brand-new multi-host service
  may be worth investigating even if it looks benign.
* The exclusion list can include `address:port` pairs to suppress the
  well-known multi-host destinations.

### Caveat

NAT and proxies collapse many internal sources into one observed source
address. If your capture is post-NAT, the source-address count is
misleading. Always interpret it in the context of where the capture was
taken.

## 3. Software updates

Auto-update mechanisms often:

* Check for updates on a fixed schedule (beacon-like).
* Then download large payloads (bursty, large byte sizes).

The first phase produces a high-score beacon; the second phase may pull the
byte-size consistency down. An analyst who sees a high regularity score
with intermittent byte-size spikes should investigate the destination
further — it may be an updater, but it may also be a C2 channel that
periodically pulls larger payloads.

### How BeaconHunt helps

* The byte-size-over-time chart in the details panel shows the bimodal
  pattern visually.
* The byte-size CV metric quantifies the inconsistency — a high byte-size
  CV with a high interval-regularity score is worth investigating.

## 4. Shared destinations with periodic but legitimate traffic

CDN endpoints, antivirus signature servers, and time services are all
contacted by many hosts on many schedules. They will appear in any
network-wide capture.

### How BeaconHunt helps

* Maintain an exclusion list of CDN and signature-update IP ranges.
* Use baseline mode to track which destinations are *new* since the last
  analysis.
* Combine BeaconHunt findings with asset ownership data — a flagged
  destination that resolves to a known CDN is almost certainly benign.

## 5. Other limitations

* **No payload inspection.** BeaconHunt does not look at packet contents,
  so it cannot distinguish a C2 heartbeat from a benign heartbeat by
  content. Pair with a deep-packet-inspection tool for content-based
  validation.
* **No DNS resolution.** IP-only analysis means you must correlate flagged
  IPs with asset ownership manually. BeaconHunt will never resolve
  hostnames online (this is a deliberate safety property).
* **No TLS/SNI inspection.** TLS metadata is not currently used. If you
  want SNI-based filtering, exclude by IP after correlating externally.
* **Truncated captures** may under-count events and produce misleading
  scores. The parser warns when a PCAP appears truncated; treat results
  from truncated captures with extra caution.
* **Bidirectional captures.** The `syn_no_ack` TCP event policy suppresses
  reverse-direction counting. If you have a one-way capture (egress only),
  every SYN you see is a connection start, which is what you want. If you
  have a two-way capture with asymmetric routing, you may see only one
  direction of some flows.
* **NAT and proxies** collapse internal sources. The source-address count
  is then misleading.
* **Jitter-tolerant mode** is a heuristic. It can miss highly irregular
  patterns (which is fine — those don't look like beacons anyway) and can
  flag legitimate periodic services (which is the false-positive problem
  this document is about). Tune `jitter_percent` and `score_threshold` for
  your environment.
* **Aggregation policy.** Grouping by destination-only (instead of
  destination+port+protocol) can merge unrelated flows that happen to share
  an IP, producing false positives. The default `dest_port_protocol`
  policy is the most conservative.

## 6. The bottom line

BeaconHunt is a triage tool. It narrows the field from "every connection
in the capture" to "a small ranked list of statistically regular
destinations." A human analyst then:

1. Reviews the ranked list and the score breakdown.
2. Filters out known-good destinations using the exclusion list and
   baseline mode.
3. Investigates the remaining flagged destinations with asset-ownership
   data, endpoint telemetry, and (where authorized) deeper packet
   inspection.

**Always correlate findings with asset ownership, endpoint telemetry, and
policy before acting.**
