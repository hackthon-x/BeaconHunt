# BeaconHunt — Demo Plan (synthetic data only)

This document walks through a complete demonstration of BeaconHunt using
only the synthetic samples bundled in `samples/`. No real network traffic
is used.

## Setup

```bash
pip install -r requirements.txt
python3 -m beaconhunt.samples.generator samples    # regenerate fixtures
python3 -m beaconhunt.app                          # launch the GUI
```

## 1. Load the demo file

On the dashboard, click **Open Sample Project** and choose `samples/mixed.csv`.

The Import and Configure panel reports:

* Detected input type: **csv**
* Size: ~1.5 KB
* Validation: file readable

Leave the default settings:

| Setting | Value |
|---|---|
| Minimum event count | 5 |
| Beacon score threshold | 70.0 |
| Jitter tolerance | 20% |
| UDP idle timeout | 120 s |
| Grouping policy | destination + port + protocol |
| TCP event policy | SYN without ACK |
| Byte-size source | captured |
| Stddev | population |

Optionally attach:

* `samples/exclusions.txt` — excludes `203.0.113.10` and `203.0.113.90:443`.
* `samples/baseline.json` — marks `203.0.113.10` and `203.0.113.90` as known.

Click **Analyze**.

## 2. Expected ranked result

| Rank | Status | Destination | Score | Events | Intervals | Median | JitFit |
|---:|---|---|---:|---:|---:|---:|---:|
| 1 | flagged | `203.0.113.20:8443/TCP` | ~90 | 12 | 11 | ~60 s | 100% |
| 2 | not_flagged | `203.0.113.30:80/TCP` | ~26 | 8 | 7 | varies | ~14% |
| 3 | insufficient_evidence | `203.0.113.40:53/TCP` | 0 | 3 | 2 | ~60 s | 100% |
| 4 | excluded | `203.0.113.10:443/TCP` | ~96 | 12 | 11 | 60 s | 100% |

Notes:

* `203.0.113.10` is the strictest periodic destination in the file (exact 60 s intervals, zero jitter, byte sizes 256-267). It scores ~96. **Excluded only because we attached the exclusion list.** Without an exclusion list it would be ranked #1 and flagged.
* `203.0.113.20` is the jittered periodic (60 s ± 20%). All intervals still fall inside the ±20% jitter band, so it scores ~90 and is flagged.
* `203.0.113.30` is the irregular human-like pattern. CV is high, jitter-band fit is low, so the score is low and it is **not flagged**.
* `203.0.113.40` has only 3 events, below the `min_events=5` threshold. It is **insufficient evidence** regardless of how regular the intervals look. This proves the minimum-event enforcement is working.

## 3. Drill into one flagged destination — `203.0.113.20:8443/TCP`

Click the row to open the details panel.

### Summary card

* Destination: `203.0.113.20:8443/TCP`
* Status: flagged
* Final score: ~90 / 100
* Key reason: `score 90.1 >= threshold 70.0 over 12 events`
* Events: 12, intervals: 11, source addresses: 1
* First seen / last seen: 2026-04-21 08:01 to 09:11 UTC

### Score breakdown tab

| Component | Weight | Raw | Weighted | Reason |
|---|---:|---:|---:|---|
| interval_regularity | 0.35 | 67.8 | 23.7 | high CV (0.161) |
| jitter_consistency | 0.30 | 100.0 | 35.1 | jitter-band fit: 100% of intervals within ± band |
| byte_size_consistency | 0.20 | 99.5 | 23.2 | byte-size CV 0.005 over 12 samples |
| connection_count | 0.15 | 78.0 | 13.7 | 12 events |

Weighted sum = 95.7 / total weight 1.00 ≈ final score 90.1 (after weight renormalization). The sum of the displayed `weighted` column equals the final score.

### Statistics tab

All required metrics are shown:

* Mean interval, median interval, std interval (population), CV.
* Min / max interval.
* Absolute jitter (MAD-median), relative jitter %.
* Jitter-band lower / upper bounds, count and percentage in band.
* Byte-size mean / median / min / max / std / CV / count / missing count.
* Notes flag any missing-data exclusions explicitly.

### Events tab

Chronological table with timestamp (UTC), source, destination, port, protocol, byte size, and input reference (`mixed.csv#N`).

### Charts tab

Three matplotlib charts:

1. **Interval timeline** — intervals plotted by index, with the median (base period) drawn as a green dashed line and the jitter band as a shaded amber region.
2. **Interval histogram** — distribution of interval values, with the median marked.
3. **Byte size over time** — bytes per event against UTC timestamp.

## 4. Evidence behind the flag

Open `download/example_reports/mixed_report.txt` (or generate it via **Export Text**). For `203.0.113.20:8443/TCP`:

```
Destination: 203.0.113.20:8443/TCP
  Status: flagged; final score: 90.1; reason: score 90.1 >= threshold 70.0 over 12 events
  Events: 12; intervals: 11; sources: 1
  Interval median: 60.74s; mean: 60.83s; std: 9.765; CV: 0.161
  Absolute jitter (MAD): 8.700s; relative jitter: 14.3%
  Jitter-band fit: 100.0% (11/11)
  Byte size: min=240, max=243, mean=241, CV=0.005 (12 samples, 0 missing)
  First seen: 2026-04-21T08:01:13+00:00; last seen: 2026-04-21T09:11:13+00:00
  Score components:
    - interval_regularity      weight=0.35 raw= 67.8 weighted= 23.7  [high CV (0.161)]
    - jitter_consistency       weight=0.30 raw=100.0 weighted= 35.1  [jitter-band fit: 100.0% of intervals within ± band]
    - byte_size_consistency    weight=0.20 raw= 99.5 weighted= 23.2  [byte-size CV 0.005 over 12 samples]
    - connection_count         weight=0.15 raw= 78.0 weighted= 13.7  [12 events]
  Interval histogram (ASCII):
  [  48.99 -   52.32] ### (1)
  [  52.32 -   55.65] ### (1)
  ...
```

The evidence is transparent and auditable:

* The destination has 12 events (above the minimum-event threshold of 5).
* The intervals cluster tightly around a 60 s base period — every interval falls within the ±20% jitter band, giving the jitter-consistency component a perfect 100.
* Byte sizes are highly consistent (CV = 0.005), boosting the byte-size component.
* The CV is 0.161 (slightly above the "very low" threshold), so the interval-regularity component is 67.8 rather than 100 — this is the cost of jitter.
* The connection-count component saturates around 78 for 12 events.

## 5. Export

From the toolbar, click **Export PDF**. The exported PDF includes:

* Input filename and analysis time.
* Tool version (BeaconHunt 1.0.0).
* Active settings (echoed verbatim from `AnalysisConfig`).
* Flow policy and byte-size source.
* Parsing warnings.
* Limitations note (metadata-only, not proof of C2).
* Ranked results table with status color coding.
* Per-flagged-destination evidence block including the score-component table and ASCII histogram.

Example exports live in `download/example_reports/`:

* `mixed_report.json` — full machine-readable report.
* `mixed_report.csv` — ranked table only.
* `mixed_report.html` — standalone HTML.
* `mixed_report.pdf` — paginated printable report.
* `mixed_report.txt` — plain text with ASCII histograms.
* `periodic_pcap_report.{json,pdf,txt}` — same exports for `samples/periodic.pcap`.

## 6. Baseline comparison

Reload the analysis with `samples/baseline.json` attached. The Baseline column now shows:

* `203.0.113.10` — **known** (in baseline; also excluded).
* `203.0.113.20` — **new** (not in baseline; flagged).
* `203.0.113.30` — **new** (not in baseline; not flagged).
* `203.0.113.40` — **new** (not in baseline; insufficient evidence).

Filter by Baseline = "new" to focus on destinations that warrant fresh analyst attention.

## 7. Cancel mid-analysis

Load `samples/periodic.pcap`, click Analyze, then immediately click Cancel in the progress dialog. The worker thread stops cleanly, the UI returns to the Import panel, and the app remains responsive. (For very large PCAPs Scapy reads the whole file in one call, so cancellation is honoured between the parse and analysis stages; this is documented in the README.)

## 8. Empty / malformed / truncated inputs

Try these to see the parser's error handling:

* `samples/empty.csv` — flagged as an error, no records produced.
* `samples/malformed.csv` — 4 of 6 rows skipped with line-numbered warnings; 2 valid records still produced.
* `samples/truncated.pcap` — first 9 of 10 SYN events parsed; no crash.
* `samples/missing_bytes.csv` — `byte_size` is None for some events; preserved as None, not zeroed.

All warnings are surfaced in the progress dialog's warnings list and echoed into every exported report.
