# BeaconHunt — Stage-by-stage build notes

This document records what was built at each stage of the incremental
build plan, the test command, and the observed result.

Every stage passed before the next was started, per the spec.

## Stage 1 — GUI shell and synthetic sample

**Files created or changed:**
- `beaconhunt/__init__.py`, `beaconhunt/app.py`
- `beaconhunt/ui/styles.py`, `beaconhunt/ui/dashboard.py`,
  `beaconhunt/ui/main_window.py`, `beaconhunt/ui/__init__.py`
- `beaconhunt/samples/generator.py`, `beaconhunt/samples/__init__.py`
- `beaconhunt/config/settings.py`, `beaconhunt/config/__init__.py`
- `beaconhunt/models/records.py`, `beaconhunt/models/__init__.py`
- `samples/*` — 17 synthetic fixtures generated with seed 20260421.

**Implementation:**
- PySide6 `QMainWindow` with a 3-page `QStackedWidget` (dashboard,
  import panel, results splitter). QSS stylesheet defines the design
  system. Dashboard has the privacy banner, Open PCAP/Log, and Open
  Sample Project actions. Samples are generated locally with a fixed
  seed; no network access.

**Test command:**
```bash
LD_LIBRARY_PATH=$PWD/.local-libs/usr/lib/x86_64-linux-gnu \
QT_QPA_PLATFORM=offscreen python3 tests/test_gui_smoke.py
```
(On a desktop with a real display, `python3 -m beaconhunt.app` is the
normal launch command.)

**Expected output:** the window constructs with title "BeaconHunt
v1.0.0", 3 stacked widgets, no exceptions.

**Observed:** PASS — window constructs, AnalysisWorker runs end-to-end on
samples/mixed.csv, finds 4 destinations with 2 flagged.

## Stage 2 — PCAP parser and normalized events

**Files created or changed:**
- `beaconhunt/parsers/base.py` (BaseParser, ParseResult, detect_input_type)
- `beaconhunt/parsers/pcap_parser.py` (PcapParser, Scapy offline)
- `beaconhunt/parsers/__init__.py`

**Implementation:**
- `PcapParser` uses `scapy.rdpcap()` (offline only — no live capture, no
  sockets, no DNS). Extracts timestamps, L3 addresses (IPv4 + IPv6), L4
  ports, protocol, and a configurable byte-size source (captured/wire/
  reported). TCP event policy = SYN-no-ACK by default; first-seen is a
  documented heuristic. UDP uses a configurable idle timeout to separate
  pseudo-flows. All output is `ConnectionRecord` objects.

**Test command:**
```bash
python3 -m pytest tests/test_stage2_pcap.py -v
```

**Expected output:** parser yields 10 records for `periodic.pcap`, 8 for
`ipv6.pcap`, 1 (with 120s timeout) or 8 (with 60s timeout) for
`udp_periodic.pcap`, ≥9 for `truncated.pcap`, error warning for empty
file.

**Observed:** 10 PcapParser tests pass.

## Stage 3 — CSV and plain-text parsers

**Files created or changed:**
- `beaconhunt/parsers/csv_parser.py` (CsvParser, ColumnMapping,
  HEADER_ALIASES, CANONICAL_FIELDS)
- `beaconhunt/parsers/text_parser.py` (TextParser, NAMED_FORMATS)

**Implementation:**
- `CsvParser` accepts an explicit `ColumnMapping` or auto-detects from
  the header row using a documented alias set. Validates timestamps,
  ports (0-65535), byte sizes (non-negative), and emits line-numbered
  `ParseWarning`s for skipped rows. Missing byte_size values are
  preserved as None, never silently replaced with zero.
- `TextParser` supports two named formats (`firewall_kv`,
  `squid_common`) plus a user-supplied regex with named groups
  (`ts`, `src`, `dst`, `dport`, `proto`, `bytes`).
- Both produce the same `ConnectionRecord` type as the PCAP parser
  (verified by `test_all_parsers_produce_same_record_type`).

**Test command:**
```bash
python3 -m pytest tests/test_stage3_logs.py -v
```

**Observed:** 13 tests pass — auto-detect, explicit mapping, malformed
skipping, empty file, missing bytes preserved, timezone offset
normalization (+05:00 → UTC), firewall_kv format, custom regex, empty
log, invalid regex raises, unknown format raises, shared record type.

## Stage 4 — Grouping and intervals

**Files created or changed:**
- `beaconhunt/analysis/grouping.py` (Group, group_records)

**Implementation:**
- Sort records by timestamp within group. Group by
  (destination_address, destination_port, protocol) by default.
  Alternative policies: dest+port, dest-only. N events produce N-1
  intervals (verified by `test_n_events_produce_n_minus_1_intervals`).
  Source-address count and first/last seen are exposed as properties.

**Test command:**
```bash
python3 -m pytest tests/test_stage4_grouping.py -v
```

**Observed:** 6 tests pass — grouping by dest+port+protocol, N-1
intervals, single-event group has zero intervals, sorting within group,
alternative policies, source-address count.

## Stage 5 — Statistics and jitter

**Files created or changed:**
- `beaconhunt/analysis/statistics.py` (GroupStatistics, compute_statistics)

**Implementation:**
- Mean, median, stddev (population or sample, configurable), CV with
  safe handling for zero mean (returns None, not divide-by-zero),
  min/max interval, absolute jitter (MAD-median), relative jitter %,
  jitter-band fit % (count and percentage within ± jitter_percent of
  base period = median). Byte-size stats only when ≥ 1 non-missing
  value; missing byte sizes are excluded, never zeroed.

**Test command:**
```bash
python3 -m pytest tests/test_stage5_statistics.py -v
```

**Observed:** 12 tests pass — edge cases for 1 event, 2 events, strict
periodic zero jitter, jittered within band, jittered outside band, zero
mean safe CV, missing byte sizes excluded, insufficient byte sizes,
population vs sample stddev, MAD-median correctness, min/max intervals,
first/last seen.

## Stage 6 — Scoring and ranked results

**Files created or changed:**
- `beaconhunt/analysis/scoring.py` (DestinationResult, ComponentScore,
  score_group, rank_results, analyze_records)
- `beaconhunt/analysis/engine.py` (AnalysisReport, run_analysis pipeline)
- `beaconhunt/analysis/__init__.py`

**Implementation:**
- Four-component score: 35% interval regularity, 30% jitter consistency,
  20% byte-size consistency, 15% connection-count support. Each
  component normalized to 0-100. Missing components are dropped and
  weights renormalized (a destination is never zero-scored because byte
  data is missing). Threshold + min-events enforcement: groups below
  min_events are "insufficient_evidence" and never flagged. Status
  labels: flagged, not_flagged, excluded, insufficient_evidence.
- `run_analysis` wires grouping → scoring → ranking → exclusions →
  baseline comparison and returns an `AnalysisReport`.

**Test command:**
```bash
python3 -m pytest tests/test_stage6_scoring.py -v
```

**Observed:** 9 tests pass — one-off destination never flagged, strict
periodic scores high and flagged, irregular pattern not flagged, missing
byte size does not zero score, weights renormalized, threshold tuning,
ranking orders by score desc, components sum to final score, default
weights documented.

## Stage 7 — Details view and visualizations

**Files created or changed:**
- `beaconhunt/ui/details_panel.py` (DetailsPanel with summary card,
  score breakdown, statistics, events table, and matplotlib charts)
- `beaconhunt/ui/results_table.py` (ResultsTableWidget with filters,
  search, status color coding)

**Implementation:**
- Destination details panel: summary card (destination, status, score,
  key reason), Score breakdown tab (4-component table with weights,
  raw, weighted, reason), Statistics tab (all metrics with units and
  definitions), Events tab (chronological event table with input
  reference), Charts tab (matplotlib: interval timeline with jitter
  band overlay, interval histogram with median line, byte-size-over-
  time chart).
- Results table: rank, status badge (color + text label, never color
  alone), destination, port, protocol, score, event count, interval
  count, mean, median, std, CV, abs jitter, rel jitter %, jitfit %,
  byte min/max/CV, source count, baseline status, first/last seen.
  Sort by score (default), with filters for status, destination, port,
  protocol, score ≥, baseline novelty, and a free-text search box +
  Clear filters button.

**Test command:**
- Visual verification via PDF render: `pdftotext
  download/example_reports/mixed_report.pdf -` shows the ranked table
  and the per-flagged-destination evidence block including score
  components and ASCII histogram.
- Functional verification: covered by `test_gui_smoke.py` (worker
  integration) and `test_stage9_usability.py` (UI affordances).

**Observed:** PASS — PDF contains the ranked table, evidence blocks,
score-component tables, and ASCII histograms. HTML report contains
status badges and a styled ranked table.

## Stage 8 — Exclusions, baseline mode, and report exports

**Files created or changed:**
- `beaconhunt/analysis/exclusions.py` (ExclusionEntry, ExclusionList,
  Baseline, load_exclusion_list, load_baseline, save_baseline)
- `beaconhunt/reports/json_export.py`, `csv_export.py`, `html_export.py`,
  `pdf_export.py`, `text_export.py`, `__init__.py`

**Implementation:**
- Exclusion list: plain-text, supports exact IP, IP:port, IPv4 CIDR.
  Hostname exclusions refused with a visible warning (no online DNS).
  Invalid lines flagged with line numbers. Excluded destinations marked
  with the matching raw entry as the reason; not included in flagged.
- Baseline: local JSON file with tool, version, created_at, settings,
  and destinations list. `load_baseline` validates compatibility (warns
  on settings mismatch). `save_baseline` raises `FileExistsError` if
  the file exists unless `force=True`. Comparison marks each result as
  "known" or "new".
- Exports: JSON (full machine-readable report), CSV (ranked table),
  HTML (self-contained with status badges), PDF (paginated, ReportLab,
  with per-flagged-destination evidence + ASCII histogram), Text
  (plain text with ASCII histograms). Every export includes input
  filename, analysis time, tool version, settings, flow policy,
  parsing warnings, and limitations note.

**Test command:**
```bash
python3 -m pytest tests/test_stage8_exclusions_baseline_exports.py -v
```

**Observed:** 14 tests pass — exclusion list parses and flags invalid
lines, exact address match, address:port match (not port), excluded
destinations marked with reason, CIDR range matches, baseline loads
and exposes known keys, baseline comparison marks new destinations,
save_baseline refuses overwrite without force, invalid baseline
produces warning, all 5 export formats produce non-empty files with
expected content, export refuses overwrite without force.

## Stage 9 — Usability, packaging, and final QA

**Files created or changed:**
- `beaconhunt/workers/analysis_worker.py` (QThread + Qt signals,
  cooperative cancel)
- `beaconhunt/ui/progress_dialog.py` (modal progress with stage label,
  progress bar, warnings list, Cancel button)
- `beaconhunt/ui/import_panel.py` (every setting has a tooltip;
  drag-and-drop file selection; CSV column mapping with auto-detect +
  manual override; text format selector + custom regex field)
- `tests/test_stage9_usability.py`
- `README.md` (installation, usage, metrics, scoring, limitations,
  synthetic test data, project structure, testing, demo plan, framework
  choices, packaging)
- `download/demo_plan.md`, `download/false_positive_discussion.md`
- `run.py` (convenience runner for GUI / tests / samples / demo)

**Implementation:**
- Background worker: parsing and analysis run on a QThread; UI stays
  responsive. Cancel button sets a cooperative flag that the worker
  checks between stages. Closing the window during analysis calls
  `cancel()` and `thread.quit()` and waits for clean exit.
- Keyboard navigation: every button and field is focusable; the Open
  button is the default (Enter activates it). All settings have
  tooltips explaining the statistical meaning.
- Window resizing: minimum size 1024×640; tested at 1400×900 and back.
- Packaging: documented PyInstaller one-file build.

**Test command:**
```bash
LD_LIBRARY_PATH=$PWD/.local-libs/usr/lib/x86_64-linux-gnu \
QT_QPA_PLATFORM=offscreen python3 -m pytest tests/test_stage9_usability.py -v
```

**Observed:** 7 tests pass — window minimum size and resize, dashboard
focus chain, every setting has a tooltip, cancel during analysis is
safe, close event cancels worker, drag-drop path metadata, default
analysis config values match the documented spec.

## Full suite

```bash
python3 -m pytest tests/ -v
```

**Observed:** 72 passed in 2.9s, 0 failures.
