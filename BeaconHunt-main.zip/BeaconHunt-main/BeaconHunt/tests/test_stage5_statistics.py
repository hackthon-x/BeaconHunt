"""Stage 5 tests — statistics and jitter metrics, including edge cases."""
from __future__ import annotations

import os
import sys
import math
from datetime import datetime, timezone, timedelta

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.config import AnalysisConfig
from beaconhunt.models.records import ConnectionRecord
from beaconhunt.analysis.grouping import Group, group_records
from beaconhunt.analysis.statistics import compute_statistics

SAMPLES = os.path.join(PROJECT_ROOT, "samples")


def _utc(s: str) -> datetime:
    return datetime.fromisoformat(s).astimezone(timezone.utc)


def _make_group(intervals: list, byte_sizes=None, src="1.1.1.1", dst="2.2.2.2", port=443) -> Group:
    base = _utc("2026-04-21T08:00:00+00:00")
    t = base
    events = []
    bs_iter = iter(byte_sizes or [None] * (len(intervals) + 1))
    for i in range(len(intervals) + 1):
        events.append(ConnectionRecord(
            timestamp_utc=t, source_address=src, destination_address=dst,
            destination_port=port, protocol="TCP", byte_size=next(bs_iter),
            input_source="test",
        ))
        if i < len(intervals):
            t = t + timedelta(seconds=intervals[i])
    return Group(key=(dst, port, "TCP"), destination_address=dst,
                 destination_port=port, protocol="TCP", events=events)


def test_one_event_no_intervals():
    g = _make_group([])
    s = compute_statistics(g, AnalysisConfig())
    assert s.event_count == 1
    assert s.interval_count == 0
    assert s.mean_interval is None
    assert s.median_interval is None
    assert s.jitter_band_fit_pct is None
    assert "insufficient events for intervals" in s.notes[0]


def test_two_events_one_interval():
    g = _make_group([60.0])
    s = compute_statistics(g, AnalysisConfig())
    assert s.event_count == 2
    assert s.interval_count == 1
    assert s.mean_interval == 60.0
    assert s.median_interval == 60.0
    # std of one value is None (we need >= 2 intervals for std).
    assert s.std_interval is None
    assert s.cv_interval is None
    # But jitter-band fit is still computable (1 of 1 in band).
    assert s.jitter_band_fit_count == 1
    assert s.jitter_band_fit_pct == 100.0


def test_strict_periodic_zero_jitter():
    g = _make_group([60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60])  # 12 events
    s = compute_statistics(g, AnalysisConfig())
    assert s.mean_interval == 60.0
    assert s.median_interval == 60.0
    assert s.std_interval == 0.0
    assert s.cv_interval == 0.0
    assert s.absolute_jitter == 0.0
    assert s.relative_jitter_pct == 0.0
    assert s.jitter_band_fit_pct == 100.0
    assert s.min_interval == 60.0
    assert s.max_interval == 60.0


def test_jittered_within_band():
    # 60s base ± 10s -> all within ±20% band (48-72).
    g = _make_group([50, 70, 55, 65, 60, 50, 70, 55, 65, 60, 50])
    s = compute_statistics(g, AnalysisConfig(jitter_percent=20))
    assert s.jitter_band_fit_pct == 100.0
    assert s.absolute_jitter > 0


def test_jittered_outside_band():
    # Mix 60s and 180s — only some in band.
    g = _make_group([60, 60, 180, 60, 60, 180, 60, 60, 180, 60, 60])
    s = compute_statistics(g, AnalysisConfig(jitter_percent=20))
    # Median is 60 (8 of 60s, 3 of 180s). 8 of 11 in band.
    assert s.median_interval == 60.0
    assert s.jitter_band_fit_pct == pytest.approx(100.0 * 8 / 11, abs=0.5)


def test_zero_mean_safe_cv():
    # All intervals 0 -> mean 0 -> CV must be None (not divide-by-zero).
    g = _make_group([0, 0, 0, 0])
    s = compute_statistics(g, AnalysisConfig())
    assert s.mean_interval == 0.0
    assert s.cv_interval is None
    assert "zero mean" in " ".join(s.notes) or s.cv_interval is None


def test_missing_byte_sizes_excluded_not_zeroed():
    # 5 events; 3 have byte_size None.
    g = _make_group([60, 60, 60, 60], byte_sizes=[100, None, 100, None, 100])
    s = compute_statistics(g, AnalysisConfig())
    assert s.byte_count == 3
    assert s.byte_missing_count == 2
    assert s.byte_mean == 100.0
    assert "missing byte size" in " ".join(s.notes)


def test_insufficient_byte_sizes():
    # Only 1 byte size -> stats require >= 2.
    g = _make_group([60, 60, 60], byte_sizes=[100, None, None, None])
    s = compute_statistics(g, AnalysisConfig())
    assert s.byte_count == 1
    assert s.byte_std is None
    assert s.byte_cv is None


def test_population_vs_sample_stddev():
    g = _make_group([60, 70, 80, 90, 100])
    s_pop = compute_statistics(g, AnalysisConfig(use_population_std=True))
    s_samp = compute_statistics(g, AnalysisConfig(use_population_std=False))
    # Sample stddev > population stddev for the same data.
    assert s_samp.std_interval > s_pop.std_interval
    # Sanity check the population value matches numpy.
    import numpy as np
    assert s_pop.std_interval == pytest.approx(float(np.std([60, 70, 80, 90, 100], ddof=0)))


def test_absolute_jitter_is_mad_median():
    # Median 60; abs deviations: |60-60|=0, |70-60|=10, |50-60|=10, |60-60|=0,
    # |70-60|=10, |50-60|=10. Median of those is (0,0,10,10,10,10) -> median 10.
    g = _make_group([60, 70, 50, 60, 70, 50])
    s = compute_statistics(g, AnalysisConfig())
    assert s.median_interval == 60.0
    assert s.absolute_jitter == 10.0
    assert s.relative_jitter_pct == pytest.approx(100.0 * 10.0 / 60.0)


def test_min_max_intervals():
    g = _make_group([10, 200, 50, 90, 5, 300])
    s = compute_statistics(g, AnalysisConfig())
    assert s.min_interval == 5.0
    assert s.max_interval == 300.0


def test_first_last_seen():
    g = _make_group([60, 60])
    assert g.first_seen == _utc("2026-04-21T08:00:00+00:00")
    assert g.last_seen == _utc("2026-04-21T08:02:00+00:00")


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
