"""Stage 3 tests — CSV and plain-text parsers, and that all three parsers
produce the same ConnectionRecord model.
"""
from __future__ import annotations

import os
import sys
from datetime import timezone

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.parsers.csv_parser import CsvParser, ColumnMapping, HEADER_ALIASES
from beaconhunt.parsers.text_parser import TextParser, NAMED_FORMATS
from beaconhunt.parsers.pcap_parser import PcapParser
from beaconhunt.models.records import ConnectionRecord

SAMPLES = os.path.join(PROJECT_ROOT, "samples")


def test_csv_strict_periodic():
    p = CsvParser()
    r = p.parse(os.path.join(SAMPLES, "strict_periodic.csv"))
    assert r.input_type == "csv"
    assert len(r.records) == 12
    assert len(r.warnings) == 0, [str(w) for w in r.warnings]
    first = r.records[0]
    assert first.source_address == "198.51.100.7"
    assert first.destination_address == "203.0.113.10"
    assert first.destination_port == 443
    assert first.protocol == "TCP"
    assert first.byte_size == 256
    assert first.timestamp_utc.tzinfo == timezone.utc


def test_csv_auto_detect_header():
    m = ColumnMapping.from_header_row(["Time", "src_ip", "dst", "DPT", "Proto", "Bytes"])
    # 'Time' is in the timestamp aliases; src_ip in source aliases; etc.
    # DPT was added to the destination_port aliases.
    assert m.timestamp == "Time"
    assert m.source == "src_ip"
    assert m.destination == "dst"
    assert m.destination_port == "DPT"
    assert m.protocol == "Proto"
    assert m.bytes == "Bytes"


def test_csv_explicit_column_mapping():
    # Make a custom CSV with non-standard headers.
    custom = os.path.join(SAMPLES, "_custom.csv")
    with open(custom, "w") as fh:
        fh.write("when,who,where,portX,proto_name,size_x\n")
        fh.write("2026-04-21T08:00:00+00:00,1.1.1.1,2.2.2.2,443,TCP,100\n")
    mapping = ColumnMapping(
        timestamp="when", source="who", destination="where",
        destination_port="portX", protocol="proto_name", bytes="size_x",
    )
    p = CsvParser(mapping=mapping)
    r = p.parse(custom)
    assert len(r.records) == 1
    assert r.records[0].destination_port == 443
    assert r.records[0].byte_size == 100
    os.unlink(custom)


def test_csv_malformed_skips_with_warnings():
    p = CsvParser()
    r = p.parse(os.path.join(SAMPLES, "malformed.csv"))
    # Header + 6 data rows. 4 are broken -> 2 valid records.
    assert len(r.records) == 2, f"expected 2 valid records, got {len(r.records)}"
    assert r.skipped_records == 4
    assert len(r.warnings) >= 4  # one per skipped row


def test_csv_empty_file():
    p = CsvParser()
    r = p.parse(os.path.join(SAMPLES, "empty.csv"))
    assert r.records == []
    assert any(w.severity == "error" for w in r.warnings)


def test_csv_missing_bytes_preserved_as_none():
    p = CsvParser()
    r = p.parse(os.path.join(SAMPLES, "missing_bytes.csv"))
    # ~40% of 10 rows should have None byte_size, but at least one.
    none_count = sum(1 for rec in r.records if rec.byte_size is None)
    assert none_count >= 1, "expected some None byte_size values"
    # And the non-None values should NOT have been silently zeroed.
    for rec in r.records:
        if rec.byte_size is not None:
            assert rec.byte_size > 0


def test_csv_timezone_offset_normalized_to_utc():
    p = CsvParser()
    r = p.parse(os.path.join(SAMPLES, "timezone_offset.csv"))
    # Source was 08:00 +05:00 -> should normalize to 03:00 UTC.
    first = r.records[0]
    assert first.timestamp_utc.hour == 3, first.timestamp_utc
    assert first.timestamp_utc.tzinfo == timezone.utc


def test_text_firewall_format():
    p = TextParser(format_name="firewall_kv")
    r = p.parse(os.path.join(SAMPLES, "firewall.txt"))
    assert r.input_type == "text"
    assert len(r.records) == 12
    first = r.records[0]
    assert first.destination_address == "203.0.113.90"
    assert first.destination_port == 443
    assert first.protocol == "TCP"
    assert first.byte_size == 256


def test_text_custom_regex():
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".log", delete=False) as fh:
        fh.write("2026-04-21T08:00:00Z 1.2.3.4 5.6.7.8 443 TCP 128\n")
        fh.write("2026-04-21T08:01:00Z 1.2.3.4 5.6.7.8 443 TCP 128\n")
        path = fh.name
    try:
        regex = (
            r"(?P<ts>\S+)\s+(?P<src>\S+)\s+(?P<dst>\S+)\s+"
            r"(?P<dport>\d+)\s+(?P<proto>\S+)\s+(?P<bytes>\d+)"
        )
        p = TextParser(custom_regex=regex)
        r = p.parse(path)
        assert len(r.records) == 2
        assert r.records[0].destination_port == 443
    finally:
        os.unlink(path)


def test_text_empty_file():
    p = TextParser()
    r = p.parse(os.path.join(SAMPLES, "empty.csv"))
    assert r.records == []
    assert any(w.severity == "error" for w in r.warnings)


def test_text_invalid_regex_raises():
    with pytest.raises(ValueError):
        TextParser(custom_regex="(unclosed")


def test_text_unknown_format_raises():
    with pytest.raises(ValueError):
        TextParser(format_name="bogus")


def test_all_parsers_produce_same_record_type():
    """Stage 3 contract: PCAP, CSV, and text parsers all return ConnectionRecord."""
    pr = PcapParser().parse(os.path.join(SAMPLES, "periodic.pcap"))
    cr = CsvParser().parse(os.path.join(SAMPLES, "strict_periodic.csv"))
    tr = TextParser().parse(os.path.join(SAMPLES, "firewall.txt"))
    for r_list in (pr.records, cr.records, tr.records):
        for rec in r_list:
            assert isinstance(rec, ConnectionRecord)
            assert rec.timestamp_utc.tzinfo == timezone.utc


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
