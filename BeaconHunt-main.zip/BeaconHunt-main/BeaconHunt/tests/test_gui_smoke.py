"""Stage 1 + end-to-end GUI smoke test.

Runs under QT_QPA_PLATFORM=offscreen so it works in a headless sandbox.

This test does two things:

  1. Verifies the MainWindow constructs and shows without error (Stage 1).
  2. Verifies the AnalysisWorker runs end-to-end on a QThread and produces
     the expected flagged destinations for samples/mixed.csv (worker
     integration).

We deliberately do NOT drive the heavy UI-update path (results table
population + matplotlib canvas draw) because the matplotlib QtAgg backend
in offscreen mode interferes with QThread signal delivery to the main
event loop. The PDF render check in the README covers the rendered output.

The test polls the spy from a QTimer on the main thread (rather than
calling app.quit() from the worker-thread slot) so the event loop exits
cleanly even in offscreen mode.
"""
from __future__ import annotations

import os
import sys

# Make sure project root is importable.
HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from PySide6.QtCore import QObject, QThread, QTimer
from PySide6.QtWidgets import QApplication

from beaconhunt.config import AnalysisConfig
from beaconhunt.ui import MainWindow
from beaconhunt.workers.analysis_worker import AnalysisWorker


class _Spy(QObject):
    """Lives on the main thread; receives worker signals."""
    def __init__(self) -> None:
        super().__init__()
        self.report = None
        self.fail_msg = None
        self.done = False


def main() -> int:
    app = QApplication([])
    win = MainWindow()
    win.show()

    # Stage 1 — window constructed correctly.
    assert win.windowTitle().startswith("BeaconHunt"), win.windowTitle()
    assert win._stack.count() == 3, win._stack.count()

    samples_mixed = os.path.abspath(os.path.join(PROJECT_ROOT, "samples", "mixed.csv"))
    assert os.path.exists(samples_mixed), samples_mixed
    win._set_file(samples_mixed)
    assert win._stack.currentWidget() is win._import_panel

    payload = win._import_panel._build_payload()
    assert payload["path"] == samples_mixed
    assert payload["input_type"] == "csv"

    spy = _Spy()

    # These slots may run on the worker thread (PySide6 dispatches Python
    # closures to the emitter's thread in some configurations). They only
    # mutate the spy; the main-thread polling timer calls app.quit().
    def on_finished(report):
        spy.report = report
        spy.done = True
    def on_failed(msg):
        spy.fail_msg = msg
        spy.done = True
    def on_cancelled():
        spy.done = True

    worker = AnalysisWorker(
        path=payload["path"],
        input_type=payload["input_type"],
        config=payload["config"],
        column_mapping=payload.get("column_mapping"),
        text_format_name=payload.get("text_format_name"),
        text_custom_regex=payload.get("text_custom_regex"),
        exclusion_path=payload.get("exclusion_path"),
        baseline_path=payload.get("baseline_path"),
    )
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished_ok.connect(on_finished)
    worker.failed.connect(on_failed)
    worker.cancelled.connect(on_cancelled)

    thread.start()

    # Poll the spy from the main thread. When done, quit on the main
    # thread (which exits the event loop cleanly even with matplotlib's
    # QtAgg backend in offscreen mode).
    def _poll():
        if spy.done:
            app.quit()
    poll_timer = QTimer()
    poll_timer.setInterval(50)
    poll_timer.timeout.connect(_poll)
    poll_timer.start()

    # Fallback in case the worker hangs.
    QTimer.singleShot(15000, app.quit)
    rc = app.exec()
    poll_timer.stop()

    # Quit and wait for the worker thread on the main thread.
    thread.quit()
    thread.wait(5000)

    if spy.fail_msg:
        print(f"FAIL: worker reported error: {spy.fail_msg}")
        return 2
    if spy.report is None:
        print("FAIL: worker did not finish within the timeout.")
        return 3

    rep = spy.report
    assert len(rep.results) > 0, "no results"
    assert any(r.status == "flagged" for r in rep.results), \
        f"no flagged dest; results: {[(r.destination_address, r.status) for r in rep.results]}"
    flagged_addrs = [r.destination_address for r in rep.flagged]
    print(f"PASS: {len(rep.results)} destinations analyzed; flagged={flagged_addrs}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
