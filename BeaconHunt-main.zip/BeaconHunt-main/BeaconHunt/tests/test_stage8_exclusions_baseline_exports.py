"""Stage 8 tests — exclusions, baselines, and report exports."""
from __future__ import annotations

import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.config import AnalysisConfig
from beaconhunt.parsers.csv_parser import CsvParser
from beaconhunt.analysis import run_analysis
from beaconhunt.analysis.exclusions import load_exclusion_list, load_baseline, save_baseline
from beaconhunt.reports import export_json, export_csv, export_html, export_pdf, export_text

SAMPLES = os.path.join(PROJECT_ROOT, "samples")
TMP = os.path.join(PROJECT_ROOT, "tests", "_tmp")
os.makedirs(TMP, exist_ok=True)


@pytest.fixture
def mixed_report():
    pr = CsvParser().parse(os.path.join(SAMPLES, "mixed.csv"))
    return run_analysis(pr, AnalysisConfig())


@pytest.fixture
def mixed_report_with_excl():
    pr = CsvParser().parse(os.path.join(SAMPLES, "mixed.csv"))
    return run_analysis(pr, AnalysisConfig(),
                        exclusion_path=os.path.join(SAMPLES, "exclusions.txt"))


@pytest.fixture
def mixed_report_with_baseline():
    pr = CsvParser().parse(os.path.join(SAMPLES, "mixed.csv"))
    return run_analysis(pr, AnalysisConfig(),
                        baseline_path=os.path.join(SAMPLES, "baseline.json"))


# ---- Exclusions ----------------------------------------------------------
def test_exclusion_list_parses_and_flags_invalid_lines():
    el = load_exclusion_list(os.path.join(SAMPLES, "exclusions.txt"))
    assert len(el.entries) >= 3  # 203.0.113.10, 203.0.113.90:443, not-an-ip
    invalid = [e for e in el.entries if e.invalid_reason]
    assert any("hostname" in e.invalid_reason for e in invalid)


def test_exclusion_list_matches_exact_address():
    el = load_exclusion_list(os.path.join(SAMPLES, "exclusions.txt"))
    assert el.matches("203.0.113.10", 443) is not None
    assert el.matches("203.0.113.99", 443) is None


def test_exclusion_list_matches_address_port():
    el = load_exclusion_list(os.path.join(SAMPLES, "exclusions.txt"))
    # 203.0.113.90:443 should match port 443 but NOT port 80.
    assert el.matches("203.0.113.90", 443) is not None
    assert el.matches("203.0.113.90", 80) is None


def test_excluded_destinations_marked_with_reason(mixed_report_with_excl):
    rep = mixed_report_with_excl
    excluded = [r for r in rep.results if r.status == "excluded"]
    assert len(excluded) >= 1
    for r in excluded:
        assert r.exclusion_reason is not None
        assert r.key_reason.startswith("matched exclusion")
    # The excluded destination should NOT appear in flagged.
    flagged_addrs = [r.destination_address for r in rep.flagged]
    assert "203.0.113.10" not in flagged_addrs


def test_cidr_exclusion_matches_range():
    p = os.path.join(TMP, "cidr_excl.txt")
    with open(p, "w") as fh:
        fh.write("# CIDR test\n10.0.0.0/24\n")
    el = load_exclusion_list(p)
    assert el.matches("10.0.0.5", 443) is not None
    assert el.matches("10.0.1.5", 443) is None
    os.unlink(p)


# ---- Baselines -----------------------------------------------------------
def test_baseline_load_and_known_keys():
    bl = load_baseline(os.path.join(SAMPLES, "baseline.json"))
    assert bl.tool == "BeaconHunt"
    keys = bl.known_keys()
    assert ("203.0.113.10", 443, "TCP") in keys
    assert ("203.0.113.90", 443, "TCP") in keys


def test_baseline_comparison_marks_new_destinations(mixed_report_with_baseline):
    rep = mixed_report_with_baseline
    # The mixed.csv file has destinations 203.0.113.{10,20,30,40}. The
    # baseline knows 203.0.113.10 and 203.0.113.90. So new destinations are
    # .20, .30, .40 (all not in baseline).
    news = [r.destination_address for r in rep.results if r.baseline_status == "new"]
    assert "203.0.113.20" in news
    assert "203.0.113.30" in news
    # .10 is in baseline -> known.
    r10 = next(r for r in rep.results if r.destination_address == "203.0.113.10")
    assert r10.baseline_status == "known"


def test_save_baseline_refuses_overwrite_without_force():
    p = os.path.join(TMP, "test_baseline.json")
    if os.path.exists(p):
        os.unlink(p)
    pr = CsvParser().parse(os.path.join(SAMPLES, "strict_periodic.csv"))
    rep = run_analysis(pr, AnalysisConfig())
    save_baseline(p, rep.results, rep.config)
    # Second call without force should raise.
    with pytest.raises(FileExistsError):
        save_baseline(p, rep.results, rep.config)
    # With force=True it should succeed.
    save_baseline(p, rep.results, rep.config, force=True)
    # Validate the file structure.
    with open(p) as fh:
        data = json.load(fh)
    assert data["tool"] == "BeaconHunt"
    assert "destinations" in data
    os.unlink(p)


def test_invalid_baseline_produces_warning():
    p = os.path.join(TMP, "bad_baseline.json")
    with open(p, "w") as fh:
        fh.write("{not valid json")
    bl = load_baseline(p)
    assert any(w.severity == "error" for w in bl.load_warnings)
    os.unlink(p)


# ---- Exports -------------------------------------------------------------
def test_export_json(mixed_report, tmp_path):
    p = tmp_path / "r.json"
    export_json(mixed_report, str(p))
    assert p.exists() and p.stat().st_size > 0
    data = json.loads(p.read_text())
    assert data["tool"] == "BeaconHunt"
    assert "results" in data
    assert "settings" in data
    assert "limitations" in data


def test_export_csv(mixed_report, tmp_path):
    p = tmp_path / "r.csv"
    export_csv(mixed_report, str(p))
    lines = p.read_text().splitlines()
    assert lines[0].startswith("rank,status,destination_address")
    assert len(lines) >= 1 + len(mixed_report.results)


def test_export_html(mixed_report, tmp_path):
    p = tmp_path / "r.html"
    export_html(mixed_report, str(p))
    text = p.read_text()
    assert "<!DOCTYPE html>" in text
    assert "BeaconHunt" in text
    assert "Ranked results" in text


def test_export_pdf(mixed_report, tmp_path):
    p = tmp_path / "r.pdf"
    export_pdf(mixed_report, str(p))
    assert p.exists() and p.stat().st_size > 1000  # non-trivial PDF
    # Quick magic-byte check.
    with open(p, "rb") as fh:
        assert fh.read(4) == b"%PDF"


def test_export_text_with_histogram(mixed_report, tmp_path):
    p = tmp_path / "r.txt"
    export_text(mixed_report, str(p), include_histogram=True)
    text = p.read_text()
    assert "BeaconHunt Analysis Report" in text
    assert "Limitations" in text
    # At least one ASCII histogram block for flagged destinations.
    if mixed_report.flagged:
        assert "Interval histogram (ASCII):" in text
        assert "[" in text and "]" in text


def test_export_refuses_overwrite_without_force(mixed_report, tmp_path):
    p = tmp_path / "r.json"
    export_json(mixed_report, str(p))
    with pytest.raises(FileExistsError):
        export_json(mixed_report, str(p))


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
