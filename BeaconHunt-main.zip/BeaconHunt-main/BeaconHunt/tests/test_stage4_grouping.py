"""Stage 4 tests — grouping and interval computation."""
from __future__ import annotations

import os
import sys
from datetime import datetime, timezone, timedelta

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.config import AnalysisConfig
from beaconhunt.models.records import ConnectionRecord
from beaconhunt.analysis.grouping import group_records, Group

SAMPLES = os.path.join(PROJECT_ROOT, "samples")


def _utc(s: str) -> datetime:
    return datetime.fromisoformat(s).astimezone(timezone.utc)


def _make_records(dst: str, port: int, intervals: list, src: str = "1.1.1.1") -> list:
    base = _utc("2026-04-21T08:00:00+00:00")
    t = base
    out = []
    for i in range(len(intervals) + 1):
        out.append(ConnectionRecord(
            timestamp_utc=t, source_address=src, destination_address=dst,
            destination_port=port, protocol="TCP", byte_size=100,
            input_source="test",
        ))
        if i < len(intervals):
            t = t + timedelta(seconds=intervals[i])
    return out


def test_grouping_by_dest_port_protocol():
    cfg = AnalysisConfig(grouping_policy="dest_port_protocol")
    records = []
    records += _make_records("1.2.3.4", 443, [60, 60])
    records += _make_records("1.2.3.4", 443, [60])  # same group, more events
    records += _make_records("1.2.3.4", 80, [60, 60])  # different port
    records += _make_records("5.6.7.8", 443, [60, 60])  # different dst
    groups = group_records(records, cfg)
    assert len(groups) == 3
    by_key = {g.key: g for g in groups}
    assert ("1.2.3.4", 443, "TCP") in by_key
    # Same dst+port should have merged the two record batches.
    assert by_key[("1.2.3.4", 443, "TCP")].event_count == 5  # 3 + 2


def test_n_events_produce_n_minus_1_intervals():
    cfg = AnalysisConfig()
    records = _make_records("1.2.3.4", 443, [60, 60, 60, 60])  # 5 events
    groups = group_records(records, cfg)
    assert len(groups) == 1
    g = groups[0]
    assert g.event_count == 5
    assert g.interval_count == 4
    assert g.intervals_seconds == [60.0, 60.0, 60.0, 60.0]


def test_single_event_group_has_zero_intervals():
    cfg = AnalysisConfig()
    records = [ConnectionRecord(
        timestamp_utc=_utc("2026-04-21T08:00:00+00:00"),
        source_address="1.1.1.1", destination_address="2.2.2.2",
        destination_port=443, protocol="TCP", byte_size=100, input_source="t",
    )]
    groups = group_records(records, cfg)
    assert len(groups) == 1
    g = groups[0]
    assert g.event_count == 1
    assert g.interval_count == 0
    assert g.intervals_seconds == []


def test_events_sorted_within_group():
    cfg = AnalysisConfig()
    records = _make_records("1.2.3.4", 443, [60, 120, 30])
    # Shuffle the records.
    import random
    rng = random.Random(0)
    rng.shuffle(records)
    groups = group_records(records, cfg)
    g = groups[0]
    # After sorting, intervals should be 30, 60, 120 (ascending events).
    intervals = g.intervals_seconds
    assert sorted(intervals) == [30.0, 60.0, 120.0]


def test_alternative_grouping_policies():
    cfg_port = AnalysisConfig(grouping_policy="dest_port")
    cfg_dst = AnalysisConfig(grouping_policy="dest_only")
    records = []
    records += _make_records("1.2.3.4", 443, [60, 60])
    records += _make_records("1.2.3.4", 80, [60, 60])
    g_port = group_records(records, cfg_port)
    assert len(g_port) == 2  # two distinct ports
    g_dst = group_records(records, cfg_dst)
    assert len(g_dst) == 1  # one distinct dst


def test_source_address_count():
    cfg = AnalysisConfig()
    records = []
    for i, src in enumerate(["1.1.1.1", "2.2.2.2", "3.3.3.3"]):
        records.append(ConnectionRecord(
            timestamp_utc=_utc("2026-04-21T08:00:00+00:00") + timedelta(seconds=60*i),
            source_address=src, destination_address="9.9.9.9",
            destination_port=443, protocol="TCP", byte_size=100, input_source="t",
        ))
    groups = group_records(records, cfg)
    assert groups[0].source_address_count == 3


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
