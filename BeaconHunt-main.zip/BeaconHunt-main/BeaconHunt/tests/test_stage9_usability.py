"""Stage 9 QA tests — usability, cancellation, resizing.

Verifies keyboard navigation focus, that the cancel button is wired up,
that the window resizes without errors, and that the worker thread can be
cancelled mid-analysis without leaving the app in a broken state.

These run under QT_QPA_PLATFORM=offscreen; they do not exercise the
matplotlib canvas (which requires a real display backend for full visual
verification — that is covered by the PDF render check in the README).

The cancel/cancel tests use a main-thread polling timer to detect worker
completion. This is a workaround for a known interaction between
matplotlib's QtAgg backend and Qt's signal delivery in offscreen mode:
calling app.quit() from a worker-thread slot does not always exit the main
event loop. Polling from a main-thread QTimer avoids the issue entirely.
"""
from __future__ import annotations

import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from PySide6.QtCore import QObject, QThread, QTimer
from PySide6.QtWidgets import QApplication

from beaconhunt.config import AnalysisConfig
from beaconhunt.ui import MainWindow
from beaconhunt.workers.analysis_worker import AnalysisWorker


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


class _Spy(QObject):
    """Lives on the main thread; receives worker signals."""
    def __init__(self) -> None:
        super().__init__()
        self.report = None
        self.fail_msg = None
        self.cancelled = False
        self.done = False


def _run_worker_until_done(app, payload, cancel_after_ms=None):
    """Helper: start a worker, optionally cancel it, poll for completion."""
    spy = _Spy()

    def on_finished(report):
        spy.report = report
        spy.done = True
    def on_failed(msg):
        spy.fail_msg = msg
        spy.done = True
    def on_cancelled():
        spy.cancelled = True
        spy.done = True

    worker = AnalysisWorker(
        path=payload["path"],
        input_type=payload["input_type"],
        config=payload["config"],
        column_mapping=payload.get("column_mapping"),
        text_format_name=payload.get("text_format_name"),
        text_custom_regex=payload.get("text_custom_regex"),
        exclusion_path=payload.get("exclusion_path"),
        baseline_path=payload.get("baseline_path"),
    )
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished_ok.connect(on_finished)
    worker.failed.connect(on_failed)
    worker.cancelled.connect(on_cancelled)
    thread.start()

    if cancel_after_ms is not None:
        QTimer.singleShot(cancel_after_ms, lambda: worker.cancel())

    def _poll():
        if spy.done:
            app.quit()
    poll_timer = QTimer()
    poll_timer.setInterval(50)
    poll_timer.timeout.connect(_poll)
    poll_timer.start()
    QTimer.singleShot(15000, app.quit)  # fallback
    app.exec()
    poll_timer.stop()

    thread.quit()
    thread.wait(5000)
    return spy


def test_window_minimum_size(qapp):
    win = MainWindow()
    win.show()
    assert win.minimumWidth() <= 1024
    assert win.minimumHeight() <= 640
    # Resize and confirm no exception.
    win.resize(1400, 900)
    win.resize(1024, 640)
    win.close()
    qapp.processEvents()


def test_dashboard_buttons_have_focus_chain(qapp):
    win = MainWindow()
    win.show()
    # The redesigned Overview page has the Open / Open Sample buttons.
    overview = win._overview
    assert overview.btn_open.isEnabled()
    assert overview.btn_sample.isEnabled()
    win.close()


def test_import_panel_settings_have_tooltips(qapp):
    """Stage 9 — every analysis setting has a tooltip explaining it."""
    win = MainWindow()
    win.show()
    win._set_file(os.path.join(PROJECT_ROOT, "samples", "mixed.csv"))
    tooltips = [
        win._import_panel.sp_min_events.toolTip(),
        win._import_panel.sp_threshold.toolTip(),
        win._import_panel.sp_jitter.toolTip(),
        win._import_panel.sp_udp_timeout.toolTip(),
        win._import_panel.cmb_grouping.toolTip(),
        win._import_panel.cmb_tcp_policy.toolTip(),
        win._import_panel.cmb_byte_source.toolTip(),
        win._import_panel.chk_population.toolTip(),
    ]
    for tip in tooltips:
        assert tip and len(tip) > 10, f"missing or too-short tooltip: {tip!r}"
    win.close()


def test_cancel_during_analysis_is_safe(qapp):
    """Stage 9 — cancelling an analysis mid-run leaves the app usable.

    For a small synthetic sample the worker typically finishes before the
    cancel timer fires; both outcomes are acceptable as long as no error
    is raised and the worker eventually exits cleanly.
    """
    win = MainWindow()
    win.show()
    win._set_file(os.path.join(PROJECT_ROOT, "samples", "periodic.pcap"))
    payload = win._import_panel._build_payload()

    spy = _run_worker_until_done(qapp, payload, cancel_after_ms=10)

    assert spy.fail_msg is None
    assert spy.done is True
    win.close()


def test_close_event_cancels_worker(qapp):
    """Stage 9 — closing the window during analysis is safe."""
    win = MainWindow()
    win.show()
    win._set_file(os.path.join(PROJECT_ROOT, "samples", "periodic.pcap"))
    payload = win._import_panel._build_payload()

    # Start a worker manually so we can close the window mid-analysis.
    worker = AnalysisWorker(
        path=payload["path"], input_type=payload["input_type"],
        config=payload["config"],
    )
    thread = QThread()
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    thread.start()

    # Close the window shortly after starting.
    QTimer.singleShot(50, win.close)
    QTimer.singleShot(10000, qapp.quit)

    # Run a separate event loop until either closeEvent fires (which
    # cancels the worker) or the fallback timeout.
    qapp.exec()

    # Cleanup: ensure the worker thread is gone.
    thread.quit()
    thread.wait(5000)


def test_drag_drop_path(qapp):
    """Stage 9 — file path metadata updates correctly via the import panel API."""
    win = MainWindow()
    win.show()
    win._set_file(os.path.join(PROJECT_ROOT, "samples", "firewall.txt"))
    assert win._import_panel._input_type == "text"
    # The redesigned import panel uses csv_card / txt_card (lowercase).
    # For a text file, the CSV mapping card should be hidden and the text
    # format card visible.
    assert win._import_panel.csv_card.isVisible() is False
    assert win._import_panel.txt_card.isVisible() is True
    win.close()


def test_default_analysis_config_values(qapp):
    """Stage 9 — defaults match the documented spec."""
    cfg = AnalysisConfig()
    assert cfg.min_events == 5
    assert cfg.score_threshold == 70.0
    assert cfg.jitter_percent == 20.0
    assert cfg.udp_idle_timeout == 120.0
    assert cfg.grouping_policy == "dest_port_protocol"
    assert cfg.tcp_event_policy == "syn_no_ack"
    assert cfg.byte_size_source == "captured"
    assert cfg.use_population_std is True
    assert cfg.weights.interval_regularity == 0.35
    assert cfg.weights.jitter_consistency == 0.30
    assert cfg.weights.byte_size_consistency == 0.20
    assert cfg.weights.connection_count_support == 0.15


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
