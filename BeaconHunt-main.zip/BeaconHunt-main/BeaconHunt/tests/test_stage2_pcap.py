"""Stage 2 tests — PCAP parser and normalized events.

Verifies that PcapParser produces the correct ConnectionRecord fields
(timestamps, addresses, ports, protocols, byte sizes) for synthetic PCAPs
generated locally, and that truncated / empty cases produce warnings.
"""
from __future__ import annotations

import os
import sys
from datetime import timezone

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.parsers.pcap_parser import PcapParser
from beaconhunt.parsers.base import BaseParser
from beaconhunt.models.records import ConnectionRecord

SAMPLES = os.path.join(PROJECT_ROOT, "samples")


def test_detect_input_type_pcap():
    assert BaseParser.detect_input_type(os.path.join(SAMPLES, "periodic.pcap")) == "pcap"
    assert BaseParser.detect_input_type("foo.PCAPNG") == "pcap"
    assert BaseParser.detect_input_type("foo.cap") == "pcap"


def test_periodic_pcap_produces_expected_records():
    p = PcapParser()
    r = p.parse(os.path.join(SAMPLES, "periodic.pcap"))
    assert r.input_type == "pcap"
    assert len(r.records) == 10, f"expected 10 SYN events, got {len(r.records)}"
    assert len(r.warnings) == 0, [str(w) for w in r.warnings]
    first = r.records[0]
    assert first.source_address == "198.51.100.7"
    assert first.destination_address == "203.0.113.10"
    assert first.destination_port == 443
    assert first.protocol == "TCP"
    assert first.byte_size is not None and first.byte_size > 0
    # Timestamps are timezone-aware UTC.
    assert first.timestamp_utc.tzinfo == timezone.utc
    # Intervals should be exactly 60s between successive events.
    for a, b in zip(r.records, r.records[1:]):
        delta = (b.timestamp_utc - a.timestamp_utc).total_seconds()
        assert delta == 60.0, f"expected 60s, got {delta}"


def test_ipv6_pcap_produces_v6_addresses():
    p = PcapParser()
    r = p.parse(os.path.join(SAMPLES, "ipv6.pcap"))
    assert len(r.records) == 8
    first = r.records[0]
    assert ":" in first.source_address  # v6 has colons
    assert first.destination_address == "2001:db8:dead:beef::10"
    assert first.destination_port == 443
    assert first.protocol == "TCP"


def test_udp_pcap_uses_idle_timeout():
    # 8 UDP packets 90s apart, idle timeout 120s -> all in one flow, but
    # since the FIRST packet of each idle-gap > timeout starts a new event,
    # and 90s < 120s, every packet is recorded as part of one flow but the
    # first packet starts an event and each subsequent packet does NOT
    # (gap < timeout). So we expect exactly 1 event.
    p = PcapParser(udp_idle_timeout=120.0)
    r = p.parse(os.path.join(SAMPLES, "udp_periodic.pcap"))
    assert len(r.records) == 1, f"expected 1 UDP event with 120s timeout, got {len(r.records)}"
    # Now with a 60s timeout, every 90s gap is > timeout -> 8 events.
    p2 = PcapParser(udp_idle_timeout=60.0)
    r2 = p2.parse(os.path.join(SAMPLES, "udp_periodic.pcap"))
    assert len(r2.records) == 8, f"expected 8 UDP events with 60s timeout, got {len(r2.records)}"


def test_truncated_pcap_parses_partial():
    p = PcapParser()
    r = p.parse(os.path.join(SAMPLES, "truncated.pcap"))
    # Last packet was truncated, so we should get the first 9 events and
    # Scapy should not raise (it tolerates the truncation).
    assert len(r.records) >= 9, f"expected >=9 records, got {len(r.records)}"


def test_empty_pcap_produces_warning():
    p = PcapParser()
    # Use the empty.csv file path trick: parse a 0-byte file.
    empty_path = os.path.join(SAMPLES, "empty.csv")
    r = p.parse(empty_path)
    assert r.records == []
    assert any(w.severity == "error" for w in r.warnings)


def test_first_seen_tcp_policy_emits_warning():
    # Using the first_seen policy: the synthetic periodic.pcap has all 10
    # packets sharing the same (src, dst, dport, proto) key, so first_seen
    # records exactly 1 event (the first packet) and emits the heuristic
    # warning that documents the policy tradeoff.
    p = PcapParser(tcp_event_policy="first_seen")
    r = p.parse(os.path.join(SAMPLES, "periodic.pcap"))
    assert len(r.records) == 1
    assert any("first_seen" in w.message for w in r.warnings)


def test_byte_size_source_wire_vs_captured():
    p_cap = PcapParser(byte_size_source="captured")
    p_wire = PcapParser(byte_size_source="wire")
    r1 = p_cap.parse(os.path.join(SAMPLES, "periodic.pcap"))
    r2 = p_wire.parse(os.path.join(SAMPLES, "periodic.pcap"))
    # Wire length and captured length should be equal in this synthetic
    # capture (no truncation per-packet).
    assert r1.records[0].byte_size == r2.records[0].byte_size


def test_invalid_pcap_event_policy_raises():
    with pytest.raises(ValueError):
        PcapParser(tcp_event_policy="bogus")


def test_invalid_byte_size_source_raises():
    with pytest.raises(ValueError):
        PcapParser(byte_size_source="bogus")


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
