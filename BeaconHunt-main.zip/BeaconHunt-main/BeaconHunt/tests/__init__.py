"""BeaconHunt test package."""
