"""Stage 6 tests — scoring, thresholds, minimum-event enforcement."""
from __future__ import annotations

import os
import sys
from datetime import datetime, timezone, timedelta

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from beaconhunt.config import AnalysisConfig, ScoringWeights
from beaconhunt.models.records import ConnectionRecord
from beaconhunt.analysis.grouping import Group
from beaconhunt.analysis.scoring import score_group, rank_results, DestinationResult

# Reuse the helper from test_stage5_statistics (same directory).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from test_stage5_statistics import _make_group  # noqa: E402


def test_one_off_destination_never_flagged():
    # 3 events, below min_events=5 -> insufficient_evidence regardless of
    # how regular the intervals are.
    g = _make_group([60, 60])
    r = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    assert r.status == "insufficient_evidence"
    assert r.final_score == 0.0
    assert "minimum" in r.key_reason


def test_strict_periodic_scores_high_and_flagged():
    g = _make_group([60]*11, byte_sizes=[256]*12)  # 12 events, all identical
    r = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    assert r.status == "flagged"
    assert r.final_score >= 90
    # Components all used and at high values.
    for c in r.components:
        assert c.used
        if c.name in ("interval_regularity", "jitter_consistency",
                      "byte_size_consistency"):
            assert c.raw_score >= 90


def test_irregular_pattern_not_flagged():
    g = _make_group([10, 500, 30, 800, 5, 200, 90, 400, 12, 300])
    r = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    assert r.status == "not_flagged"
    assert r.final_score < 70


def test_missing_byte_size_does_not_zero_score():
    # All intervals perfect but byte_size None for every event.
    g = _make_group([60]*11, byte_sizes=[None]*12)
    r = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    # Should still flag because intervals are perfect.
    assert r.status == "flagged"
    # byte_size_consistency component must be dropped, not zero.
    byte_c = next(c for c in r.components if c.name == "byte_size_consistency")
    assert not byte_c.used
    # Other components used.
    used = [c.name for c in r.components if c.used]
    assert "interval_regularity" in used
    assert "jitter_consistency" in used


def test_weights_renormalized_when_byte_size_missing():
    g = _make_group([60]*11, byte_sizes=[None]*12)
    r = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    # Sum of weighted_score of used components should equal final_score.
    used = [c for c in r.components if c.used]
    s = sum(c.weighted_score for c in used)
    assert abs(s - r.final_score) < 0.1


def test_threshold_can_be_lowered_to_flag_irregular():
    g = _make_group([60, 90, 60, 90, 60, 90, 60, 90, 60, 90, 60])
    r_default = score_group(g, AnalysisConfig(min_events=5, score_threshold=70))
    r_low = score_group(g, AnalysisConfig(min_events=5, score_threshold=30))
    # With low threshold it should flag.
    assert r_low.status == "flagged" or r_low.final_score >= 30
    # At default 70 threshold it may or may not flag, but the score should
    # match the threshold comparison.
    if r_default.final_score >= 70:
        assert r_default.status == "flagged"
    else:
        assert r_default.status == "not_flagged"


def test_rank_results_orders_by_score_desc():
    r1 = DestinationResult(destination_address="1.1.1.1", destination_port=443,
                           protocol="TCP", final_score=80, event_count=10)
    r2 = DestinationResult(destination_address="2.2.2.2", destination_port=443,
                           protocol="TCP", final_score=50, event_count=10)
    r3 = DestinationResult(destination_address="3.3.3.3", destination_port=443,
                           protocol="TCP", final_score=20, event_count=3)
    r3.status = "insufficient_evidence"
    ranked = rank_results([r2, r1, r3])
    # Flagged (highest) first; insufficient last.
    assert ranked[0].final_score == 80
    assert ranked[-1].status == "insufficient_evidence"


def test_components_sum_to_final_score():
    g = _make_group([60]*11, byte_sizes=[256]*12)
    r = score_group(g, AnalysisConfig())
    used = [c for c in r.components if c.used]
    # Sum of weighted_score equals final_score (already renormalized).
    s = sum(c.weighted_score for c in used)
    assert abs(s - r.final_score) < 0.1


def test_default_weights_documented():
    w = ScoringWeights()
    assert w.interval_regularity == 0.35
    assert w.jitter_consistency == 0.30
    assert w.byte_size_consistency == 0.20
    assert w.connection_count_support == 0.15
    assert abs((w.interval_regularity + w.jitter_consistency +
                w.byte_size_consistency + w.connection_count_support) - 1.0) < 1e-9


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
